package main.java.lirmm.modelNavigation.factories;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.json.JSONObject;

import main.java.lirmm.modelNavigation.domains.Transition;

public class DotRulesCreator {

	
	
	List<Transition> transitions;
	
	public DotRulesCreator(List<Transition> transitions) {
		
		this.transitions = transitions;
	}
	
	
	public void createTransitions() {
		
		String template = "";
		
		for (Transition transition: transitions) {
			template += transition.getActualPage() + " -> " + transition.getNextPage() + ";\n";
		}
		
		toFileTxt(template);
	}
	
	/**
	 * 
	 * @param template
	 */
	 private void toFileTxt(String template) {
		FileWriter file;
		try {
            // Constructs a FileWriter given a file name, using the platform's default charset
           file =  (new FileWriter("models/outputs/dotFile.txt"));
           file.write(template.toString());
          
           file.flush();
           file.close();
           
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
