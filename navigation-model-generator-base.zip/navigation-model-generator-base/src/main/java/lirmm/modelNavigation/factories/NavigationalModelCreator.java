package main.java.lirmm.modelNavigation.factories;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import main.java.lirmm.modelNavigation.domains.Transition;

public class NavigationalModelCreator {
	
	
	List<Transition> transitions;
	
	public NavigationalModelCreator(List<Transition> transitions) {
		this.transitions = transitions;
	}
	
	
	public void createNavigationalModelCreation() {
		
		JSONObject rootModel = new JSONObject();
		
		JSONArray transitionsAsJsonObjects = new JSONArray();
		
		for (Transition transition: transitions) {
						
			JSONObject object = createTransitionEntity(transition);
			
			transitionsAsJsonObjects.put(object);
			
		}
		
		rootModel.put("transitions", transitionsAsJsonObjects);
		
		toFileJson(rootModel);
	}
	
	private JSONObject createTransitionEntity(Transition transition) {
		
		JSONObject entity = new JSONObject();
		
		entity.put("from", transition.getActualPage());		
		entity.put("to", transition.getNextPage());
		entity.put("by", transition.getByElement());
		entity.put("token", transition.getToken());
		
		return entity;
		
	}
	
	/**
	 * 
	 * @param template
	 */
	 private void toFileJson(JSONObject template) {
		FileWriter file;
		try {
            // Constructs a FileWriter given a file name, using the platform's default charset
           file =  (new FileWriter("models/outputs/navigationalModel.json"));
           file.write(template.toString());
          
           file.flush();
           file.close();
           
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

}
