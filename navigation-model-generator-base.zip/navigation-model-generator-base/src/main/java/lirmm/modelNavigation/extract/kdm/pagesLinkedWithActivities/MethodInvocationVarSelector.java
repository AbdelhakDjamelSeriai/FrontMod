package main.java.lirmm.modelNavigation.extract.kdm.pagesLinkedWithActivities;

import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

public class MethodInvocationVarSelector implements IVarSelector{
	
	
	@Override
	public boolean ifis(VariableDeclarationStatement var) {
		return (var.getFragments().get(0).getInitializer() instanceof MethodInvocation);
	}
	
	@Override
	public ClassDeclaration apply(VariableDeclarationStatement var) {
		return (ClassDeclaration)((MethodDeclaration)((MethodInvocation)var.getFragments().get(0).getInitializer()).getMethod()).getReturnType().getType();
	}

}
