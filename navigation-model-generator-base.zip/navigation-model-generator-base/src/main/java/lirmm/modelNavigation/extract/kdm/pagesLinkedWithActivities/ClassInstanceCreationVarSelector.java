package main.java.lirmm.modelNavigation.extract.kdm.pagesLinkedWithActivities;

import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;


public class ClassInstanceCreationVarSelector implements IVarSelector{
	
	
	@Override
	public boolean ifis(VariableDeclarationStatement var) {
		
		return (var.getFragments().get(0).getInitializer() instanceof ClassInstanceCreation) ;
	}
	
	@Override
	public ClassDeclaration apply(VariableDeclarationStatement var) {
		
		return  (ClassDeclaration)((ClassInstanceCreation)var.getFragments().get(0).getInitializer()).getType().getType();
	}
	
	

}
