package main.java.lirmm.modelNavigation.extract.kdm.placesLinkedWithActivities;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.ClassDeclaration;

import com.github.javaparser.ast.expr.ObjectCreationExpr;

import kdm.code.gwt.Activity;
import kdm.code.gwt.Place;
import main.java.lirmm.modelNavigation.extractors.ast.ASTParser;

public class PlacesActivities {

	
	public Map<Place,Activity> apMap= new HashMap<Place,Activity>();
	
	public EList<Activity> activities;
	
	public EList<Place> places;
	
	public ClassDeclaration activityMapper;
	

	
	
	public PlacesActivities(EList<Activity> activities, EList<Place> places, ClassDeclaration activitymapper) {
		
		this.activities = activities;
		
		this.places = places;
		
		this.activityMapper = activitymapper;
		
	}
	
	
	public void linkPlacesToActivities() {
		
		String FILE_PATH = activityMapper.getOriginalCompilationUnit().getOriginalFilePath();
		
		List<ObjectCreationExpr> creationExprs = (new ASTParser(FILE_PATH)).getObjectCreation();
		
		for (Activity activity: activities) {
			for (ObjectCreationExpr expr: creationExprs) {
				
				if (expr.getType().getNameAsString().equals(activity.getName())) {
					
					String arf = expr.getArguments().stream().filter(e -> e.isCastExpr() && e.toString().contains("place")).findFirst().get().toString();
					
					String placeIntanceName = arf.substring(arf.indexOf("(")+1, arf.indexOf(")"));

					//System.out.println(places.stream().filter(e -> e.getName().equals(placeIntanceName)).findFirst().get());
					
					apMap.put(places.stream().filter(e -> e.getName().equals(placeIntanceName)).findFirst().get(),activity);
				}
				
			}
			
		}
		
	}

	
	
	public Map<Place, Activity> getPlaceActivities() {
		linkPlacesToActivities();
		return apMap; 
	}
	
	
	
	
	
	
}
