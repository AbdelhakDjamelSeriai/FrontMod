package main.java.lirmm.modelNavigation.extract.kdm.pagesLinkedWithActivities;

import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

public interface IVarSelector {
	
	
	public boolean ifis(VariableDeclarationStatement var);
	
	public ClassDeclaration apply(VariableDeclarationStatement var);
}
