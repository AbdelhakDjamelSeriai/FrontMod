package main.java.lirmm.modelNavigation.extract.kdm.pagesLinkedWithActivities;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

import kdm.code.gwt.Activity;
import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.java.MethodDeclarationExtractor;

public class ActivityModifier {

	
	
	public Map<Page, Activity> pageActivity = new HashMap<Page, Activity>();
	
	
	
	/**
	 * 
	 */
	private static ActivityModifier uniqueInstance;
	
	/**
	 * 
	 */
	private ActivityModifier() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static ActivityModifier getInstance() {
		
		if (uniqueInstance == null) {
			
			uniqueInstance = new ActivityModifier();
			
		}
		
		return uniqueInstance;
	}
	
	
	

	/**
	 * Return null : if ClassDeclaration not exists in Pages Set from GWT Model 
	 * 
	 * else Return Page 
	 * 
	 * 
	 * @param classDeclaration
	 * @return
	 */
	public Page checkIfClassDeclarationIsPage(ClassDeclaration classDeclaration, EList<Page> pages) {
			
			boolean check = false;
			
			Page page = null;
			
			int index = 0 ; 
			
			if (classDeclaration != null) {
				
				while ((!check) && (index < pages.size())) {
					if (pages.get(index).getName().equals(classDeclaration.getName())) {
						check = true;
						page = pages.get(index);
					}
					index++;
				}
			} 
					
			return page;
	}
	
	
	/**
	 * link the activity to page , we initialize the @var pageActivity [{Page1 -> Activity 1}]
	 * 
	 * @param activity
	 */
	public void linkPageToActivity (Activity activity, EList<Page> pages) {
		
		MethodDeclaration startMethodDeclaration = MethodDeclarationExtractor.getInstance().getMethod( ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(activity) , "start");
		
		EList<VariableDeclarationStatement> variableDeclarationStatements = MethodDeclarationExtractor.getInstance().getVariableDeclarationList(startMethodDeclaration);
		
		
		IVarSelector[] iVarSelectors = {new ClassInstanceCreationVarSelector(), new MethodInvocationVarSelector() };
		
		
		Page page = null;
		
		for (VariableDeclarationStatement variableDeclarationStatement: variableDeclarationStatements) {
			
			for (IVarSelector iVarSelector : iVarSelectors) {
				
				if (iVarSelector.ifis(variableDeclarationStatement)) {
					
					page = checkIfClassDeclarationIsPage(iVarSelector.apply(variableDeclarationStatement), pages);
					
					if (page != null) {
						
						pageActivity.put(page, activity);
						
					}
				}
			}
		}
		
	}
	
	
	
	/**
	 * Return @var pageActivity after initialization
	 * 
	 * @param activities
	 * @return
	 */
	public Map<Page, Activity> getPageActivityMap(EList<Activity> activities, EList<Page> pages) {
		
		for (Activity activity: activities) {
			
			linkPageToActivity(activity, pages);
		
		}
		return pageActivity;
		 
	}
	
	
}
