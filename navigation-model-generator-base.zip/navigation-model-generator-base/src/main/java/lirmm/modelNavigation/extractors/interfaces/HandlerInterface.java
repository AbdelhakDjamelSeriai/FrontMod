package main.java.lirmm.modelNavigation.extractors.interfaces;

import java.util.List;

import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

public interface HandlerInterface {	
	// MethodInvocation is : addClickHandler(object or instance)
	//public MethodDeclaration getMethodHandler(MethodInvocation methodInvocation);
	
	// MethodDeclaration is : onClick(ClickEvent event)
	//public MethodInvocation getInvokedAddHandlerMethod();
	
	// get All Expressions of method Handler
	public List<Expression> getAllExpressionOfMethodHandler(MethodDeclaration methodDeclaration);
	
	// get All Variable declarations of method Handler
	public List<VariableDeclarationStatement> 
					getAllVariableDeclarationStatementsOfMethodHandler(MethodDeclaration methodDeclaration);
	
	// get All Method Invocations under method Handler
	public List<MethodInvocation> getAllMethodInvocationsOfMethodHandler(MethodDeclaration methodDeclaration);
	
	// get the Element How call the handler methods
	public String getElementHowCallInvokedMethod(MethodInvocation methodInvocation);

	// get method declaration handler !!!
	public MethodDeclaration getMethodDeclarationHandler(MethodInvocation methodInvocation);
	
}
