package main.java.lirmm.modelNavigation.extractors.java;

import org.eclipse.gmt.modisco.java.Package;

public class PackageIdentifier {
	
	
	/**
	 * 
	 */
	private static PackageIdentifier uniqueInstance;
	
	/**
	 * 
	 */
	private PackageIdentifier() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static PackageIdentifier getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new PackageIdentifier();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * Get Client Package
	 * @param root
	 * @return
	 */
	public Package getClientPackage(Package root) {
		
		if (!root.getName().equals("client")) {
						
			return getClientPackage(root.getOwnedPackages().get(0));
		}
		else
			return root.getPackage().getOwnedPackages().get(0);
		
	}

	
	/**
	 * Get Package that is Sub Package of Client Package
	 * @param client
	 * @param nameOfDesiredPackage
	 * @return
	 */
	public Package getPackagePageFromClientPackage(Package client, String nameOfDesiredPackage) {
		  
		  Package resultPackage = null;
		  if (client.getName().equals(nameOfDesiredPackage)) {
			  resultPackage = client;
		  } else {
			  for (Package package1: client.getOwnedPackages()) {
				  
				  if (package1.getName().equals(nameOfDesiredPackage)) {
					  
					  resultPackage = package1;
					  
					  return resultPackage;
					  
				  } else {
					  
					 resultPackage = getPackagePageFromClientPackage(package1, nameOfDesiredPackage);
					 
					 if (resultPackage!=null) {
						 
						 return resultPackage;
						 
					 }
				  }
				  
			  }
		  }
		  
		  
		  return resultPackage;
	}

}
