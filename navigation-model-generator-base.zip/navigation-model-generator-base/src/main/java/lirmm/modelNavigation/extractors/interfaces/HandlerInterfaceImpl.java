package main.java.lirmm.modelNavigation.extractors.interfaces;

import java.util.List;
import java.util.stream.Collectors;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

import main.java.lirmm.modelNavigation.extractors.java.HandlerExtractor;
import main.java.lirmm.modelNavigation.extractors.java.MethodHandlerContentAnalyzer;
import main.java.lirmm.modelNavigation.extractors.java.MethodHandlerExtractor;

public class HandlerInterfaceImpl implements HandlerInterface {
	
		
	public HandlerInterfaceImpl() {		
		 /// 
	}
	
	@Override
	public List<Expression> getAllExpressionOfMethodHandler(MethodDeclaration methodHandler) {
		return MethodHandlerContentAnalyzer.getInstance().getAllArguments(methodHandler);
	}
	
	@Override
	public List<VariableDeclarationStatement> getAllVariableDeclarationStatementsOfMethodHandler(MethodDeclaration methodHandler) {
		return MethodHandlerContentAnalyzer.getInstance().getAllVariableDeclarationStatements(methodHandler);
	}
	
	@Override
	public List<MethodInvocation> getAllMethodInvocationsOfMethodHandler(MethodDeclaration methodHandler) {
		
		List<MethodInvocation> methodInvocations = MethodHandlerContentAnalyzer.getInstance().getAllMethodInvocations(methodHandler);	
		
		if (methodInvocations!=null) {
			return methodInvocations.stream()
					.filter(e -> ((e.getMethod() instanceof MethodDeclaration) && ( e.getMethod().getBody()!=null )) )
					.collect(Collectors.toList());
		}
		return null;
	}

	@Override
	public String getElementHowCallInvokedMethod(MethodInvocation methodInvocation) {
		
		// You can add element 
		if (methodInvocation.getExpression() instanceof SingleVariableAccess) {
			return ((SingleVariableAccess)methodInvocation.getExpression()).getVariable().getName();
		}
		// Il y a un autre cas  
		return null;
	}

	@Override
	public MethodDeclaration getMethodDeclarationHandler(MethodInvocation methodInvocation) {

		return  MethodHandlerExtractor.getInstance().getHandlerMethod(methodInvocation);
	}
	
	
	

}
