package main.java.lirmm.modelNavigation.extractors.java;

import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.AnonymousClassDeclaration;
import org.eclipse.gmt.modisco.java.BodyDeclaration;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;


public class MethodHandlerExtractor {
	
	/**
	 * 
	 */
	private static MethodHandlerExtractor uniqueInstance;
	
	/**
	 * 
	 */
	private MethodHandlerExtractor() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static MethodHandlerExtractor getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new MethodHandlerExtractor();
		}
		return uniqueInstance;
	}
	
	
	
	public MethodDeclaration getHandlerMethod(MethodInvocation methodInvocation) {
		//if (getHandlerMethod( methodInvocation.getArguments()) != null) {
		
		return	getHandlerMethod( methodInvocation.getArguments()) ;
		//}
		
		//return null;
	}
	
	
	/**
	 * Get the Method Declaration from injected argument 
	 * case of handlers example : 
	 * 
	 * button.addClickHandler( new ClickHandler() {
	 * 	 --> public void onClick(ClickEvent event) {
	 * 	
	 * 		 }
	 * } 			  
	 * 
	 * "onClick" method should be returned
	 * @param expressions
	 * @return
	 */
	private MethodDeclaration getHandlerMethod(List<Expression> expressions) {
		
		
		
		if ( expressions.size() == 1 ) {
			
			// if the argument is type of AnonymousClassDeclaration
			
			if (expressions.get(0) instanceof ClassInstanceCreation) {
				// get the type
				ClassInstanceCreation classInstanceCreation = (ClassInstanceCreation) expressions.get(0);
				
				EList<BodyDeclaration> bodyDeclarations = null;
				if (classInstanceCreation.getAnonymousClassDeclaration()!=null) {
					AnonymousClassDeclaration anonymousClassDeclaration = 
							classInstanceCreation.getAnonymousClassDeclaration();
				   
					// get list of declarations
				   bodyDeclarations = anonymousClassDeclaration.getBodyDeclarations();
				   
				   // return the handler method
				   return MethodDeclarationExtractor.getInstance().getMethodIfItStartsWith(bodyDeclarations , "on");

				} else if ( classInstanceCreation.getType().getType() instanceof ClassDeclaration ) {
					ClassDeclaration classDeclaration = (ClassDeclaration)
							classInstanceCreation.getType().getType();
					
					bodyDeclarations = classDeclaration.getBodyDeclarations();
					
					// return the handler method
					return MethodDeclarationExtractor.getInstance().getMethodIfItStartsWith(bodyDeclarations , "on");
					
				}
				
			}
			
			/// case of ThisExpression
			/// case of .....
			/// case of .....
			
			else if (true) { 
				/// another case
				/// ... another case
			}
			
		}	
		return null;
	}
	
}
