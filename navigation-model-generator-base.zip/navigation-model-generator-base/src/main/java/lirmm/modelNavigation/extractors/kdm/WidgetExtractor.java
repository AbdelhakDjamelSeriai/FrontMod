package main.java.lirmm.modelNavigation.extractors.kdm;

import org.eclipse.emf.common.util.EList;

import kdm.code.gwt.Page;
import kdm.code.gwt.Widget;

public class WidgetExtractor {
	
	
	private String modelName;
	
	/**
	 * 
	 */
	private static WidgetExtractor uniqueInstance;
	
	
	/**
	 * 
	 */
	private WidgetExtractor(String modelName) {
		this.modelName = modelName; 
	}
	
	
	
	/**
	 * 
	 * @return uniqueInstance
	 */
	public static WidgetExtractor getInstance(String modelName) {
		if (uniqueInstance == null) {
			uniqueInstance = new WidgetExtractor(modelName);
		}
		return uniqueInstance;
	}
	
	/**
	 * Get Spec Widget From Page
	 *  
	 * @param pageName
	 * @param widgetName
	 * @return
	 */
	public Widget getWidgetFromPage(String pageName, String widgetName) {
		
		Page page = GwtModelExtractor.getInstance(modelName).getPageByName(pageName);
		
		return getPageWidget(page).stream().filter(w -> w.getName().equals(widgetName)).findFirst().get();
	
	}
	
	/**
	 * Get List Widget Of Page
	 * 
	 * @param page
	 * @return
	 */
	public EList<Widget> getPageWidget(Page page) {
		return page.getWidgets();
	}
	
	
}
