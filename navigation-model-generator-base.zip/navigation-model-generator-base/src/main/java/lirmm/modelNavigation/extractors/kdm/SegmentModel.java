package main.java.lirmm.modelNavigation.extractors.kdm;

import java.io.File;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import kdm.code.gwt.GwtPackage;
import kdm.kdm.Segment;

public class SegmentModel {
	
	private Segment segment = null;
	
	private Resource resourceModel = null;
	
	
	private static final String PATH_META_MODEL = "metamodels/kdm_gwt.ecore";
	
	/**
	 * Constructor of the class MethodUnitsExtractor. 
	 * Its visibility is private in order not to allow the other classes to create many instances of MethodUnitsExtractor
	 */
	private SegmentModel(){
		
	}
	
	/**
	 * unique instance of MethodUnitsExtractor.
	 */
	private static SegmentModel uniqueInstance;
	
	/**
	 *Method insuring that a unique instance of MethodUnitsExtractor is created.
	 * @return uniqueInstance
	 */
	public static SegmentModel getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new SegmentModel();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * 
	 * @param metamodelPath
	 * @param rs
	 * @return
	 */
	private String lazyMetamodelRegistration(String metamodelPath, ResourceSet rs){
		
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
		
   		// Enables extended meta-data, weird we have to do this but well...
	    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(EPackage.Registry.INSTANCE);
	    rs.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
	
	    Resource r = rs.getResource(URI.createFileURI(metamodelPath), true);
	    EObject eObject = r.getContents().get(0);
	    // A meta-model might have multiple packages we assume the main package is the first one listed
	    
	    lazyPackagesRegistration(eObject,rs);
	    if (eObject instanceof EPackage) {
	        EPackage p = (EPackage)eObject;
	       // System.out.println(p.getNsURI());
	       // EPackage.Registry.INSTANCE.put(p.getNsURI(), p);
	        rs.getPackageRegistry().put(p.getNsURI(), p);
	        return p.getNsURI();
	    }
	    return null;
	}
	
	/**
	 * 
	 * @param eObject
	 * @param rs
	 */
	private void lazyPackagesRegistration(EObject eObject, ResourceSet rs){
	    // A meta-model might have multiple packages we assume the main package is the first one listed
		 EList<EPackage> ePackages = ((EPackage) eObject).getESubpackages();
		
		for (EPackage ePackage: ePackages) {
	        //
			
			//System.out.println(ePackage.getName());
	       // EPackage.Registry.INSTANCE.put(ePackage.getNsURI(), ePackage);
	        rs.getPackageRegistry().put(ePackage.getNsURI(), ePackage);
	        lazyPackagesRegistration(ePackage,rs);
		}
		
	}
	
	public Segment getSegment(String ePath) {
	
		try {
			GwtPackage KdmInstance = GwtPackage.eINSTANCE;
			
			

			// Register the default resource factory
			Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
			
			Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());
			
			EPackage.Registry.INSTANCE.put(KdmInstance.eNS_URI, KdmInstance);
			// Create a resource set.  
			
			ResourceSet resourceSet = new ResourceSetImpl();
			// 
			lazyMetamodelRegistration(PATH_META_MODEL, resourceSet);
			// Get the URI of the model file.
			URI fileURI = URI.createFileURI(new File(ePath).getAbsolutePath());

			//
			resourceModel = resourceSet.getResource(fileURI, true);
			
			
			// get the KDM segment from the resource
			for (EObject eObject: resourceModel.getContents()) {
				if (eObject instanceof Segment) {
					segment = (Segment) eObject;
					break;
				}
			}
			
		} catch (Exception e) {
			System.out.println("Mahi il y une exception");
			System.out.println(e.getMessage());
		}
		return segment;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public GwtPackage getGwtPackage() {
		
		
		GwtPackage gwtPackage = null;
		
		for(EObject eObject: resourceModel.getContents()) {
			System.out.println(eObject.getClass().getName());

				if(eObject instanceof GwtPackage) {
					
					System.out.println("hiiiieeeeeeeeeeeeiii");

					gwtPackage = (GwtPackage)eObject;
					
					break;
				}
		}
		
		return gwtPackage;
	}
	
	/**
	 * 
	 */
	public Resource save()  {
		   // save changes in the file
		try {
			resourceModel.save(null);

		} catch (Exception e) {

			System.out.println(e);
		}
		
		return resourceModel;

	}
}
