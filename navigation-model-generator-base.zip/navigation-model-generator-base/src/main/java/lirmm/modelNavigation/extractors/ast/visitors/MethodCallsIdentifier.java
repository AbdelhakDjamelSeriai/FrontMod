package main.java.lirmm.modelNavigation.extractors.ast.visitors;

import java.util.ArrayList;
import java.util.List;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class MethodCallsIdentifier extends VoidVisitorAdapter<Void>{
	
	
	List<MethodCallExpr> methodInvocations = new ArrayList<>();
	
	@Override
	public void visit(MethodCallExpr n, Void arg) {
		super.visit(n, arg);	
		methodInvocations.add(n);

	}
	
	public List<MethodCallExpr> getMethodCalls(){
		return this.methodInvocations;
	} 

}
