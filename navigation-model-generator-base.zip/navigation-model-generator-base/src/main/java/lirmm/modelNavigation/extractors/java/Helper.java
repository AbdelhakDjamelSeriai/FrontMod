package main.java.lirmm.modelNavigation.extractors.java;

import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.Statement;

import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;

import main.java.lirmm.modelNavigation.visitors.arguments.IHelper;

public class Helper implements IHelper{
	
	/**
	 * 
	 */
	private static Helper uniqueInstance;
	
	
	/**
	 * 
	 */
	private Helper() {
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static Helper getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new Helper();
		}
		return uniqueInstance;
	}
	
	
	
	
	/**
	 * 
	 * @param creationExprs
	 * @param placesNames
	 * @return
	 */
	public List<ObjectCreationExpr> getPlacesInActivity(List<ObjectCreationExpr> creationExprs, List<String> placesNames) {
		
		return creationExprs.stream().filter(e -> placesNames.contains(e.asObjectCreationExpr().getTypeAsString())).collect(Collectors.toList());
	
	}
	
	
	/**
	 * Get 
	 * @param handlersMethod
	 * @return
	 */
	public List<String> mapNamesListExpr(List<MethodCallExpr> handlersMethod) {
		return handlersMethod.stream().map(MethodCallExpr::getNameAsString).collect(Collectors.toList());
	}
	
	
	
	@Override
	public List<ReturnStatement> getAllReturnStatementsInsideMethod(MethodDeclaration mtd) {
		
		List<Statement> statements = StatementExtractor.getInstance().getAllStatementsInsideMethodDeclaration(mtd);
		
		return statements.stream().filter(ReturnStatement.class::isInstance).map(ReturnStatement.class::cast).collect(Collectors.toList());
	}
	
	
	
	
	
	
	
	
	

}
