package main.java.lirmm.modelNavigation.extractors.java;

import java.io.File;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.gmt.modisco.java.Model;
import org.eclipse.gmt.modisco.java.emf.JavaPackage;


public class RootModel {
	/**
	 * 
	 */
	private static RootModel uniqueInstance;
	
	/**
	 * 
	 */
	private RootModel() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static RootModel getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new RootModel();
		}
		return uniqueInstance;
	}
	
	/**
	 * Get Java Model From 
	 * @param ePath
	 * @return
	 */
	public Model getJavaModelFromXMIFile(String ePath) {
		
		Model javaModel = null ;
		
		try {
			
			ResourceSet rs = new ResourceSetImpl();
						
			EPackage.Registry.INSTANCE.put(JavaPackage.eNS_URI, JavaPackage.eINSTANCE); 

			Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
			
			URI fileURI = URI.createFileURI(new File(ePath).getAbsolutePath());
			
			Resource resourceModel = rs.getResource(fileURI, true);
			
			javaModel = (Model) resourceModel.getContents().get(0);
			
			
		} catch (Exception e) {
			
			System.out.println(e.getMessage());
			
		}
		
		return javaModel;
	}
	
}
