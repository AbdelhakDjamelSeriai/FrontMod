package main.java.lirmm.modelNavigation.extractors.java;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.ExpressionStatement;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.Statement;

public class MethodInvocationExtractor {
	
	/**
	 * 
	 */
	private static MethodInvocationExtractor uniqueInstance;
	
	/**
	 * 
	 */
	private MethodInvocationExtractor() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static MethodInvocationExtractor getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new MethodInvocationExtractor();
		}
		return uniqueInstance;
	}
	
	/**
	 * <!-- Get All Method Invocation from Expression Statement -->
	 * @param expressionStatements
	 * @return
	 */
	public List<MethodInvocation> getMethodInovcationsFromExpressionStatement(List<ExpressionStatement> expressionStatements) {
		if (expressionStatements!=null) {
			return expressionStatements.stream().map(e -> e.getExpression())
					.filter(MethodInvocation.class::isInstance).map(MethodInvocation.class::cast).collect(Collectors.toList());
		}
		
		return null;
		
	}
	
	/**
	 * <!-- Get All method Invocation from statements -->
	 * @param statements
	 * @return
	 */
	public List<MethodInvocation> getMethodInovcationsFromStatements(List<Statement> statements) {
		
		return getMethodInovcationsFromExpressionStatement(StatementExtractor.getInstance().getExpressionStmts(statements));
	}
	
	
	/**
	 * <!-- Get All Method Invocation inside ClassDeclaration -->
	 * @param statements
	 * @return
	 */
	public List<MethodInvocation> getMethodInovcationsFromClassDeclaration(ClassDeclaration classDeclaration) {
		
		List<Statement> statements = StatementExtractor.getInstance().getAllStatements(classDeclaration);
		
		return getMethodInovcationsFromStatements(statements);
	}
	
	/**
	 * <!-- Get Add**Handler from class declarations  -->
	 * @param statements
	 * @return
	 */
	public List<MethodInvocation> getHandlers(ClassDeclaration classDeclaration) {
		
		List<MethodInvocation> methodInvocations = getMethodInovcationsFromClassDeclaration(classDeclaration);
		
		return getAllHandlers(methodInvocations);
	}
	
	/**
	 * Get All Method invocation type of button.addClickHandler( object || instance )
	 * @param methodInvocations
	 * @return
	 */
	private List<MethodInvocation> getAllHandlers(List<MethodInvocation> methodInvocations) {
		
		List<MethodInvocation> handlers = new ArrayList<>();
		
		if (methodInvocations!=null) {
			for(MethodInvocation methodInvocation: methodInvocations) {
				if (methodInvocation.getMethod().getName().startsWith("add") && 
					( methodInvocation.getMethod().getName().endsWith("Handler") || 
					  methodInvocation.getMethod().getName().endsWith("Listener")		
					)) {
					handlers.add(methodInvocation);
				}
			}
			
		 	return handlers; 
		}
		
		return null;
	}

	
	
	
	
	
}
