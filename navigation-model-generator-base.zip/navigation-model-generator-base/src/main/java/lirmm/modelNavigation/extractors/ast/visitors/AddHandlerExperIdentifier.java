package main.java.lirmm.modelNavigation.extractors.ast.visitors;

import java.util.ArrayList;
import java.util.List;

import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class AddHandlerExperIdentifier extends VoidVisitorAdapter<Void>{
	
	
	List<MethodCallExpr> methodInvocations = new ArrayList<>();

	
	@Override
	public void visit(MethodCallExpr n, Void arg) {
		super.visit(n, arg);		
		if (predicateAddHandlers(n)) {	
			methodInvocations.add(n);
		}
		
	}
	
	private boolean predicateAddHandlers(MethodCallExpr n) {
		return n.getNameAsString().startsWith("add") && n.getNameAsString().endsWith("Handler");
	}
	
	public List<MethodCallExpr> getCallExprs(){
		return methodInvocations;
	}

}
