package main.java.lirmm.modelNavigation.extractors.java;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.gmt.modisco.java.AbstractMethodDeclaration;
import org.eclipse.gmt.modisco.java.Block;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ExpressionStatement;
import org.eclipse.gmt.modisco.java.ForStatement;
import org.eclipse.gmt.modisco.java.IfStatement;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.SwitchStatement;
import org.eclipse.gmt.modisco.java.TryStatement;
import org.eclipse.gmt.modisco.java.WhileStatement;


public class StatementExtractor {
	
	/**
	 * 
	 */
	private static StatementExtractor uniqueInstance;
	
	/**
	 * 
	 */
	private StatementExtractor() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static StatementExtractor getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new StatementExtractor();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * Get All Statements from ClassDeclaration
	 * @param classDeclaration
	 * @return
	 */
	public List<Statement> getAllStatements(ClassDeclaration classDeclaration) {
		
		List<AbstractMethodDeclaration> abstractMethodDeclarations = 
				MethodDeclarationExtractor.getInstance().getAbstractMethodDeclarations(classDeclaration);
				;
		
		return getAllStatements(abstractMethodDeclarations);
	}
	
	
	/**
	 * Get All Statement Inside Method Declaration
	 * @param methodDeclaration
	 * @return
	 */
	public List<Statement> getAllStatementsInsideMethodDeclaration(MethodDeclaration methodDeclaration){
		return getAllStatementOfGivenBlock(methodDeclaration.getBody());
	}
	
	/**
	 * Get All Statements from set of abstractMethodDeclaration
	 * @param abstractMethodDeclarations
	 * @return
	 */
	public List<Statement> getAllStatements(List<AbstractMethodDeclaration> abstractMethodDeclarations) {
		
		List<Statement> statements = new ArrayList<>();
		
		if (abstractMethodDeclarations!= null) {
			for (AbstractMethodDeclaration abstractMethodDeclaration: abstractMethodDeclarations) {
				if (abstractMethodDeclaration.getBody()!=null) {
					statements.addAll( getAllStatementOfGivenBlock(abstractMethodDeclaration.getBody()));
				}
			}
			
			return statements;
		}
		return null;
	}
	
	/**
	 * Get All Statement inside a Block
	 * @param block
	 * @return
	 */
	public List<Statement> getAllStatementOfGivenBlock(Block block){	
		List<Statement> statements = new ArrayList<>();
		for (Statement statement: block.getStatements()) {
			
			
			
			if ( (!(statement instanceof TryStatement)) && (!(statement instanceof Block)) ) {
				
					statements.add(statement);	
				
					if (statement instanceof IfStatement && ( ((IfStatement)statement).getThenStatement() instanceof Statement ) ) {
						statements.add(((IfStatement)statement).getThenStatement());
					}
					
					if (statement instanceof IfStatement && ( ((IfStatement)statement).getElseStatement() instanceof Statement ) ) {
						statements.add(((IfStatement)statement).getElseStatement());
					}
					
					if (statement instanceof SwitchStatement) {
						statements.addAll( ((SwitchStatement)statement).getStatements() );
					}
					
					if (statement instanceof ForStatement && ( ((ForStatement)statement).getBody() instanceof Statement ) ) {
						statements.add( ((ForStatement)statement).getBody() );
					}
					
					if (statement instanceof WhileStatement && ( ((WhileStatement)statement).getBody() instanceof Statement ) ) {
						
						statements.add( ((WhileStatement)statement).getBody() );				
					}
					
			} //else {
				
			if (statement instanceof Block) {
				statements.addAll(getAllStatementOfGivenBlock( (Block) statement));						
			}		
				
			if (statement instanceof TryStatement) {
				statements.addAll(getAllStatementOfGivenBlock( (Block) ((TryStatement) statement).getBody()) );
			}
				
			if (statement instanceof IfStatement && ( ((IfStatement)statement).getThenStatement() instanceof Block ) ) {
				statements.addAll(getAllStatementOfGivenBlock( (Block) ((IfStatement)statement).getThenStatement() ));
			}
				
			if (statement instanceof IfStatement && ( ((IfStatement)statement).getElseStatement() instanceof Block ) ) {
				statements.addAll(getAllStatementOfGivenBlock( (Block) ((IfStatement)statement).getElseStatement()));
			}
				
			if (statement instanceof ForStatement && ( ((ForStatement)statement).getBody() instanceof Block ) ) {
				
				statements.addAll(getAllStatementOfGivenBlock( (Block) ((ForStatement)statement).getBody() ));
			}
				
			if (statement instanceof WhileStatement && ( ((WhileStatement)statement).getBody() instanceof Block ) ) {
				statements.addAll(getAllStatementOfGivenBlock( (Block)(((WhileStatement)statement).getBody()) ));		
			}
				
			//}	
		}		
		return statements;
	}
	
	
	/**
	 * Get All Expression Statement
	 * @param statements
	 * @return
	 */
	public List<ExpressionStatement> getExpressionStmts(List<Statement> statements) {
		  if (statements!=null) {
			  return statements.stream().filter(ExpressionStatement.class::isInstance).map(ExpressionStatement.class::cast).collect(Collectors.toList());
		  }
		return null;
	}
	
	
	
	
}
