package main.java.lirmm.modelNavigation.extractors.ast.visitors;

import java.util.ArrayList;
import java.util.List;

import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class MethodDeclarationIdentifier extends VoidVisitorAdapter<Void>{
	
	
	List<MethodDeclaration> methodDeclarations = new ArrayList<>();
	
	@Override
	public void visit(MethodDeclaration n, Void arg) {
		super.visit(n, arg);
		methodDeclarations.add(n);
		
	}

	public List<MethodDeclaration> getMethodDeclarations() {
		return this.methodDeclarations;
	}
}
