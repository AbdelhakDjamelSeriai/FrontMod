package main.java.lirmm.modelNavigation.extractors.ast.visitors;

import java.util.List;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.CallableDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;

import main.java.lirmm.modelNavigation.extractors.ast.ASTParser;
import main.java.lirmm.modelNavigation.extractors.java.HandlerExtractor;

public class FilterFacade {
	
	private static FilterFacade uniqueInstance;
	
	private FilterFacade() {
		
	}
	
	public static FilterFacade getInstance() {
		
		if(uniqueInstance == null) {
			uniqueInstance = new FilterFacade();
		} 		
		return uniqueInstance;
	}
	
	
	
	/**
	 * You can change after the predicate selection of method declaration
	 * @param path
	 * @param methodCallExpr
	 * @return
	 */
	public MethodDeclaration getMdFromGivenMc(String path, MethodCallExpr methodCallExpr) {
		
		return (new ASTParser(path).getMethodDeclarations())
							.stream()
							.filter( e -> isMcTypeOfInovkeMd(methodCallExpr,e)
									)
							.findFirst().orElse(null);	
	}
	
	
	/**
	 * Predicate to check if method invocation is type of method declaration
	 * @param mc
	 * @param md
	 * @return
	 */
	public boolean isMcTypeOfInovkeMd(MethodCallExpr mc, MethodDeclaration md) {		
		return md.getName().getIdentifier().equals(mc.getName().getIdentifier()) ;		
	}
	
	
	/**
	 * Predicate to check if set of methodInvocations contain Clear Add statement
	 * @param methodInvocations
	 * @return
	 */
	public boolean itContainsClearAdd(List<MethodCallExpr> methodInvocations) 
	{				
		   return (
			methodInvocations.stream().anyMatch(e -> HandlerExtractor.getInstance().getMethodName(e).equals("clear"))				
			&&		
			methodInvocations.stream().anyMatch( e -> HandlerExtractor.getInstance().getMethodName(e).equals("add"))
		   );
	}
	
	public MethodCallExpr getAddMethod(List<MethodCallExpr> methodInvocations) {
		
		return  methodInvocations.stream().filter( e -> HandlerExtractor.getInstance().getMethodName(e).equals("add")).findFirst().orElse(null);
	}
	
	
	
	/**
	 * get the parent
	 * @param expr
	 * @return
	 */
	public CallableDeclaration getCallableDeclarationContainsMethodCall(MethodCallExpr node) {
			
			Node parent = node.getParentNode().orElse(null);
			
			boolean check = false;
			while(!check) {
				if ( parent instanceof CallableDeclaration ) {
					check = true;
				} else {
					parent = parent.getParentNode().get();
				}
			}
			
			return (CallableDeclaration)parent;
	}
	
	/**
	 * 
	 * @param node
	 * @return
	 */
	public boolean checkIfMethodDeclarationDirectlyInClass(Node node) {
		return (node.getParentNode().get() instanceof ClassOrInterfaceDeclaration) ;
	}
	
	
	/**
	 * @param node
	 * @return
	 */
	public ObjectCreationExpr getHandlerMethod(Node node) {
		
		Node parent = node.getParentNode().orElse(null);
		
		boolean check = false;

		while(!check) {
			if ( parent instanceof ObjectCreationExpr ) {
				check = true;
			} else {
				parent = parent.getParentNode().get();
			}
		}
		
		return (ObjectCreationExpr)parent;
	}
	
	
	
	
		
}
