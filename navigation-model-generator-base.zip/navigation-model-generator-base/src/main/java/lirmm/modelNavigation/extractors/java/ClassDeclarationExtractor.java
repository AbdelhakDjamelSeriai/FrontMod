package main.java.lirmm.modelNavigation.extractors.java;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.AbstractTypeDeclaration;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.Model;
import org.eclipse.gmt.modisco.java.Package;
import kdm.code.ClassUnit;


public class ClassDeclarationExtractor {
	
	private String pathToJavaModel = "models/inputs/java-model/";

	
	/**
	 * 
	 */
	private static ClassDeclarationExtractor uniqueInstance;
	
	
	/**
	 * 
	 */
	private ClassDeclarationExtractor(String pathString) {
		pathToJavaModel += pathString;
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static ClassDeclarationExtractor getInstance(String pathString) {
		if (uniqueInstance == null) {
			uniqueInstance = new ClassDeclarationExtractor(pathString);
		}
		return uniqueInstance;
	}
	
	
	
	
	/**
	 * Get Class Declaration that corresponds to ClassUnit
	 * @param classUnit
	 * @return
	 */
	public ClassDeclaration getClassDeclaration(ClassUnit classUnit) {
		
		ClassDeclaration desiredClassDeclaration = null;
		
		
		String packageName = ((kdm.code.Package)classUnit.eContainer()).getName();
			
		Model rootModel = RootModel.getInstance().getJavaModelFromXMIFile(pathToJavaModel);
		
		Package client = PackageIdentifier.getInstance().getClientPackage(rootModel.getOwnedElements().get(0));
		
		
		Package package1 = PackageIdentifier.getInstance().getPackagePageFromClientPackage(client,packageName);
			
			
		EList<ClassDeclaration> classDeclarations = getClassesDeclaration(package1);
			
			 
			
		for (ClassDeclaration classDeclaration: classDeclarations) {
			if (classDeclaration.getName().equals(classUnit.getName())) {
					desiredClassDeclaration = classDeclaration; 
			}
		}
			
		
		return desiredClassDeclaration;
	}
	
	
	/**
	 * Get Classes Declaration from A Package
	 * @param package1
	 * @return
	 */
	public EList<ClassDeclaration> getClassesDeclaration(Package package1) {
		 
		 EList<AbstractTypeDeclaration> abstractTypeDeclarations= package1.getOwnedElements();
		 
		 EList<ClassDeclaration> classDeclarations = new BasicEList<>();
		 
		 for (AbstractTypeDeclaration abstractTypeDeclaration : abstractTypeDeclarations) {
			 
			 if (abstractTypeDeclaration instanceof ClassDeclaration) {
				 
				 classDeclarations.add((ClassDeclaration)abstractTypeDeclaration);
				 
			 }
		 }
		 
		return classDeclarations;
	}
}
