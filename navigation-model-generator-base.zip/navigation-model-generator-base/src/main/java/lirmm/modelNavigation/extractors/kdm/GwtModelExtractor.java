package main.java.lirmm.modelNavigation.extractors.kdm;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.EList;

import kdm.code.gwt.Activity;
import kdm.code.gwt.ActivityMapper;
import kdm.code.gwt.GwtModel;
import kdm.code.gwt.Page;
import kdm.code.gwt.Place;

public class GwtModelExtractor {
	
	private String pathString = "models/inputs/gwt-kdm-model/";

	/**
	 * 
	 */
	private static GwtModelExtractor uniqueInstance;
	
	
	/**
	 * 
	 */
	private GwtModelExtractor(String nameOfModelFile) {
		this.pathString += nameOfModelFile; 
	}
	
	
	
	/**
	 * 
	 * @return uniqueInstance
	 */
	public static GwtModelExtractor getInstance(String nameOfModelFile) {
		if (uniqueInstance == null) {
			uniqueInstance = new GwtModelExtractor(nameOfModelFile);
		}
		return uniqueInstance;
	}
	
	
	/**
	 * Get <em>GWT Model</em> From Segment
	 * @return
	 */
	public GwtModel getGwtModel() {
				
		return (GwtModel)SegmentModel.getInstance().getSegment(pathString).getModel().get(0); 
	}
	
	/**
	 * Get <b>Activities</b> from <em>GWT Model</em> // activities of the APP
	 * @return
	 */
	public EList<Activity> getActivities() {
		return ((GwtModel)SegmentModel.getInstance().getSegment(pathString).getModel().get(0)).getActivities();
	}
	
	/**
	 * Get <b>Places<b> from <em>GWT Model</em>// places of the APP
	 * @return
	 */
	public EList<Place> getPlaces() {
		return ((GwtModel)SegmentModel.getInstance().getSegment(pathString).getModel().get(0)).getPlaces();
	}
	
	
	/**
	 * Get <b>Pages</b> <em>GWT Model</em> // pages of the APP
	 * @return
	 */
	public EList<Page> getPages() {
		return ((GwtModel)SegmentModel.getInstance().getSegment(pathString).getModel().get(0)).getPages();
	}
	
	/**
	 * Get <b>ActivityMapper</b> <em>GWT Model</em> // ActivityMapper(Manager) of the APP
	 * @return
	 */
	public ActivityMapper getActivityMapper() {
		return (ActivityMapper)((GwtModel)SegmentModel.getInstance().getSegment(pathString).getModel().get(0)).getMapper().get(0);
	}
	

	/**
	 * Filter Only the only the place Only
	 * 
	 * @param gwtModel
	 * @return
	 */
	public List<String> getPlaceNames() {	
		return getPlaces().stream().map(e -> e.getName()).collect(Collectors.toList());
	}
	
	/**
	 * 
	 * Get Page By Name
	 * 
	 * @param pageName
	 * @return
	 */
	public Page getPageByName(String pageName) {
		return getPages().stream().filter(p -> p.getName().equals(pageName) ).collect(Collectors.toList()).get(0);
	}
	
	/**
	 * 
	 * Get Pages By Name
	 * 
	 * @param pageName
	 * @return
	 */
	public List<String> getPagesByName() {
		return getPages().stream().map(e -> e.getName()).collect(Collectors.toList());
	}
	
}
