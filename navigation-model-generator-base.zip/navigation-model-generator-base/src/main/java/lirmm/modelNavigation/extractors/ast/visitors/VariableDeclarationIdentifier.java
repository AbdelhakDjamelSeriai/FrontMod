package main.java.lirmm.modelNavigation.extractors.ast.visitors;

import java.util.ArrayList;
import java.util.List;

import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class VariableDeclarationIdentifier extends VoidVisitorAdapter<Void> {
	
	List<VariableDeclarationExpr> variableDeclarationExprs = new ArrayList<>();
	
	@Override
    public void visit(VariableDeclarationExpr md, Void arg) {
    	
        super.visit(md, arg);
        
        variableDeclarationExprs.add(md);
        
        
    }
	
	
	public List<VariableDeclarationExpr> getVariableDeclarationExprs(){
		return this.variableDeclarationExprs;
	}
}
