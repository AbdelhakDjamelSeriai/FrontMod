package main.java.lirmm.modelNavigation.extractors.ast.visitors;

import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class IfStmtIdentifier extends VoidVisitorAdapter<Void>{

	
}
