package main.java.lirmm.modelNavigation.extractors.java;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;


public class MethodHandlerContentAnalyzer {
	
	/**
	 * 
	 */
	private static MethodHandlerContentAnalyzer uniqueInstance;
	
	
	/**
	 * 
	 */
	private MethodHandlerContentAnalyzer() {
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static MethodHandlerContentAnalyzer getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new MethodHandlerContentAnalyzer();
		}
		return uniqueInstance;
	}
	
	/**
	 * 
	 * @param methodDeclaration
	 * @return
	 */
	private List<Statement> getAllStatementOfHandlerMethod(MethodDeclaration methodDeclaration) {
		
		if (methodDeclaration != null) {
			return StatementExtractor.getInstance().getAllStatementOfGivenBlock(methodDeclaration.getBody());
		}
		return null;
	}
	
	/**
	 * 
	 * @param methodDeclaration
	 * @return
	 */
	public List<MethodInvocation> getAllMethodInvocations(MethodDeclaration methodDeclaration) {
		
		List<Statement> statements = getAllStatementOfHandlerMethod(methodDeclaration);
		
		
	    return MethodInvocationExtractor.getInstance().getMethodInovcationsFromStatements(statements);
		
	}
	
	/**
	 * Get All Arguments Inside MethodInvocation
	 * @param methodDeclaration
	 * @return
	 */
	public List<Expression> getAllArguments(MethodDeclaration methodDeclaration) {
		List<MethodInvocation> methodInvocations = getAllMethodInvocations(methodDeclaration);
		
		List<Expression> arguments = new ArrayList<>();
		
		if (methodInvocations != null) {
			for(MethodInvocation methodInvocation: methodInvocations) {
				if (!methodInvocation.getArguments().isEmpty()) {
					arguments.addAll(methodInvocation.getArguments());
				}
			}
			
			return arguments;
		}
		
		
		return null;
	}
	
	
	/**
	 * Get All Variable Declaration Statements From Method Declaration;
	 * @param methodDeclaration
	 * @return
	 */
	public List<VariableDeclarationStatement> getAllVariableDeclarationStatements(MethodDeclaration methodDeclaration){
		
		List<Statement> statements = getAllStatementOfHandlerMethod(methodDeclaration);
		
		List<VariableDeclarationStatement> variableDeclarationStatements = new ArrayList<>(); 
		
		if (statements!=null) {
			for(Statement statement: statements) {
				if (statement instanceof VariableDeclarationStatement) {
					variableDeclarationStatements.add((VariableDeclarationStatement)statement);
				}
			}
			return variableDeclarationStatements;
		}
		
		
		return null;
	}
	
	
	
	
	
	
}
