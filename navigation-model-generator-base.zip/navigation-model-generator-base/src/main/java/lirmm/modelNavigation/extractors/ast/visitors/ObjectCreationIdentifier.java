package main.java.lirmm.modelNavigation.extractors.ast.visitors;


import java.util.ArrayList;
import java.util.List;

import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class ObjectCreationIdentifier extends VoidVisitorAdapter<Void>{
	
	List<ObjectCreationExpr> objects = new ArrayList<>();
	
	
	@Override
    public void visit(ObjectCreationExpr md, Void arg) {
    	
        super.visit(md, arg);
        
        objects.add(md);
        
        System.out.println("Method Name Printed: " + md.getArguments());
        
    }
	
	
	public List<ObjectCreationExpr> getObjectCreation(){
		return this.objects;
	}
	
	

}
