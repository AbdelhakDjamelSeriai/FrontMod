package main.java.lirmm.modelNavigation.extractors.java;


import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.AbstractMethodDeclaration;
import org.eclipse.gmt.modisco.java.BodyDeclaration;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.VariableDeclaration;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

public class MethodDeclarationExtractor {
	
	
	/**
	 * 
	 */
	private static MethodDeclarationExtractor uniqueInstance;
	
	/**
	 * 
	 */
	private MethodDeclarationExtractor() {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public static MethodDeclarationExtractor getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new MethodDeclarationExtractor();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * 
	 * @param classDeclaration
	 * @param methodName
	 * @return
	 */
	public MethodDeclaration getMethodDeclarationFromClassDeclaration(ClassDeclaration classDeclaration, 
			String methodName) {
		
		EList<BodyDeclaration> bodyDeclarations = classDeclaration.getBodyDeclarations();
		MethodDeclaration methodDeclaration = null;
		
		for (BodyDeclaration bodyDeclaration: bodyDeclarations) {
		
			if ((bodyDeclaration instanceof MethodDeclaration) && (((MethodDeclaration)bodyDeclaration)
					.getName().equals(methodName) )) {
				methodDeclaration = ((MethodDeclaration)bodyDeclaration);
			}
		}
		
		return methodDeclaration;
	}
	
	/**
	 * 
	 * @param classDeclaration
	 * @return
	 */
	public List<AbstractMethodDeclaration> getAllMethodOfClass(ClassDeclaration classDeclaration) {
		return getAbstractMethodDeclarations(classDeclaration);
	}
	
	/**
	 * 
	 * @param bodyDeclarations
	 * @return
	 */
	public List<AbstractMethodDeclaration> getAbstractMethodDeclarations(
			ClassDeclaration classDeclaration) {
		
		List<AbstractMethodDeclaration> abstractMethodDeclarations = new ArrayList<>();
		if (classDeclaration!=null) {
			for(BodyDeclaration bodyDeclaration: classDeclaration.getBodyDeclarations()) {
				if(bodyDeclaration instanceof AbstractMethodDeclaration) {
					abstractMethodDeclarations.add((AbstractMethodDeclaration)bodyDeclaration);
				}
			}
			return abstractMethodDeclarations;
		}
		
		return null;
		
	}
	
	/**
	 * 
	 * @param methodDeclaration
	 * @return
	 */
	public VariableDeclaration getReturnStatementFromAMethod(MethodDeclaration methodDeclaration) {
		
		EList<Statement> statements = methodDeclaration.getBody().getStatements();
		VariableDeclaration variable = null;
		for (Statement statement: statements) {
			if ((statement instanceof ReturnStatement) && ( ((ReturnStatement)statement)
					.getExpression() instanceof SingleVariableAccess )){
				variable = ((SingleVariableAccess)((ReturnStatement)statement).getExpression()).getVariable();

			}
		}
		return variable;	
	}
	
	/**
	 * get List Of Variable Declaration Statement From Method Declaration
	 * 
	 * @param methodDeclaration
	 * @return
	 */
	public EList<VariableDeclarationStatement> getVariableDeclarationList(MethodDeclaration methodDeclaration) {	
		EList<Statement> statements = methodDeclaration.getBody().getStatements();
		EList<VariableDeclarationStatement> variableDeclarationList = new BasicEList<>();
		
		for (Statement s: statements) {
			if (
					(s instanceof VariableDeclarationStatement) 
				) {
				variableDeclarationList.add((VariableDeclarationStatement)s);
			}
		}
		return variableDeclarationList;	
	}
	
	/**
	 * get Start method from Activity
	 * @param activity
	 * @return
	 */
	public MethodDeclaration getMethod(ClassDeclaration classDeclaration, String methodName) {	
		
		EList<BodyDeclaration>	bodyDeclarations = classDeclaration.getBodyDeclarations();		
		MethodDeclaration method  = null;	
		for (BodyDeclaration bodyDeclaration: bodyDeclarations) {	
			if ((bodyDeclaration instanceof MethodDeclaration) && (((MethodDeclaration)bodyDeclaration)
					.getName().equals(methodName) )) {
				method =  ((MethodDeclaration)bodyDeclaration);
			}
		}	
		return method;	
	}
	
	/**
	 * 
	 * @param bodyDeclarations
	 * @return
	 */
	public List<MethodDeclaration> getMethodDeclarations(EList<BodyDeclaration> bodyDeclarations) {
		
		List<MethodDeclaration> methodDeclarations = new ArrayList<>(); 
		
		for(BodyDeclaration bodyDeclaration: bodyDeclarations) {
			if (bodyDeclaration instanceof MethodDeclaration) {
				methodDeclarations.add((MethodDeclaration)bodyDeclaration);
			}
		}
		return methodDeclarations;
	}
	
	/**
	 * 
	 * @param methodDeclarations
	 * @param methodName
	 * @return
	 */
	public MethodDeclaration getMethodIfItStartsWith(EList<BodyDeclaration> bodyDeclarations, String startsWith) {
		
		for (MethodDeclaration method: getMethodDeclarations(bodyDeclarations)) {
			if (method.getName().startsWith(startsWith)) {
				return method;
			}
		}
		return null;
	}
	
	
	
		
}
