package main.java.lirmm.modelNavigation.extractors.java;

import java.util.List;
import java.util.stream.Collectors;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;

public class HandlerExtractor {
	
	
	/**
	 * 
	 */
	private static HandlerExtractor uniqueInstance;
	
	
	/**
	 * 
	 */
	private HandlerExtractor() {
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static HandlerExtractor getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new HandlerExtractor();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * 
	 * @param expr
	 * @return
	 */
	public MethodCallExpr getHandler(ObjectCreationExpr expr) {
		
		Node parent = expr.getParentNode().get();
		
		boolean check = false;
		
		while(!check) {
			
			if (	
					(parent instanceof MethodCallExpr) 
					&& ( ( (MethodCallExpr) parent ).getName().getIdentifier().endsWith("Handler") 
					&& (( (MethodCallExpr) parent ).getName().getIdentifier().startsWith("add") ) ) 
				) {
				
				check = true;
				
			} else {
				
				parent = parent.getParentNode().get();
				
			}
			
		}
		
		return (MethodCallExpr)parent;
	}
	
	
	/**
	 * 
	 * @param methodCallExpr
	 * @return
	 */
	public String getMethodName(MethodCallExpr methodCallExpr) {
			
		return methodCallExpr.getName().getIdentifier();
	}
	
	
	/**
	 * 
	 * @param creationExprsFiltered
	 * @return
	 */
	public List<MethodCallExpr> getHandlersMethod(List<ObjectCreationExpr> creationExprsFiltered) {
		
		return creationExprsFiltered.stream().map(e -> getHandler(e) ).collect(Collectors.toList());
	
	}
}
