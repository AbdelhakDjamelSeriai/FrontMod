package main.java.lirmm.modelNavigation.extractors.kdm;

import kdm.code.ClassUnit;

public class Facade {
	

	/**
	 * 
	 */
	private static Facade uniqueInstance;
	
	
	/**
	 * 
	 */
	private Facade() {
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static Facade getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new Facade();
		}
		return uniqueInstance;
	}
	
	
	
	
	
	
	public String getStringPathOfClassUnit(ClassUnit classUnit) {
		
		String path = null;
		
		if ((classUnit.getSource().size()!= 0) && (classUnit.getSource().get(0).getRegion().size()!=0)) {
			
			path = classUnit.getSource().get(0).getRegion().get(0).getFile().getPath();
		}
		
		return path;
	}

}
