package main.java.lirmm.modelNavigation.extractors.ast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.VariableDeclaration;

import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;

import kdm.code.gwt.Activity;
import kdm.code.gwt.Page;
import kdm.code.gwt.Place;
import main.java.lirmm.modelNavigation.extract.kdm.pagesLinkedWithActivities.ActivityModifier;
import main.java.lirmm.modelNavigation.extract.kdm.placesLinkedWithActivities.PlacesActivities;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.java.HandlerExtractor;
import main.java.lirmm.modelNavigation.extractors.java.Helper;
import main.java.lirmm.modelNavigation.extractors.java.MethodDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.Facade;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;

public class GraphPage {
	
	
	
	/**
	 * 
	 */
	private static GraphPage uniqueInstance;
	
	
	/**
	 * 
	 */
	private GraphPage() {
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static GraphPage getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new GraphPage();
		}
		return uniqueInstance;
	}
	
	
	
	
	public String getScopHandler(MethodCallExpr expr) {
		
		String scopHandlerName = null;
		
		if (expr.getScope().isPresent()) {
			
			 //checks if the scope of the method being called
			 if (expr.getScope().get() instanceof MethodCallExpr) {
				 
				 scopHandlerName = expr.getScope().get().asMethodCallExpr().getNameAsString();
				 
			 } else 
				 //checks if the scope of the var 
				 if (expr.getScope().get() instanceof NameExpr) {
				 
				 scopHandlerName = expr.getScope().get().asNameExpr().getNameAsString();
			 }
		}
		
		return scopHandlerName;
	}
	
	
	
	 
	public List<List<String>> getHandlerElementCallMap(
			Page page, Activity activity, List<String> placesNames, Map<Place, Activity> placeActivityMap, Map<Page, Activity> pageActivityMap
			) 
	{
		
		String FILE_PATH = Facade.getInstance().getStringPathOfClassUnit(activity);

		List<ObjectCreationExpr> placesInActivity = Helper.getInstance().getPlacesInActivity((new ASTParser(FILE_PATH)).getObjectCreation() , placesNames);
		
		List<List<String>> handlerPlaceElementList = new ArrayList<>();
		
		
		
		for (ObjectCreationExpr place: placesInActivity) {
			
			List<String> lists = new ArrayList<>();
			
			
			MethodCallExpr addregexHandler = HandlerExtractor.getInstance().getHandler(place); //// get add**Handler that have inside logic UI
			
			/**
			 *  add the method Handler
			 */
			String addRegexHandlerName = HandlerExtractor.getInstance().getMethodName(addregexHandler); //// get the Name of Handler Method
			lists.add(addRegexHandlerName);
			
			String objectThatCallHandlerName = getScopHandler(addregexHandler); //// get the Name of Object That Call Handler  
			/*lists.add(objectThatCallHandlerName);*/
			
			
			
			/**
			 * add the widget name how make event
			 */
			String widgetCallerName = searchForWidgetNameOnPage(page, objectThatCallHandlerName); //// get the Name widget Caller 
			lists.add(widgetCallerName);
			
			/**
			 * add Name Of Place
			 */
			String placeName = place.getTypeAsString();
			lists.add(placeName);
			
			/**
			 * add token of page
			 */
			String token = customizeUrlForAngularComponent(place);			
			lists.add(token);
			
			/**
			 * Next Page
			 */
			String nextPage = getPageCorrespondToPlaceName(placeName, placeActivityMap, pageActivityMap);
			lists.add(nextPage);
			
		
			// added to list 
			handlerPlaceElementList.add(lists);
			
		}
		
		
		
		
		return handlerPlaceElementList;
	}
	
	
	public String getPageCorrespondToPlaceName(String placeName, Map<Place, Activity> placeActivityMap, Map<Page, Activity> pageActivityMap) {
		
		Activity correspondedActivity = null;
		String correspondedPageName = "";
		
		for(Map.Entry<Place, Activity> entry : placeActivityMap.entrySet()) {
			if (placeName.equals(entry.getKey().getName())) {
				correspondedActivity = entry.getValue();
				break;
			}
		}
		
		for (Map.Entry<Page, Activity> entry : pageActivityMap.entrySet()) {
			if(correspondedActivity.getName().equals(entry.getValue().getName())) {
				correspondedPageName = entry.getKey().getName();
			}
		}
		
		return correspondedPageName;
	}
	
	
	public String  customizeUrlForAngularComponent(ObjectCreationExpr place) {
		
		String token = null;
		
		if ( ! place.getArgument(0).toString().contains(":") ) {
			
			token = place.getArgument(0).toString();
		
		} else {
			String debut = place.getArgument(0).toString().replace(":", "/:id");
			StringTokenizer stk = new StringTokenizer(debut, "\"");
			token = "\""+stk.nextToken() + "\"";
			
		}
		 
		
		return token;
	}
	
	
	
	public String searchForWidgetNameOnPage(Page page, String funcThatCallHandlerOnActivity) {
		
		ClassDeclaration pageDeclaration = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(page);
	
		MethodDeclaration methodDeclaration = MethodDeclarationExtractor.getInstance().getMethodDeclarationFromClassDeclaration(pageDeclaration, funcThatCallHandlerOnActivity);
		
		VariableDeclaration variableDeclaration = MethodDeclarationExtractor.getInstance().getReturnStatementFromAMethod(methodDeclaration);
		
		return variableDeclaration.getName();
	}
	
	
	
	public Map<String, List<List<String>>> getGraphResult() {
		
	
		EList<Activity> activities = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities();
		
		EList<Page> pages = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPages();
		
		EList<Place> places = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPlaces();
		
		ClassDeclaration mapperActivity = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(
				
				GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivityMapper()
				
		);
		
		/**
		 * Map for Place, Activity 
		 */
		Map<Place, Activity> placeActivityMap = (new PlacesActivities(activities, places, mapperActivity)).getPlaceActivities();
	
		/**
		 * Map for Page, Activity
		 */
		Map<Page, Activity> pageActivityMap = ActivityModifier.getInstance().getPageActivityMap(activities, pages);
		
		
		List<String> placesNames = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPlaceNames(); 
		
		
		Map<String, List<List<String>>> graphResult = new HashMap<String, List<List<String>>>();
			
		
		for(Map.Entry<Page, Activity> entry : pageActivityMap.entrySet()) {
			
			List<List<String>> list = getHandlerElementCallMap(entry.getKey(), entry.getValue(), placesNames, placeActivityMap, pageActivityMap);

			graphResult.put(entry.getKey().getName(), list);
		}
		
		return graphResult;
	}
	
}
