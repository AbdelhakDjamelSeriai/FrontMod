package main.java.lirmm.modelNavigation.extractors.ast;

import java.io.FileInputStream;
import java.util.List;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;

import main.java.lirmm.modelNavigation.extractors.ast.visitors.AddHandlerExperIdentifier;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.MethodCallsIdentifier;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.MethodDeclarationIdentifier;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.ObjectCreationIdentifier;


public class ASTParser {
	
	public CompilationUnit cu;
	
	public ObjectCreationIdentifier vistor;
	
	public AddHandlerExperIdentifier addHandlerExperIdentifier;
	
	public MethodDeclarationIdentifier methodDeclarationIdentifier;
	
	public MethodCallsIdentifier methodCallsIdentifier;
	
	
	public ASTParser(String filePath) {
		try {			
	        cu = StaticJavaParser.parse(new FileInputStream(filePath));	        
		} catch (Exception e) {		
			e.getStackTrace();	
		}
	}
	
	public List<ObjectCreationExpr> getObjectCreation(){
		vistor = new ObjectCreationIdentifier();
		vistor.visit(cu, null);
		return vistor.getObjectCreation();
	}
	
	public List<MethodCallExpr> getAddHandlerExper(){
		addHandlerExperIdentifier = new AddHandlerExperIdentifier();
		addHandlerExperIdentifier.visit(cu, null);
		return addHandlerExperIdentifier.getCallExprs();
	}
	
	public List<MethodDeclaration> getMethodDeclarations(){
		methodDeclarationIdentifier = new MethodDeclarationIdentifier();
		methodDeclarationIdentifier.visit(cu, null);
		return methodDeclarationIdentifier.getMethodDeclarations();
	}
	
	public List<MethodCallExpr> getMethodCallExpr(){
		methodCallsIdentifier = new MethodCallsIdentifier();
		methodCallsIdentifier.visit(cu, null);
		return methodCallsIdentifier.getMethodCalls();
	}
	
	
	
	
	
	
	
	
	
	 
	
	
	
	
	
	
	
	
	
}
