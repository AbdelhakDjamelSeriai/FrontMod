package main.java.lirmm.modelNavigation.visitors.arguments;

import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.Expression;

public class ClassInstanceCreationExpression implements CoverExpressionInArguments{
	
	
	public ClassInstanceCreationExpression() {
		//
	}
	
	@Override
	public String accept(Expression expression ,ExpressionInspector vInspector) {
		
		if (expression instanceof ClassInstanceCreation) {
			return vInspector.visit((ClassInstanceCreation)expression);
		}
		
		return null;
	}

}
