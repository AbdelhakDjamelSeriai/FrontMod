package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;

import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.domains.Transition;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.java.MethodInvocationExtractor;


public class HandlersListenersIterator {
		
	NextPageService service;
	
	List<Page> pages;
	
	ClassDeclarationExtractor classDeclarationExtractor;
	
	public HandlersListenersIterator(List<Page> pages, NextPageService service, 
			ClassDeclarationExtractor classDeclarationExtractor) {
		this.classDeclarationExtractor = classDeclarationExtractor;
		this.pages = pages;
		this.service = service;
	}
	
	
	public List<Transition> createTransitions() {
		
		List<Transition> transitions = new ArrayList<>();
		
		for(Page page: pages) {
			
			ClassDeclaration declaredPage = classDeclarationExtractor.getClassDeclaration(page);
			
			
			List<MethodInvocation> methodInvocations = MethodInvocationExtractor.getInstance().getHandlers(declaredPage) ;
			
		
				for (MethodInvocation methodInvocation : methodInvocations) {

					service.setMethodHandler(methodInvocation);
					
					if (service.getNextPageName() != null) {	
						
						Transition transition = 
						new Transition(page.getName(), service.getByElement(), service.getNextPageName() );
						transitions.add(transition);
					}
				}
			}
			
		return transitions;
	}

}
