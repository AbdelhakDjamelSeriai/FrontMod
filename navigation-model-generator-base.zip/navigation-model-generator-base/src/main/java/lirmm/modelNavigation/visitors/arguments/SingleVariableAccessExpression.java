package main.java.lirmm.modelNavigation.visitors.arguments;

import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;

public class SingleVariableAccessExpression implements CoverExpressionInArguments{
	
	
	public SingleVariableAccessExpression() {
		//
	}
	
	@Override
	public String accept(Expression expression, ExpressionInspector vInspector) {
		
		if (expression instanceof SingleVariableAccess) {	
			return vInspector.visit((SingleVariableAccess)expression);
		}
		
		return null;
	}

}
