package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.List;

import org.eclipse.gmt.modisco.java.MethodInvocation;


public class MethodInvocationInstance implements Acceptor{
	
	
	private List<MethodInvocation> methodInvocations;
		
	public MethodInvocationInstance(List<MethodInvocation> methodInvocations) {
		this.methodInvocations = methodInvocations;
	}
	
	
	@Override
	public String accept(Visitor visitor) {	
		return visitor.visitMethodInvocation(methodInvocations);
	}

}
