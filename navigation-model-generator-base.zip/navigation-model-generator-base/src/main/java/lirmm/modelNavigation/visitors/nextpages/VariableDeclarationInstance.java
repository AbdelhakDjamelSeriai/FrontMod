package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.List;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;


public class VariableDeclarationInstance implements Acceptor{
	
	private List<VariableDeclarationStatement> variableDeclarationStatements;
	
	public VariableDeclarationInstance(List<VariableDeclarationStatement> variableDeclarationStatements) {
		this.variableDeclarationStatements = variableDeclarationStatements;
	}
	
	@Override
	public String accept(Visitor visitor) {		
		return visitor.visitVariableDeclaration(variableDeclarationStatements);
	}

}
