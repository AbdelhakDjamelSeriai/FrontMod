package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.List;

import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

public interface Visitor {
	
	String visitArgument(List<Expression> expressions);
	
	String visitVariableDeclaration(List<VariableDeclarationStatement> variableDeclarationStatements);
	
	String visitMethodInvocation(List<MethodInvocation> methodInvocations);
}
