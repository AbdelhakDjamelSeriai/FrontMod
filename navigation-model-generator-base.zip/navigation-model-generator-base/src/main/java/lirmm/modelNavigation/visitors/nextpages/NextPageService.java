package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extractors.interfaces.HandlerInterface;
import main.java.lirmm.modelNavigation.extractors.java.Helper;
import main.java.lirmm.modelNavigation.visitors.arguments.IHelper;



public class NextPageService {
	
	
	private Acceptor[] acceptors;
		
	private List<Expression> expressions;
	
	private List<MethodInvocation> methodInvocationsHaveBody;
	
	private List<VariableDeclarationStatement> variableDeclarationStatements;
	
	private HandlerInterface handlerInterface;
	
	private List<String> listPages;
	
	private MethodInvocation methodInvocation;
	
	/**
	 * 
	 * @param handlerInterface
	 */
	public NextPageService(HandlerInterface handlerInterface, List<String> listPages) {
		this.handlerInterface = handlerInterface;
		this.listPages = listPages;
	}
	
	public NextPageService(HandlerInterface handlerInterface) {
		this.handlerInterface = handlerInterface;
	}
	
	public void setPages(List<String> pages) {
		this.listPages = pages;
	}
	
	/**		**/
	public void setMethodHandler(MethodInvocation methodInvocation) {
		
		this.methodInvocation = methodInvocation;
		
		MethodDeclaration methodHandler = handlerInterface.getMethodDeclarationHandler(methodInvocation);
		

		expressions = handlerInterface.getAllExpressionOfMethodHandler(methodHandler);
			
		
		
		variableDeclarationStatements = handlerInterface.getAllVariableDeclarationStatementsOfMethodHandler(methodHandler);
		
		methodInvocationsHaveBody = handlerInterface.getAllMethodInvocationsOfMethodHandler(methodHandler);
		
		acceptors = new Acceptor[] {
				new InjectedInstance(expressions), 
				new VariableDeclarationInstance(variableDeclarationStatements),
				new MethodInvocationInstance(methodInvocationsHaveBody)
		};
	}
	
	
	/*
	 *
	 * @param listPages 
	 * 
	 * @return
	 * */
	public String getNextPageName() {
		// 1- get All pages 
				// 2- for, each page ,do :
		        //<----------------------------------------------------------->
				//    2.1 - get it's class declaration
				//    2.2 - get All listeners in this class declaration
		  		//<----------------------------------------------------------->
				//    2.3 -  for, each listeners ,do:
		        //<----------------------------------------------------------->
				//           2.4 - get all arguments in method invocation 
				//           2.5 - apply the visitros on the collection
				//<----------------------------------------------------------->
		
		//NextPageVisitor( List<String> namePages, IHelper helper)		
		IHelper helper =  Helper.getInstance();		
		Visitor visitor = new NextPageVisitor(listPages, helper, handlerInterface);		
		for (Acceptor acceptor: acceptors) {			
			String state = acceptor.accept(visitor);
		    if ( state != null) {		    	
		       return state;	 
		    }		    
		}		
		return null;
	}
	
	
	/**
	 * 
	 * @param methodInvocation
	 * @return
	 */
	public String getByElement() {	
	  return handlerInterface.getElementHowCallInvokedMethod(methodInvocation);
	}
	
	
	
	
	
	

}
