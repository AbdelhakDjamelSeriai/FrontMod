package main.java.lirmm.modelNavigation.visitors.arguments;

import org.eclipse.gmt.modisco.java.Expression;

public interface CoverExpressionInArguments {
	
	String accept(Expression expression, ExpressionInspector vInspector);
	
}
