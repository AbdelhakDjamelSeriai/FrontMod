package main.java.lirmm.modelNavigation.visitors.nextpages;

public interface Acceptor {
	
	public String accept(Visitor visitor);
}
