package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.List;
import org.eclipse.gmt.modisco.java.Expression;

public class InjectedInstance implements Acceptor {
	
	private List<Expression> expression ;
	
	public InjectedInstance(List<Expression> expression) {
		this.expression = expression;
	}
		
	@Override
	public String accept(Visitor visitor) {				
		return visitor.visitArgument(expression);
	}

}
