package main.java.lirmm.modelNavigation.visitors.arguments;

import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;

public interface ExpressionInspector {
	
	/* An expression Inspector is supposed to visit all the expression stored in arguments and get the next
    page if exists. */
	
	String visit(ClassInstanceCreation classInstanceCreation);
	
	String visit(SingleVariableAccess singleVariableAccess);
	
	String visit(MethodInvocation methodInvocation);
	
	String visit(ReturnStatement returnStatement);

}
