package main.java.lirmm.modelNavigation.visitors.arguments;

import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodInvocation;

public class MethodInvocationExpression implements CoverExpressionInArguments{
	
	
	
	public MethodInvocationExpression() {
		///
	}
	
	
	@Override
	public String accept(Expression expression, ExpressionInspector vInspector) {
		
		if (expression instanceof MethodInvocation) {
			
			return vInspector.visit((MethodInvocation)expression);
		}
		
		return null;
	}
}
