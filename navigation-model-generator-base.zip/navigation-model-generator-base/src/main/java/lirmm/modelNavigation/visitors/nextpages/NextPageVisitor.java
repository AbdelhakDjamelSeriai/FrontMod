package main.java.lirmm.modelNavigation.visitors.nextpages;

import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

import main.java.lirmm.modelNavigation.extractors.interfaces.HandlerInterface;
import main.java.lirmm.modelNavigation.visitors.arguments.ClassInstanceCreationExpression;
import main.java.lirmm.modelNavigation.visitors.arguments.CoverExpressionInArguments;
import main.java.lirmm.modelNavigation.visitors.arguments.ExpressionInspection;
import main.java.lirmm.modelNavigation.visitors.arguments.ExpressionInspector;
import main.java.lirmm.modelNavigation.visitors.arguments.IHelper;
import main.java.lirmm.modelNavigation.visitors.arguments.MethodInvocationExpression;
import main.java.lirmm.modelNavigation.visitors.arguments.SingleVariableAccessExpression;


public class NextPageVisitor implements Visitor{
	
	//private List<String> namePages;
	
	ExpressionInspector inspector;
	
	HandlerInterface handlerInterface ;

	
	CoverExpressionInArguments[] coverExpressions = new CoverExpressionInArguments[] {
			new ClassInstanceCreationExpression(), 
			new MethodInvocationExpression(), 
			new SingleVariableAccessExpression()
			
	};
	
	
	public NextPageVisitor( List<String> namePages, IHelper helper ,HandlerInterface handlerInterface) {
		inspector = new ExpressionInspection(namePages, helper);
		this.handlerInterface = handlerInterface;
	}
	
	@Override
	public String visitArgument(List<Expression> expressions) {
		
		if (expressions != null) {
			for(CoverExpressionInArguments coverExpression: coverExpressions) {
				
				for(Expression expression: expressions) {
				   if ( coverExpression.accept(expression, inspector) != null ) {
					   return coverExpression.accept(expression, inspector);
				   }
				}
			}
		}
		
		
		return null;
	}
	
	
	@Override
	public String visitVariableDeclaration(
			List<VariableDeclarationStatement> variableDeclarationStatements
	) {
		
		if (variableDeclarationStatements!=null) {
			List<Expression> initializers = variableDeclarationStatements.stream().filter(e -> e.getFragments().get(0).getInitializer()!= null)
					.map(e -> e.getFragments().get(0).getInitializer()).collect(Collectors.toList());
			return visitArgument(initializers);
		}
		return null;
	}
	
	@Override
	public String visitMethodInvocation(List<MethodInvocation> methodInvocations) {
		
		if (methodInvocations!=null) {
			for(MethodInvocation methodInvocation: methodInvocations) {
				

				if ( (methodInvocation.getMethod() instanceof MethodDeclaration) && (methodInvocation.getMethod()!= null) ) {
					MethodDeclaration methodDeclaration = (MethodDeclaration)methodInvocation.getMethod();
									
					if (visitArgument(handlerInterface.getAllExpressionOfMethodHandler(methodDeclaration)) != null) {
						
						return visitArgument(handlerInterface.getAllExpressionOfMethodHandler(methodDeclaration));
					}
					
					return visitMethodInvocation( handlerInterface.getAllMethodInvocationsOfMethodHandler(
							(MethodDeclaration)methodInvocation.getMethod()
							) );
					
				}
				
			}
		}
		
		
		return null;
	}

}
