package main.java.lirmm.modelNavigation.visitors.arguments;

import java.util.List;

import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.ReturnStatement;

public interface IHelper {
	
	/*
	 * We Inject Method Invocation after that 
	 * We Get Method Declaration after that 
	 * We Get Body --> Statements --> Only ::ReturnStatement::  
	 * */
	public List<ReturnStatement> getAllReturnStatementsInsideMethod(MethodDeclaration mtd);

	//public List<Expression> getAllExpressionOfThisMethod(MethodInvocation methodInvocation);
	
	//public List<MethodInvocation> getAllMethodInvocationsOfThisMethod(MethodInvocation methodInvocation);
	
	
}
