package main.java.lirmm.modelNavigation.visitors.arguments;

import java.util.List;

import org.eclipse.gmt.modisco.java.AbstractMethodDeclaration;
import org.eclipse.gmt.modisco.java.Assignment;
import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;


public class ExpressionInspection implements ExpressionInspector{
	
	private List<String> namePages;
	
	private IHelper helper;
	
	public ExpressionInspection(List<String> namePages, IHelper helper) {
		this.namePages = namePages; 
		this.helper = helper;
	}
	
	@Override
	public String visit(ClassInstanceCreation classInstanceCreation) {
		
		if ( namePages.contains(classInstanceCreation.getMethod().getName()) ) {
			return classInstanceCreation.getMethod().getName();
		}
		
		return null;
	}
	
	@Override
	public String visit(MethodInvocation methodInvocation) {
		
		AbstractMethodDeclaration methodDeclaration = methodInvocation.getMethod();
		
		if ( ( methodDeclaration instanceof MethodDeclaration )  && ( methodDeclaration.getBody() != null )) {
			
		    List<ReturnStatement> returnStatements = 
		    		helper.getAllReturnStatementsInsideMethod( (MethodDeclaration)methodDeclaration );
			
		    for (ReturnStatement returnStatement: returnStatements ) {
		    	
		    	if (visit(returnStatement) != null) {
		    		return visit(returnStatement);
		    	}
		    }
		    
		}
		
		return null;
	}
	
	@Override
	public String visit(SingleVariableAccess singleVariableAccess) {
		
		Expression expression = singleVariableAccess.getVariable().getInitializer();
		
		if (expression instanceof ClassInstanceCreation ) {
			
		   return visit( (ClassInstanceCreation)singleVariableAccess.getVariable().getInitializer());
		   
		} else if (expression instanceof MethodInvocation) {
			
		   return visit( (MethodInvocation)expression );
		   
		} else if (
			singleVariableAccess.getVariable()
			.getUsageInVariableAccess()
			.stream()
			.filter( e -> e.eContainer() instanceof Assignment )
			.map(e-> e.eContainer() )
			.map(Assignment.class::cast)
			.anyMatch(e -> e.getRightHandSide() instanceof ClassInstanceCreation)
			) {
			
			expression = 
			singleVariableAccess.getVariable()
			.getUsageInVariableAccess()
			.stream().filter( e -> e.eContainer() instanceof Assignment )
			.map(e-> e.eContainer() )
			.map(Assignment.class::cast)
			.filter(e -> e.getRightHandSide() instanceof ClassInstanceCreation)
			.map( e -> e.getRightHandSide())
			.map(ClassInstanceCreation.class::cast)
			.findFirst().get();
			
			return visit( (ClassInstanceCreation)expression);
		}
		
		return null;
	}
	
	@Override
	public String visit(ReturnStatement returnStatement) {
		
		Expression expression = returnStatement.getExpression();
		
		if (expression instanceof ClassInstanceCreation) {
			
			return visit((ClassInstanceCreation)expression);
			
		} else if (expression instanceof MethodInvocation) {
			
		    return  visit((MethodInvocation)expression);
			
		} else if (expression instanceof SingleVariableAccess) {
			
		    return visit((SingleVariableAccess)expression);
			
		}
		
		return null;
	}
	

}
