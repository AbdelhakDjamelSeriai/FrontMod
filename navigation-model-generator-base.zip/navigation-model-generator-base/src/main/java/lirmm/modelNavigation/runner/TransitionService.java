package main.java.lirmm.modelNavigation.runner;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extractors.interfaces.HandlerInterface;
import main.java.lirmm.modelNavigation.extractors.interfaces.HandlerInterfaceImpl;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;
import main.java.lirmm.modelNavigation.factories.DotRulesCreator;
import main.java.lirmm.modelNavigation.factories.NavigationalModelCreator;
import main.java.lirmm.modelNavigation.visitors.nextpages.HandlersListenersIterator;
import main.java.lirmm.modelNavigation.visitors.nextpages.NextPageService;

public class TransitionService {
	
	
	

	
	
	

	
	public static void main(String[] args) throws IOException {
		
		System.out.println("------------------------------- We start transformation -------------------------------");

		// 1- get All pages 
		// 2- for, each page ,do :
		//    2.1 - get it's class declaration
		//    2.2 - get All listeners in this class declaration    
		//    2.3 -  for, each listeners ,do:
		//           2.4 - get all arguments in method invocation 
		//           2.5 - apply the visitros on the collection
		
		List<Path> gwtKdmModelPaths =  Files.walk(Paths.get("models/inputs/gwt-kdm-model")).filter(Files::isRegularFile).collect(Collectors.toList());
		List<Path> javaModelPaths = Files.walk(Paths.get("models/inputs/java-model")).filter(Files::isRegularFile).collect(Collectors.toList());
		
		GwtModelExtractor gwtModelExtractor = 
				GwtModelExtractor
				.getInstance( gwtKdmModelPaths.get(0).getFileName().toString()  );
		ClassDeclarationExtractor classDeclarationExtractor = ClassDeclarationExtractor
				.getInstance(javaModelPaths.get(0).getFileName().toString());
		
		List<Page> pages = gwtModelExtractor.getPages();
		
		List<String> namePages = gwtModelExtractor.getPagesByName();
		
		HandlerInterface handler = new HandlerInterfaceImpl();
		
		NextPageService service = new NextPageService(handler, namePages);
		
		HandlersListenersIterator iterator = new HandlersListenersIterator(pages, service,classDeclarationExtractor);
	   
		/**
		 * Create Navigation Model as JSON Model
		 */
		NavigationalModelCreator navigationalModelCreation = new NavigationalModelCreator(iterator.createTransitions());
		navigationalModelCreation.createNavigationalModelCreation();
		System.out.println(" Navigation Model has been create at: models/output/"  );

		/**
		 * Create Dot Rules 
		 */
		DotRulesCreator dotRulesCreation = new DotRulesCreator(iterator.createTransitions());
		dotRulesCreation.createTransitions();
		
		System.out.println(" Transformation Rules has been create at : models/output/"  );

		
		System.err.println("-------------------------------------------------------------------------------------");

	}

}
