package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;

import org.eclipse.gmt.modisco.java.Model;
import org.eclipse.gmt.modisco.java.Package;
import org.junit.jupiter.api.Test;

import main.java.lirmm.modelNavigation.extractors.java.PackageIdentifier;
import main.java.lirmm.modelNavigation.extractors.java.RootModel;



class PackageExtractorTest {

	@Test
	void can_get_specific_package_from_project() {
		
		Model rootModel = RootModel.getInstance().getJavaModelFromXMIFile("src/tests/features/dbExamples/mvp_java.xmi");
				
		Package client = PackageIdentifier.getInstance().getClientPackage(rootModel.getOwnedElements().get(0));
		
		Package componentOne = PackageIdentifier.getInstance().getPackagePageFromClientPackage(client,"placesAndactivities");
		
		assertEquals(componentOne.getName(), "placesAndactivities");
	}
	
	
	
	


}
