package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;


class PagesExtractorTest {

	@Test
	void can_get_pages() {	
		
		assertNotNull(GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPages());
	
	}

}
