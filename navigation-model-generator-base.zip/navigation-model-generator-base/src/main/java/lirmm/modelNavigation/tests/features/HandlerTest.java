package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.junit.jupiter.api.Test;

import com.github.javaparser.JavaParser;
import com.github.javaparser.JavaParserBuild;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.resolution.SymbolResolver;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.model.resolution.TypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import kdm.code.gwt.Activity;
import main.java.lirmm.modelNavigation.extractors.ast.ASTParser;
import main.java.lirmm.modelNavigation.extractors.ast.GraphPage;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.FilterFacade;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.MethodCallsIdentifier;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.VariableDeclarationIdentifier;
import main.java.lirmm.modelNavigation.extractors.java.HandlerExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;

class HandlerTest {

	@Test
	void checkIfCanGetAllAddHandlerForGivenClass() {
		
		Activity loginActivity = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities().get(1);
		
		String path = loginActivity.getSource().get(0).getRegion().get(0).getFile().getPath();

		List<MethodCallExpr> methodCallExpr = (new ASTParser(path).getAddHandlerExper());
		
		MethodCallExpr methodCall = methodCallExpr.get(0);
		
		/**
		 * Get The response !!
		 */
		MethodCallsIdentifier methodCallsIdentifier = new MethodCallsIdentifier();
		VariableDeclarationIdentifier variableDeclarationIdentifier = new VariableDeclarationIdentifier();
		
		methodCall.accept(methodCallsIdentifier, null);
		methodCall.accept(variableDeclarationIdentifier, null);
		
		String scopeName = "";
		
		if (FilterFacade.getInstance().itContainsClearAdd(methodCallsIdentifier.getMethodCalls())) {
			
			scopeName = GraphPage.getInstance().getScopHandler(methodCall);
		}
		 
		getDataElementFromHandler(methodCall);
		
				
		
		
		assertEquals( getDataElementFromHandler(methodCall).size(), 8	);
	}
	
	
	
	public List<String> getDataElementFromHandler(MethodCallExpr addhandler){
		List<String> data = new ArrayList<>();
		
		MethodCallsIdentifier methodCallsIdentifier = new MethodCallsIdentifier();
		VariableDeclarationIdentifier variableDeclarationIdentifier = new VariableDeclarationIdentifier();
		
		addhandler.accept(methodCallsIdentifier, null);
		addhandler.accept(variableDeclarationIdentifier, null);
		
		
		if (FilterFacade.getInstance().itContainsClearAdd(methodCallsIdentifier.getMethodCalls())) {
			
			/**
			 *  add the method Handler """ Method Handler """
			 */
			String addRegexHandlerName = HandlerExtractor.getInstance().getMethodName(addhandler); //// get the Name of Handler Method
			data.add(addRegexHandlerName);
			
			/**
			 *  add the widget Name	   """ Widget Name """
			 */
			String objectThatCallHandlerName =  GraphPage.getInstance().getScopHandler(addhandler); //// get the Name of Object That Call Handler  
			data.add(objectThatCallHandlerName);
			
			
			/**
			 * Get the add Method 	
			 */
			MethodCallExpr addMethod = FilterFacade.getInstance().getAddMethod(methodCallsIdentifier.getMethodCalls());
			
			/**
			 * add the NextPage ;
			 */
			
			data.add(getNextPage(addMethod, variableDeclarationIdentifier.getVariableDeclarationExprs()));
			
			/**
			 * add the fake token  """ Widget Name """
			 */
			data.add(getNextPage(addMethod, variableDeclarationIdentifier.getVariableDeclarationExprs()) + objectThatCallHandlerName);
			
			
		} else {
			
		}
		
		return data;
	}

	
	public String getNextPage(MethodCallExpr addMethod, List<VariableDeclarationExpr> variableDeclarationExprs) {
		
		Expression firstArgument = addMethod.getArgument(0); 
		
		String nextPageName = "" ;
		
		if (firstArgument.isMethodCallExpr()) {

		} else if ( firstArgument.isObjectCreationExpr()) {
			nextPageName = firstArgument.asObjectCreationExpr().getTypeAsString();

		} else if (firstArgument.isNameExpr()) {
			nextPageName = resolveTypeVar(variableDeclarationExprs, firstArgument.asNameExpr().getNameAsString());
		} 
		
		return nextPageName;
	}
	
	
	public String resolveTypeVar(List<VariableDeclarationExpr> variableDeclarationExprs , String nameExpr) {
		
		String typeName = "";
		
		
		if ( variableDeclarationExprs.stream().filter(e -> e.getVariable(0).getNameAsString().equals(nameExpr)).findFirst().isPresent() ) {	
			
			typeName = variableDeclarationExprs.stream().filter(e -> e.getVariable(0).getNameAsString().equals(nameExpr))
			.findFirst().get().getVariable(0).getTypeAsString();
			
		}
		
		return typeName;
	}
	
	

	
}
