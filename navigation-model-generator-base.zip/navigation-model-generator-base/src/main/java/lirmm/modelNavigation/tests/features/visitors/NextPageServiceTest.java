package main.java.lirmm.modelNavigation.tests.features.visitors;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extractors.interfaces.HandlerInterface;
import main.java.lirmm.modelNavigation.extractors.interfaces.HandlerInterfaceImpl;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.java.MethodHandlerExtractor;
import main.java.lirmm.modelNavigation.extractors.java.MethodInvocationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;
import main.java.lirmm.modelNavigation.visitors.nextpages.HandlersListenersIterator;
import main.java.lirmm.modelNavigation.visitors.nextpages.NextPageService;

class NextPageServiceTest {
	
	
	
	/*private Page page = GwtModelExtractor.getInstance("gwt-app-17_kdm_gwt.xmi").getPages().get(0);
	
	private List<String> namePages = GwtModelExtractor.getInstance("gwt-app-17_kdm_gwt.xmi").getPagesByName();
	
	private ClassDeclaration declaredPage = ClassDeclarationExtractor.getInstance("gwt-app-17_java.xmi").getClassDeclaration(page);*/
	

	
	/*@Test
	void we_can_get_next_page_name_from_add_handler() {
		
		
	
		MethodInvocation lastHandler = MethodInvocationExtractor.getInstance().getHandlers(declaredPage).get(0);

		/// l� tu peux traiter le deuxi�me cas !! 
		 
		MethodDeclaration methodDeclaration = MethodHandlerExtractor.getInstance().getHandlerMethod(lastHandler);
		
		HandlerInterface handler = new HandlerInterfaceImpl();
		
		NextPageService service = new NextPageService(handler, namePages);
		
		service.setMethodHandler(lastHandler);
		
		assertEquals("GreetingPanel", service.getNextPageName());
	}*/
	
	
	
	
	
	@Test
	void we_can_create_transition_from_project() {
		
		GwtModelExtractor gwtModelextractor = GwtModelExtractor.getInstance("gwt-app-1_kdm_gwt.xmi");
		
		ClassDeclarationExtractor classDeclarationExtractor = ClassDeclarationExtractor
				.getInstance("gwt-app-1_java.xmi");
		
		List<Page> pages = gwtModelextractor.getPages();
		
		List<String> namePages = gwtModelextractor.getPagesByName();
		
		HandlerInterface handler = new HandlerInterfaceImpl();
		
		NextPageService service = new NextPageService(handler, namePages);
		
		HandlersListenersIterator iterator = new HandlersListenersIterator(pages, 
				service,
				classDeclarationExtractor);
		
		assertEquals(3 , iterator.createTransitions().size());
	}

}
