package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.Activity;
import kdm.code.gwt.ActivityMapper;
import kdm.code.gwt.Place;
import main.java.lirmm.modelNavigation.extract.kdm.placesLinkedWithActivities.PlacesActivities;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;



class ActivityPlaceLinkerTest {

	@Test
	void can_we_link_place_activities() {
		

				
		EList<Activity> activities = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities(); 
		
		EList<Place> places = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPlaces();		
		
		ActivityMapper mapper = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivityMapper();
		
		ClassDeclaration activitymapper =  ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(mapper);
		
				
		PlacesActivities placesActivities = new PlacesActivities(activities, places, activitymapper);
		
		placesActivities.linkPlacesToActivities();
		
		//placesActivities.getPlaceActivities().forEach((key, value) -> System.out.println(key.getName() + " : " + value.getName()));

		assertEquals(placesActivities.getPlaceActivities().size(),2);
	}

}
