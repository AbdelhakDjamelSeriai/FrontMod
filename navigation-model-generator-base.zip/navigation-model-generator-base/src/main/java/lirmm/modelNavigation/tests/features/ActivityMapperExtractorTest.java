package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.ActivityMapper;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;



class ActivityMapperExtractorTest {

	@Test
	void we_can_extract_activity_mapper() {
			
		ActivityMapper activityMapper = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivityMapper();
		
		assertEquals(activityMapper.getName(), "MyActivityMapper");
		
	}
	
	
	
	
	
	
	
	

}
