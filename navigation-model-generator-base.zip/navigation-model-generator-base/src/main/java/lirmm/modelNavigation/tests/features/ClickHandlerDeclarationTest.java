package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream.PutField;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.GwtFactory;
import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.Page;
import kdm.code.gwt.Route;
import kdm.code.gwt.Widget;
import kdm.code.gwt.impl.RouteImpl;
import kdm.kdm.Segment;
import main.java.lirmm.modelNavigation.extractors.ast.GraphPage;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.SegmentModel;
import main.java.lirmm.modelNavigation.extractors.kdm.WidgetExtractor;


class ClickHandlerDeclarationTest {
	
	
	FileWriter file;
	
	
	@Test
	void can_we_can_get_handler_of_an_activity() {
		
		Map<String, List<List<String>>> map = GraphPage.getInstance().getGraphResult();
		System.out.println("________________________________________________________________________________________________________________________________________________________________________");
		System.out.println("|                           |                           |                           |                           |                           |                           |");
		System.out.println("|           Page            |        MethodHandler      |         Element           |           Place           |           Token           |     Next  Page            |");
		System.out.println("|___________________________|___________________________|___________________________|___________________________|___________________________|___________________________|");
		for (Entry<String, List<List<String>>> entry: map.entrySet()) {
			
			
			for (List<String> stringList: entry.getValue()) {
				
				String line = "";
				System.out.print("|"+entry.getKey() + IntStream.range(0, 27-entry.getKey().length()).mapToObj(i -> " ").collect(Collectors.joining("")));
				
				for(String string: stringList) {
					
				
				    String chunck = IntStream.range(0, 27-string.length()).mapToObj(i -> " ").collect(Collectors.joining(""));
					
					line +="|"+string+chunck;
				}
				System.out.println(line+"|");
				
				System.out.println("|___________________________|___________________________|___________________________|___________________________|___________________________|___________________________|");

			}
			
		}
		
		
		assertEquals(map.size(),2);
	
	}
	
	
	
	@Test
	void can_we_save_route_to_page() {
				
		Map<String, List<List<String>>> map = GraphPage.getInstance().getGraphResult();
		
		EList<Page> pages =  GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPages();
		
		Page page = null;
		
		for (Entry<String, List<List<String>>> entry: map.entrySet()) {			
			
		   page = pages.stream().filter( e -> e.getName().equals(entry.getKey()) ).findFirst().get();
		   
		   System.err.println(page.getName());

		   for (List<String> stringList: entry.getValue()) {
			   
			   Route route = getRoute(page.getRoutes(), stringList.get(1));
			   
			   if ( route != null ) {
				   
				   route.setName(stringList.get(3).substring(1, stringList.get(3).length()-1));
				   
				   System.err.println(stringList.get(3)); 
				   
				   route.setToken(stringList.get(3).substring(1, stringList.get(3).length()-1));
				   
				   route.setTo( pages.stream().filter( e -> e.getName().equals(stringList.get(4)) ).findFirst().get() ); 
			   
			   } 
			     
				    
			}
		   
		   
		}
		
		SegmentModel.getInstance().save();


		
		///assertEquals(route.getToken(),"Hello ");
		assertNull(null);
		
	}
	
	
	public Route getRoute(EList<Route> routes, String byName) {
		Route route = null;
		for (int i = 0 ; i < routes.size(); i ++) {
			if (routes.get(i).getBy().getName().equals(byName)) {
				route = routes.get(i);
			}
		}
		
		return route;
	}
	
	
	@Test
	void can_we_can_get_generte_of_json_graph() {
		
		Map<String, List<List<String>>> map = GraphPage.getInstance().getGraphResult();
		
		String[] keyProperties= {"MethodHandler","Element","Place","Token","NPage"};
		
		JSONObject pages = new JSONObject();

		for (Entry<String, List<List<String>>> entry: map.entrySet()) {
			JSONObject page = new JSONObject();

			//page.put("View", entry.getKey());

			JSONArray properties = new JSONArray();
			
			for (List<String> stringList: entry.getValue()) {
					
				JSONObject propertie = new JSONObject();
				int index = 0;
				for(String string: stringList) {
					
				 propertie.put(keyProperties[index], string);
				index++;
					
				}
				properties.put(propertie);
			}
			
			page.put("data", properties);
			pages.put(entry.getKey(), page);
		}
		
		toFileJson(pages);
	}
	
	
	@Test
	void can_we_can_get_generte_of_dot_rules() {
		
		Map<String, List<List<String>>> map = GraphPage.getInstance().getGraphResult();
		
		String template = "";
		
		String[] keyProperties= {"MethodHandler","Element","Place","Token","NPage"};
		
		JSONObject pages = new JSONObject();

		for (Entry<String, List<List<String>>> entry: map.entrySet()) {
			JSONObject page = new JSONObject();

			
			JSONArray properties = new JSONArray();
			
			for (List<String> stringList: entry.getValue()) {
				
				template += entry.getKey() + " -> " + stringList.get(3) + ";\n"; 	
			}
			
		}
		toFileTXT(template);
	}
	
	/**
	 * 
	 * @param template
	 */
	private void toFileJson(JSONObject template) {
		
		
		try {
			 
            // Constructs a FileWriter given a file name, using the platform's default charset
           file =  (new FileWriter("graph_call.json"));
           file.write(template.toString());
          
 
        } catch (IOException e) {
            e.printStackTrace();
 
        } finally {
 
            try {
                file.flush();
                file.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }		
	    }
	}
	
	/**
	 * 
	 * @param template
	 */
	private void toFileTXT(String template) {
		
		
		try {
			 
            // Constructs a FileWriter given a file name, using the platform's default charset
           file =  (new FileWriter("DotMvp.txt"));
           file.write(template.toString());
          
 
        } catch (IOException e) {
            e.printStackTrace();
 
        } finally {
 
            try {
                file.flush();
                file.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }		
	    }
	}
	
	
	
	
		
		

		
				

	
	
	
	

	
	
	
	
	

}
