package main.java.lirmm.modelNavigation.tests.features;


import static org.junit.jupiter.api.Assertions.assertEquals;


import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.ActivityMapper;
import main.java.lirmm.modelNavigation.extractors.ast.ASTParser;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;



class ParserTest {

	@Test
	void test() {
		
		ActivityMapper mapper = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivityMapper();	
		
		ClassDeclaration activitymapper =  ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(mapper);
		
		String FILE_PATH = activitymapper.getOriginalCompilationUnit().getOriginalFilePath();
		
		int k = (new ASTParser(FILE_PATH)).getObjectCreation().size();
		
				
		assertEquals(k, 3);
	}
	
	

}
