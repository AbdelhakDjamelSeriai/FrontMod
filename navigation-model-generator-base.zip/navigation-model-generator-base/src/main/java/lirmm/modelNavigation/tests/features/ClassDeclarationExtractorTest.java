package main.java.lirmm.modelNavigation.tests.features;


import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;

class ClassDeclarationExtractorTest {

	@Test
	void can_extract_class_declaration() {
				
		Page page = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPages().get(0);
		
			
		assertEquals(ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(page).getName(),"LoginView");
	}
	
	
	

}
