package main.java.lirmm.modelNavigation.tests.features.visitors;

import static org.junit.jupiter.api.Assertions.*;


import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extractors.java.ClassDeclarationExtractor;
import main.java.lirmm.modelNavigation.extractors.java.MethodInvocationExtractor;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;

class AddHandlerExtractorTest {

	
	@Test
	void we_can_extract_all_add_handlers_from_class_declaration() {
		
		Page page = GwtModelExtractor.getInstance("gwt-app-6_kdm_gwt.xmi").getPages().get(0);
		
		ClassDeclaration declaredPage = ClassDeclarationExtractor.getInstance("gwt-app-6_java.xmi")
				.getClassDeclaration(page);
		
		assertEquals(65, MethodInvocationExtractor.getInstance().getHandlers(declaredPage).size());
		
	}

}
