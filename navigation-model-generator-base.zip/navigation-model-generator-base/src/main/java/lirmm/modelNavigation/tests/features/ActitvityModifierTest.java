package main.java.lirmm.modelNavigation.tests.features;



import static org.junit.jupiter.api.Assertions.assertEquals;
import org.eclipse.emf.common.util.EList;
import org.junit.jupiter.api.Test;

import kdm.code.gwt.Activity;
import kdm.code.gwt.Page;
import main.java.lirmm.modelNavigation.extract.kdm.pagesLinkedWithActivities.ActivityModifier;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;


class ActitvityModifierTest {

	@Test
	void can_link_page_to_an_activity() {
		
		EList<Activity> activities = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities();
		
		EList<Page> pages = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getPages();
				
		assertEquals(ActivityModifier.getInstance().getPageActivityMap(activities, pages).size(), 2);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	
}
