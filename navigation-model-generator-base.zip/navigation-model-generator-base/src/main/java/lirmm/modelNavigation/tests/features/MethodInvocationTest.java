package main.java.lirmm.modelNavigation.tests.features;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import org.junit.jupiter.api.Test;

import com.github.javaparser.ast.body.CallableDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;

import kdm.code.gwt.Activity;
import main.java.lirmm.modelNavigation.extractors.ast.ASTParser;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.FilterFacade;
import main.java.lirmm.modelNavigation.extractors.ast.visitors.MethodCallsIdentifier;
import main.java.lirmm.modelNavigation.extractors.kdm.GwtModelExtractor;



class MethodInvocationTest {

	@Test
	void canGetAllAddHandlerForGivenClassUnit() {
		
		Activity loginActivity = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities().get(0);
		
		String path = loginActivity.getSource().get(0).getRegion().get(0).getFile().getPath();
		
		List<MethodCallExpr> methodCallExpr = (new ASTParser(path).getMethodCallExpr());
		
		assertEquals(methodCallExpr.size(),2);
	}
	
	@Test
	void canGetObjectCreationOfAddHandler() {
		
		Activity loginActivity = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities().get(0);
		
		String path = loginActivity.getSource().get(0).getRegion().get(0).getFile().getPath();

		MethodCallExpr methodCallExpr = (new ASTParser(path).getAddHandlerExper()).get(0);
		
		ObjectCreationExpr objectCreationExpr = null;
		
		MethodCallsIdentifier methods =  new MethodCallsIdentifier();
		
		if ( methodCallExpr.getArguments().get(0).isObjectCreationExpr() ) {
			
			objectCreationExpr = methodCallExpr.getArguments().get(0).asObjectCreationExpr();
			
			objectCreationExpr.accept(methods, null);
						
		}
			
		assertTrue(false);
	}
	
	
	
	@Test
	void canGetMethodDeclarationParentOfMethodInvocation() {
		
		Activity loginActivity = GwtModelExtractor.getInstance("mvp_kdm_gwt.xmi").getActivities().get(1);
		
		String path = loginActivity.getSource().get(0).getRegion().get(0).getFile().getPath();

		MethodCallExpr methodCallExpr = (new ASTParser(path).getMethodCallExpr()).get(7);

		
		CallableDeclaration callableDeclaration = FilterFacade.getInstance().getCallableDeclarationContainsMethodCall(methodCallExpr);

		System.err.println(FilterFacade.getInstance().getHandlerMethod(callableDeclaration).getParentNode().get() instanceof MethodCallExpr);
		
		
		assertTrue(false);
	}
	
	
	
	
	

}
 