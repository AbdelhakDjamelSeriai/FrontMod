# navigation-model

This repo create a navigation model from given GWT model and Java model. 
To execute this project you have  to run the class [TransitionService](https://github.com/migration-Fr-org/navigation-model/blob/main/src/TransitionService.java)
In this class  you should  given  the name of your  GWT, Java models puted into [dbExamples](https://github.com/migration-Fr-org/navigation-model/tree/main/src/tests/features/dbExamples)


