package main.java.lirmm.angularGenerator.gamba;

import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmt.modisco.java.AbstractMethodDeclaration;
import org.eclipse.gmt.modisco.java.AbstractMethodInvocation;
import org.eclipse.gmt.modisco.java.AnonymousClassDeclaration;
import org.eclipse.gmt.modisco.java.Assignment;
import org.eclipse.gmt.modisco.java.Block;
import org.eclipse.gmt.modisco.java.BodyDeclaration;
import org.eclipse.gmt.modisco.java.BooleanLiteral;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.ConstructorDeclaration;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.FieldDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.NumberLiteral;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.StringLiteral;
import org.eclipse.gmt.modisco.java.TryStatement;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;

import main.java.lirmm.angularGenerator.dao.Attribute;

public class FragmentExtractor {
	
	
	private ClassDeclaration classDeclaration;
	/**
	 * 
	 */
	private static FragmentExtractor uniqueInstance;
	
	/**
	 * 
	 */
	private FragmentExtractor() {
	}
	
	/**
	 * 
	 */
	public void setClassDeclaration(ClassDeclaration classDeclaration) {
		this.classDeclaration = classDeclaration;
	}
	
	/**
	 * 
	 * @return
	 */
	public static FragmentExtractor getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new FragmentExtractor();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * get Widget From Class Declaration
	 * @param mainPageViewJava
	 * @param nameWidget
	 * @return
	 */
	public VariableDeclarationFragment getWidgetFromClassDeclaration(String nameWidget) {
		
		VariableDeclarationFragment fragment = null;
		
		for(BodyDeclaration bodyDeclaration: classDeclaration.getBodyDeclarations()) {
			
			if (getVariableDeclarationFragmentAsFieldDeclaration(bodyDeclaration, nameWidget) !=  null) {

					fragment = getVariableDeclarationFragmentAsFieldDeclaration(bodyDeclaration, nameWidget);
					
			}else if (getVariableDeclarationFragmentAsVarDecStmt(bodyDeclaration, nameWidget) != null) {
					
					fragment = getVariableDeclarationFragmentAsVarDecStmt(bodyDeclaration, nameWidget);
			}
		}
		
		return fragment;
	}
	
	/**
	 * Get Fragment case Field Declaration
	 * @param bodyDeclaration
	 * @param nameWidget
	 * @return
	 */
	public VariableDeclarationFragment getVariableDeclarationFragmentAsFieldDeclaration(BodyDeclaration bodyDeclaration, String nameWidget) {
		
		VariableDeclarationFragment fragment = null;
		
		if ( (bodyDeclaration instanceof FieldDeclaration) && (((FieldDeclaration)bodyDeclaration).getFragments().get(0).getName().equals(nameWidget)) ) {
			
			fragment = (((FieldDeclaration)bodyDeclaration).getFragments().get(0));
		}
		
		return fragment;
	}
	

	/**
	 * Get Fragment case VarDecStmt <--> Variable Declaration Statement 
	 * @param bodyDeclaration
	 * @param nameWidget
	 * @return
	 */
	public VariableDeclarationFragment getVariableDeclarationFragmentAsVarDecStmt(BodyDeclaration bodyDeclaration, String nameWidget) {
		
		VariableDeclarationFragment fragment = null;
		
		if ((bodyDeclaration instanceof AbstractMethodDeclaration)) {
			 
			EList<Statement> statements = null ;
			
			if (((AbstractMethodDeclaration)bodyDeclaration).getBody()!=null) {
				//statements = ((AbstractMethodDeclaration)bodyDeclaration).getBody().getStatements();
				statements = getAllStatementOfGivenStatement(((AbstractMethodDeclaration)bodyDeclaration).getBody());
			}
			
			if (statements != null) {
				for(Statement s : statements) {				
					if ((s instanceof VariableDeclarationStatement) && ( ((VariableDeclarationStatement)s).getFragments().get(0).getName().equals(nameWidget) ) ) {					
						fragment = ((VariableDeclarationStatement)s).getFragments().get(0);					
						break;					
					}				
				}
			}
			
		}
		
		 
		 return fragment;
	}
	
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
	public EList<Statement> getAllStatementOfGivenStatement(Block block){
		
		EList<Statement> statements = new BasicEList<>();
			
		for (Statement statement: block.getStatements()) {
			if ( (!(statement instanceof TryStatement)) && (!(statement instanceof Block)) ) {
					statements.add(statement);	
			} else {															
					if (statement instanceof Block) {
					   statements.addAll(getAllStatementOfGivenStatement( (Block) statement));						
					}
					
					if (statement instanceof TryStatement) {
						statements.addAll(getAllStatementOfGivenStatement( ((TryStatement) statement).getBody()) );
					}
			}
			
		}
			
		return statements;
	}
	
	
	public boolean isInHandler(SingleVariableAccess singleVariableAccess) {
		EObject container = singleVariableAccess.eContainer();
		
		boolean detected = false;
		
		while ( (container != null) && !detected ) {
			
			if ( (container instanceof AnonymousClassDeclaration) ) {
				detected = true;
				return true;
			}
			
			container = container.eContainer() ; 
		}
		
		return false;
	}
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
	public List<Attribute> createAttributesFromSva(SingleVariableAccess singleVariableAccess) {
		// methodInovcation Basic List 
		EList<MethodInvocation> methodInvocations = new BasicEList<>();
		
		// check if Handler type not exist 
		if ( !isInHandler(singleVariableAccess)) {
			//get the methodInovcation
			methodInvocations = getMethodInvocationsFromSVA(singleVariableAccess);
		}
		 
		// initialize attributes 
		List<Attribute> attributes = new ArrayList<>();

		// if the methodInovcations list is not empty
		if (!methodInvocations.isEmpty()) {
			// check if the singleVariableAccess how invoke these methods
			if (checkIfSvaIsSource(singleVariableAccess, methodInvocations)) {

				// for each methodInovcation in the list
				for (MethodInvocation methodInvocation: methodInvocations) {
				    // create an attribute of methodInovcation
					Attribute attribute = new Attribute();
					// set Name by methodDeclaration Name
				    attribute.setName(methodInvocation.getMethod().getName());
				    // set the arguments by invoke @@@transformArgsStringList Method
				    attribute.setArgs( transformArgsToStringList(methodInvocation.getArguments()) );
				    // added to the list of attribute
					attributes.add(attribute);
				}
				

			}
			
		} else if (!getAssignmentFromSVA(singleVariableAccess).isEmpty()) {
			// create an attribute
			Attribute attribute = new Attribute();
		    // set Name constructor
			attribute.setName("constructor");
			// set Arguments
		    attribute.setArgs(getAssignmentFromSVA(singleVariableAccess));
		    // added to the list of attribute
		    attributes.add(attribute);
		}
		
	    // return linked Attributes
		return linkedAttributes(attributes);
	}
	
	
	/**
	 * get the case of "singleVariableAccess.methodInvocation1().methodInvocation2().methodInvocation3().......methodInvocationN();"
	 * @param singleVariableAccess
	 * @return
	 */
	public EList<MethodInvocation> getMethodInvocationsFromSVA(Expression singleVariableAccess) {
		
		// create a basic list of methodInvocation
		EList<MethodInvocation> methodInvocations = new BasicEList<>();
		
		// get the singleVariableAccess container 
		EObject econtainer = singleVariableAccess.eContainer();
		
		// while, the singleVariableAccess container is not type of Statement, do :
		while (!(econtainer instanceof Statement)) {
			
			// if, the singleVariableAccess container is type of MethodInvocation, then : 
			if (econtainer instanceof MethodInvocation) {
				// add the container to the basic list @@@methodInvocations
				methodInvocations.add((MethodInvocation)econtainer);
			}
			
			// get the next container 
			econtainer = econtainer.eContainer();
		}
		
		// return the basic list !
		return methodInvocations;
	}
	
	
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
	public List<AbstractMethodInvocation> getMethodInvocationsFromSVAMethodCase(Expression singleVariableAccess) {
		// create a methodInovcations List
		List<AbstractMethodInvocation> methodInvocations = new ArrayList<>();

		// get the parent of the single Variable Access
		EObject econtainer = singleVariableAccess.eContainer();
		
		// if, the parent is not instance of Assignment and MethodInvocation Types, Then :
		if (!(econtainer instanceof Assignment) && !(econtainer instanceof MethodInvocation) ) {

			// While, the parent is not instance of MethodDeclaration Type, do :
 		    while (!(econtainer instanceof AbstractMethodDeclaration)) {
 		    	
 				//System.err.println(econtainer);

 		    	// get the parent of signleVariableAccessParent 
				econtainer = econtainer.eContainer();

				// if ,the parent is instance of MethodDeclaration, then
				if (econtainer instanceof MethodDeclaration) {
				   
				   // create a new methodDeclaration and affect the parent to it .
					MethodDeclaration methodDeclaration = (MethodDeclaration)econtainer;
				   
				   // affectation the 
				   methodInvocations =
						   // get MethodDeclaration Usages by steaming
						   methodDeclaration.getUsages().stream()
						   // make a filter to the sequence usages
							.filter( 
								   // foreach case apply the predicatFromMethodInvocationSelection
								   e -> predicatForMethodInvocationSelection(classDeclaration,e)
						    // we make a collectors 
							).collect(Collectors.toList());
				   }					
			} 
 		    
 		    
		
		}
		
		// return the sequence of the methodInvocations
		return methodInvocations;
	}
	
	
	/**
	 * check if @param methodInvocation is in the right classDeclaration @param mainPageViewJava  
	 * @return boolean Type
	 */
	public boolean predicatForMethodInvocationSelection(ClassDeclaration mainPageViewJava, AbstractMethodInvocation methodInvocation) {
		
		boolean check = false;
		
		EObject container = methodInvocation.eContainer();
		
		// while the parent is not a class Declaration
		while (! (container instanceof ClassDeclaration)) {
			
			// get the next parent
			container = container.eContainer();
			
			// compare between mainPageViewJava and the super container of methodInvocation 
			if ( ((container instanceof ClassDeclaration) ) && ((ClassDeclaration)container).getName().equals(mainPageViewJava.getName())) {
				check = true;
			}	  
		}
		return check;
	}
	
	
	
	
	
	
	
	
	/**
	 * Get the arguments when we assign a ClassInstanceCreation to singleVariableAccess
	 * @param singleVariableAccess
	 * @return
	 */
	public List<String> getAssignmentFromSVA(SingleVariableAccess singleVariableAccess) {
		
		// get the container of singleVariableAccess
		EObject econtainer = singleVariableAccess.eContainer();
		
		// initialize the arguments List
		List<String> argAsString = new ArrayList<>(); 
		
		// if, the container is type Of Assignment and the right Hand Side is kind of ClassInstanceCreation, then
		if ( (econtainer instanceof Assignment) && ( ((Assignment) econtainer).getRightHandSide() instanceof ClassInstanceCreation) ){
			// get the arguments Of ClassInstanceCreation
			argAsString = transformArgsToStringList( ((ClassInstanceCreation)(((Assignment) econtainer).getRightHandSide())).getArguments() );
		}
		
		return argAsString;
	}
	
	
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @param methodInvocations
	 * @return
	 */
	public boolean checkIfSvaIsSource(SingleVariableAccess singleVariableAccess, EList<MethodInvocation> methodInvocations) {
		
		// get All the arguments of All MethodInovcations
		List<Expression> arguments =  methodInvocations.stream().flatMap(s -> s.getArguments().stream()).collect(Collectors.toList()) ; 
		
		// return true if arguments is not contain the singleVariableAccess
		return arguments.stream().filter(e -> compareTwoSva(singleVariableAccess, e)).collect(Collectors.toList()).size() == 0 ;
	}
	
	
	/**
	 * Compare two objects if they are the same 
	 * @param sva1
	 * @param sva2
	 * @return
	 */
	public boolean compareTwoSva(SingleVariableAccess sva1, EObject sva2) {
		
		//we compare by name, you can extend after the condition 
		return ((sva2 instanceof SingleVariableAccess) && ( ((SingleVariableAccess)sva2).getVariable().getName().equals(sva1.getVariable().getName()) ));
	}
	
	
	
	/**
	 * 
	 * @param arguments
	 * @return
	 */
	public List<String> transformArgsToStringList(List<Expression> arguments) {
		
		// create a string list for args
		List<String> argsList = new ArrayList<>();
		
		// for each argument in arguments
		for (Expression expression: arguments ) {
			
			// transform BooleanLiteral
			if (expression instanceof BooleanLiteral) {
					argsList.add( ((BooleanLiteral)expression).isValue() ? "true" : "false" );
			}
				
			// transform NumberLiteral 
			if (expression instanceof NumberLiteral) {
					argsList.add( ((NumberLiteral)expression).getTokenValue() ); 
			}
						
			// transform StringLiteral
			if (expression instanceof StringLiteral) {
					argsList.add( ((StringLiteral)expression).getEscapedValue() );
			}
			
			// transform SingleVariableAccess
			if (expression instanceof SingleVariableAccess) {
					argsList.add( ((SingleVariableAccess)expression).getVariable().getName() );
			}
			
			// transform MethodInovcation
			if (expression instanceof MethodInvocation) {
					
				MethodDeclaration methodDeclaration = (MethodDeclaration)((MethodInvocation)expression).getMethod() ;
				ReturnStatement returnStatement = null;
						
				/*if((ReturnStatement)methodDeclaration.getBody().getStatements().get( methodDeclaration.getBody().getStatements().size() - 1 ) != null) {
					returnStatement = (ReturnStatement)methodDeclaration.getBody().getStatements().get( methodDeclaration.getBody().getStatements().size() - 1 );
				}*/
				
				//ReturnStatement returnStatement = (ReturnStatement)methodDeclaration.getBody().getStatements().get( methodDeclaration.getBody().getStatements().size() - 1 );
						
				///argsList.add(((SingleVariableAccess)(returnStatement.getExpression())).getVariable().getName()) ;
				argsList.add("returnType") ;
				 
					
			}
					
		}
		
		return argsList;
	}
	
	
	/**
	 * 
	 * @param attributes
	 * @return
	 */
	private List<Attribute> linkedAttributes(List<Attribute> attributes) {
			
			if (!attributes.isEmpty()) {
				for(int j = 0; j < attributes.size(); j++) {
						
					if (j+1<attributes.size()) {
						attributes.get(j).setAttribute(attributes.get(j+1));
					} 
				}
				attributes.get(attributes.size()-1).setAttribute(null);
			}
			
			return attributes;
	}
	
	/**
	 * 
	 * @param fragment
	 * @return
	 */
	public Attribute createAttributeFromVariableDeclaration(VariableDeclarationFragment fragment) {
		
		Expression expression = fragment.getInitializer();
		
		Attribute attribute = new Attribute();
		
		attribute.setName("affectedType");
		
		Attribute attribute2 =  new Attribute();
		attribute2.setName(getAffectedTypeForVariable(fragment));
		
		attribute.setAttribute(attribute2);

		if (( expression instanceof ClassInstanceCreation ) && ( ((ClassInstanceCreation)expression).getArguments().size() > 0 ) ) {
			
			attribute2.setArgs( transformArgsToStringList(((ClassInstanceCreation)expression).getArguments()) );
		}
		return attribute;
	}
	
	/**
	 * Get the affected type elements 
	 * @param fragment
	 * @return
	 */
	public String getAffectedTypeForVariable(VariableDeclarationFragment fragment) {
		Expression expression = fragment.getInitializer();
		String nameType = "";
		
		if (( expression instanceof ClassInstanceCreation )) {		
			nameType = ((ClassInstanceCreation)expression).getType().getType().getName();
		} else if (expression instanceof MethodInvocation) {
			if (((MethodDeclaration)((MethodInvocation)expression).getMethod()).getReturnType()!=null) {
				nameType = ((MethodDeclaration)((MethodInvocation)expression).getMethod()).getReturnType().getType().getName();
			} else {
				nameType = "RootPanel";
			}
		}
		return nameType;
	}
	
	
	public List<List<Attribute>>  createAttributesFromFromSVAMethodCase(SingleVariableAccess singleVariableAccess) {
		
		List<MethodInvocation> methodInvocations = (List<MethodInvocation>)(List<?>)getMethodInvocationsFromSVAMethodCase(singleVariableAccess);
		
		List<List<Attribute>> attributes1 = new ArrayList<>();

		for (MethodInvocation methodInvocation: methodInvocations) {
			 
			  List<Attribute> attributes = new ArrayList<>();
			  
			  if (checkIfMiIsSource(methodInvocation, getMethodInvocationsFromSVA(methodInvocation))) {
				  for (MethodInvocation methodInvocation2: getMethodInvocationsFromSVA(methodInvocation)) {
					    
						Attribute attribute = new Attribute();
					    attribute.setName(methodInvocation2.getMethod().getName());
					    attribute.setArgs( transformArgsToStringList(methodInvocation2.getArguments()) );
					    
						attributes.add(attribute);
						
					}
				  
				  attributes1.add(attributes);
			  }
			  
			  
			
		}
		
		return attributes1;
	}
	
	/***
	 * 
	 * 
	 */
	public boolean checkIfMiIsSource(MethodInvocation methodInvocation, EList<MethodInvocation> methodInvocations) {
		List<Expression> arguments =  methodInvocations.stream().flatMap(s -> s.getArguments().stream()).collect(Collectors.toList()) ; 
		return arguments.stream().filter( e -> compareTwoMi(methodInvocation,e)).collect(Collectors.toList()).size() == 0;
	}
	
	/**
	 * 
	 */
	public boolean compareTwoMi(MethodInvocation methodInvocation, EObject eObject) {
		return ((eObject instanceof MethodInvocation) && ( ((MethodInvocation)eObject).getMethod().getName().equals(methodInvocation.getMethod().getName()) ));
	}
	

}
