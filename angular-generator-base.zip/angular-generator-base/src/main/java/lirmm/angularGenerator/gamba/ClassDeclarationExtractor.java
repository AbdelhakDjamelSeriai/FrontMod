package main.java.lirmm.angularGenerator.gamba;


import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.AbstractTypeDeclaration;
import org.eclipse.gmt.modisco.java.BodyDeclaration;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.Model;
import org.eclipse.gmt.modisco.java.Package;
import kdm.code.ClassUnit;


public class ClassDeclarationExtractor {
	
	private String pathToJavaModel ;//= "src/resources/source/";

	
	/**
	 * 
	 */
	private static ClassDeclarationExtractor uniqueInstance;
	
	
	/**
	 * 
	 */
	private ClassDeclarationExtractor(String pathString) {
		pathToJavaModel = pathString;
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public static ClassDeclarationExtractor getInstance(String pathString) {
		if (uniqueInstance == null) {
			uniqueInstance = new ClassDeclarationExtractor(pathString);
		}
		return uniqueInstance;
	}
	
	
	
	
	/**
	 * Get Class Declaration that corresponds to ClassUnit
	 * @param classUnit
	 * @return
	 */
	public ClassDeclaration getClassDeclaration(ClassUnit classUnit) {
		
	  ClassDeclaration desiredClassDeclaration = null; 
	  
	  String packageName = "";Model rootModel = null; Package client = null; Package package1 = null;
	  
	  EList<ClassDeclaration> classDeclarations = null;
	 
	  //try {
		if (classUnit.eContainer() instanceof kdm.code.Package) {
			
		    packageName = ((kdm.code.Package)classUnit.eContainer()).getName();
		    
		    rootModel = RootModel.getInstance().getJavaModelFromXMIFile(pathToJavaModel);
		    
		    client = PackageIdentifier.getInstance().getClientPackage(rootModel.getOwnedElements().get(0));
		    
		    package1 = PackageIdentifier.getInstance().getPackagePageFromClientPackage(client,packageName);
		    
		    classDeclarations = getClassesDeclaration(package1);
		    
		    for (ClassDeclaration classDeclaration: classDeclarations) {
				if (classDeclaration.getName().equals(classUnit.getName())) {
						desiredClassDeclaration = classDeclaration; 
				}
			}

		    
		} else {
			
			if (classUnit.eContainer() instanceof kdm.code.ClassUnit) {
				
				packageName = ((kdm.code.Package)((kdm.code.ClassUnit)classUnit.eContainer()).eContainer()).getName();
			    
			    rootModel = RootModel.getInstance().getJavaModelFromXMIFile(pathToJavaModel);
			    
			    client = PackageIdentifier.getInstance().getClientPackage(rootModel.getOwnedElements().get(0));
			    
			    package1 = PackageIdentifier.getInstance().getPackagePageFromClientPackage(client,packageName);
			    
			    classDeclarations = getClassesDeclaration(package1);
				
			    for (ClassDeclaration classDeclaration: classDeclarations) {
					if (classDeclaration.getName().equals(((kdm.code.ClassUnit)classUnit.eContainer()).getName())) {
							desiredClassDeclaration = classDeclaration;
							
							for (BodyDeclaration bodyDeclaration: desiredClassDeclaration.getBodyDeclarations()) {
								if ((bodyDeclaration instanceof ClassDeclaration) && ( ((ClassDeclaration)bodyDeclaration)
										.getName().equals(classUnit.getName()) 
								    )) {
									desiredClassDeclaration = (ClassDeclaration)bodyDeclaration;
								}
							}
					}
				}
			    
			    
			}
		}

			
			
		
	  /*} catch (Exception e) {
			
	  }*/
	
	  return desiredClassDeclaration;
	}
	
	
	/**
	 * Get Classes Declaration from A Package
	 * @param package1
	 * @return
	 */
	public EList<ClassDeclaration> getClassesDeclaration(Package package1) {
		 
		 EList<AbstractTypeDeclaration> abstractTypeDeclarations= package1.getOwnedElements();
		 
		 EList<ClassDeclaration> classDeclarations = new BasicEList<>();
		 
		 for (AbstractTypeDeclaration abstractTypeDeclaration : abstractTypeDeclarations) {
			 
			 if (abstractTypeDeclaration instanceof ClassDeclaration) {
				 
				 classDeclarations.add((ClassDeclaration)abstractTypeDeclaration);
				 
			 }
		 }
		 
		return classDeclarations;
	}
}
