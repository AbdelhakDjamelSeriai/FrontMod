package main.java.lirmm.angularGenerator.test.json;

import static org.junit.Assert.*;

import org.json.simple.JSONArray;
import org.junit.Test;

import main.java.lirmm.angularGenerator.json.GWTModelFileReader;

public class GWTModelFileReaderTest {

	@Test
	public void it_can_parse_json_data() {
		
		JSONArray pages = (JSONArray)(new GWTModelFileReader("gwt.json")).parseData();
		
		int actual = pages.size();
		
		assertEquals(1,actual);
		
	}

}
