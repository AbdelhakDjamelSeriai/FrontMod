package main.java.lirmm.angularGenerator.test.json;

import static org.junit.Assert.*;

import org.json.simple.JSONArray;
import org.junit.Before;
import org.junit.Test;

import main.java.lirmm.angularGenerator.json.GWTElementsFileReader;

public class GWTElementsFileReaderTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void it_can_get_gwt_elements() {
		
		GWTElementsFileReader reader = new GWTElementsFileReader("gwtElements.json");
		
		int actual = ((JSONArray)reader.parseData()).size();
		
		assertEquals(21, actual);
	}

}
