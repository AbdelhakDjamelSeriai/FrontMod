package main.java.lirmm.angularGenerator.test.iterators;

import static org.junit.Assert.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;

import main.java.lirmm.angularGenerator.angular.ng.commands.AngularConfigurations;
import main.java.lirmm.angularGenerator.iterators.AngularGenerator;
import main.java.lirmm.angularGenerator.iterators.PageIterator;
import main.java.lirmm.angularGenerator.iterators.PagesCollection;
import main.java.lirmm.angularGenerator.json.GWTElementsFileReader;
import main.java.lirmm.angularGenerator.json.GWTModelFileReader;
import main.java.lirmm.angularGenerator.pivotModel.PivotModelReader;

public class PagesCollectionTest {
	
	private JSONArray pages;
	
	private JSONObject page;
	
	private JSONArray widgets;

	@Before
	public void setUp() throws Exception {	
		
		pages = (JSONArray)(new GWTModelFileReader("gwt.json")).parseData();
		
		page = (JSONObject)pages.get(0);
		
		widgets = (JSONArray)page.get("Widgets");
		
	}

	@Test
	public void it_can_iterate_page() {
		
		int actual = widgets.size();
		
		assertEquals(7,actual);
	}
	
	@Test
	public void it_can_iterate_widget() {
		
		JSONObject widget = (JSONObject)widgets.get(0);
		
		String actual = (String) widget.get("type");
		
		assertEquals("Button",actual);
	}
	
	@Test
	public void it_can_iterate_list_list_pages() {
		
		GWTModelFileReader readmodel = new GWTModelFileReader("gwt.json");
		
		PivotModelReader pivotModel = new PivotModelReader(readmodel);
		
		
		PagesCollection pagesCollection = new PagesCollection(pivotModel.getPages()
				, new PageIterator( new AngularGenerator(), new AngularConfigurations() ) );
		assertEquals(1, pagesCollection.iteratePages().size());
	}

}
