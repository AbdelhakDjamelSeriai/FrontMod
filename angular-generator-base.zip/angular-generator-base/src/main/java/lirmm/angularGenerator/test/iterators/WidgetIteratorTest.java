package main.java.lirmm.angularGenerator.test.iterators;

import static org.junit.Assert.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Before;
import org.junit.Test;

import main.java.lirmm.angularGenerator.json.GWTElementsFileReader;
import main.java.lirmm.angularGenerator.json.GWTModelFileReader;

public class WidgetIteratorTest {

	GWTElementsFileReader reader;
	
	//WidgetIterator widgetIterator;
	
	@Before
	public void setUp() throws Exception {
		reader = new GWTElementsFileReader("gwtElements.json");
		
		//widgetIterator = new WidgetIterator(reader);
	}

	@Test 
	public void it_can_iterate_given_widget() {
		GWTModelFileReader reader = new GWTModelFileReader("gwt.json");
		JSONArray pages = (JSONArray)reader.parseData();
		JSONObject firstPage = (JSONObject)pages.get(0);
		JSONArray widgets = (JSONArray)firstPage.get("Widgets") ;//0-1-3-4-5-6
		JSONObject stocksFlexTable = (JSONObject)widgets.get(2);
		
	
		//String htmlCode = widgetIterator.iterateWidget(stocksFlexTable);
		
		//System.out.print(htmlCode);
		
		//String expected /*0*/ = "<button type=\"button\" class=\"gwt-Button\"></button>";
		//String expected /*1*/ = "<table cellspacing=\"0\" cellpadding=\"0\"><tbody></tbody></table>";	
		String expected /*2*/ = "<table><colgroup><col></colgroup><tbody></tbody></table>";
		//String HorizontalPanel /*3*/= "<table cellspacing=\"0\" cellpadding=\"0\" ><tbody><tr></tr></tbody></table>";
		//String expected /*4*/ = "<input type=\"text\" class=\"gwt-TextBox\" autofocus>";
		//String label /*6*/= "<div class=\"gwt-Label\">Last update : </div>";
		
		Document document = Jsoup.parse(expected);
		
		String expectedString = document.select("body > *").outerHtml();
		
		//System.out.println(expectedString);
		
		//assertEquals(expectedString, htmlCode);
	}
	
	@Test
	public void it_can_check_widget_name() {
		
		//assertNotNull(widgetIterator.searchForMappedWidget("Button"));
	
	}
	
	@Test
	public void it_can_return_outer_html_of_mapped_elements_in_gwt_elemets(){
		
		String expected = "<button type=\"button\" class=\"gwt-Button\"></button>";
		
		//assertEquals(expected, widgetIterator.getTypeHTML("Button"));
	}
	
	
	

}
