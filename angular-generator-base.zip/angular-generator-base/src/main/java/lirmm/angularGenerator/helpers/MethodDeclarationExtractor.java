package main.java.lirmm.angularGenerator.helpers;

import static org.junit.Assert.assertNotNull;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.BodyDeclaration;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ConstructorDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;

public class MethodDeclarationExtractor {

	
	/**
	 * Constructor of the class MethodDeclarationExtractor. 
	 * Its visibility is private in order not to allow the other classes to create many instances of MethodUnitsExtractor
	 */
	private MethodDeclarationExtractor(){
		
	}
	
	/**
	 * unique instance of MethodDeclarationExtractor.
	 */
	private static MethodDeclarationExtractor uniqueInstance;
	
	/**
	 * Method insuring that a unique instance of MethodDeclarationExtractor is created.
	 * 
	 * @return uniqueInstance
	 */
	public static MethodDeclarationExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new MethodDeclarationExtractor();
		}
		return uniqueInstance;
	}
	
	/**
	 * 
	 * @param classDeclaration
	 * @param methodName
	 * @return
	 */
	public MethodDeclaration getMethodDeclarationFromClassDeclaration(ClassDeclaration classDeclaration, String methodName) {
		
		EList<BodyDeclaration> bodyDeclarations = classDeclaration.getBodyDeclarations();
		MethodDeclaration methodDeclaration = null;
		
		for (BodyDeclaration bodyDeclaration: bodyDeclarations) {
		
			if ((bodyDeclaration instanceof MethodDeclaration) && (((MethodDeclaration)bodyDeclaration).getName().equals(methodName) )) {
				methodDeclaration = ((MethodDeclaration)bodyDeclaration);
			}
		}
		
		return methodDeclaration;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public EList<ConstructorDeclaration> getConstructors(ClassDeclaration classDeclaration) {
		
		EList<BodyDeclaration> bodyDeclarations = classDeclaration.getBodyDeclarations();
		EList<ConstructorDeclaration> constructorDeclarations = new BasicEList<>();
		
		for(BodyDeclaration bodyDeclaration: bodyDeclarations) {
			
			if ((bodyDeclaration instanceof ConstructorDeclaration)) {
				constructorDeclarations.add((ConstructorDeclaration)bodyDeclaration);
			}
			
		}
		
		return constructorDeclarations;
	}
}
