package main.java.lirmm.angularGenerator.helpers;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gmt.modisco.java.BooleanLiteral;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.ExpressionStatement;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.NumberLiteral;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.StringLiteral;

public class StatementExtractor {
	
	/**
	 * Constructor of the class StatementExtractor. 
	 * 
	 * Its visibility is private in order not to allow the other classes to create many instances of StatementExtractor
	 * 
	 */
	private StatementExtractor(){
		
	}
	
	/**
	 * 
	 * unique instance of MethodDeclarationExtractor.
	 * 
	 */
	private static StatementExtractor uniqueInstance;
	
	/**
	 * 
	 * Method insuring that a unique instance of StatementExtractor is created.
	 * 
	 * @return uniqueInstance
	 */
	public static StatementExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new StatementExtractor();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * 
	 * @param methodDeclaration
	 * @return
	 */
	public Statement getLastStatementOfMethodDeclaration(MethodDeclaration methodDeclaration) {
		return methodDeclaration.getBody().getStatements().get( methodDeclaration.getBody().getStatements().size() - 1);
	}
	
	/**
	 * 
	 * @param statement
	 * @return
	 */
	public boolean isReturnStatement(Statement statement) {
		return statement instanceof ReturnStatement ;
	}

	
	/**
	 * get return Statement
	 */
	public Statement getReturnStatement(MethodDeclaration methodDeclaration) {
		
		Statement returnStatement = null;

		Statement stmt = getLastStatementOfMethodDeclaration(methodDeclaration);
				
		if (isReturnStatement(stmt)) {
			
			returnStatement = stmt;
		}
		
		return returnStatement;
	}
	
	
	/**
	 * get the Widget Name returned by As
	 * @param methodDeclaration
	 * @return
	 */
	public String getWidgtNameReturedByAsWidget(MethodDeclaration methodDeclaration) {
		
		String widgetName = null;
		
		if ( getReturnStatement(methodDeclaration) != null ) {
			Statement returnStatement = getReturnStatement(methodDeclaration);
			Expression expression = ((ReturnStatement)returnStatement).getExpression();
			
			if ( expression instanceof SingleVariableAccess) {
				widgetName = ((SingleVariableAccess)expression).getVariable().getName();
			}
		}
		return widgetName;
	}
	
	/**
	 * � terminer apr�s
	 * @param methodDeclaration
	 * @return
	 */
	public Statement bolo(MethodDeclaration methodDeclaration) {
		
		for(Statement statement: methodDeclaration.getBody().getStatements()) {
			if (statement instanceof ExpressionStatement) {
				Expression expression =  ((ExpressionStatement)statement).getExpression();
				if (expression instanceof MethodInvocation) {
					
					transformArgsToStringList(((MethodInvocation)expression).getArguments());
					
				}
			}
		}
		return null;
	}
	
	
	/**
	 * voir �a 
	 * @param arguments
	 * @return
	 */
	public List<String> transformArgsToStringList(List<Expression> arguments) {
		
		List<String> argsList = new ArrayList<String>();
		
		for (Expression expression: arguments ) {
			
			if (expression instanceof BooleanLiteral) {
				argsList.add( ((BooleanLiteral)expression).isValue() ? "true" : "false" );
			}
			
			if (expression instanceof NumberLiteral) {
				argsList.add( ((NumberLiteral)expression).getTokenValue() ); 
			}
					
			if (expression instanceof StringLiteral) {
				argsList.add( ((StringLiteral)expression).getEscapedValue() );
			}
			
			if (expression instanceof SingleVariableAccess) {
				argsList.add( ((SingleVariableAccess)expression).getVariable().getName() );
			}
			
			if (expression instanceof MethodInvocation) {
				
					MethodDeclaration methodDeclaration = (MethodDeclaration)((MethodInvocation)expression).getMethod() ;
					
					ReturnStatement returnStatement = (ReturnStatement)methodDeclaration.getBody().getStatements().get( methodDeclaration.getBody().getStatements().size() - 1 );
					
					argsList.add(((SingleVariableAccess)(returnStatement.getExpression())).getVariable().getName()) ;
			 
				
			}
				
		}
		
		return argsList;
	}
	
}
