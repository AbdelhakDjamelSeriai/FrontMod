package main.java.lirmm.angularGenerator.helpers;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;

import kdm.code.gwt.Page;
import kdm.code.gwt.Widget;
import main.java.lirmm.angularGenerator.dao.Attribute;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gamba.FragmentExtractor;

public class FilterHelper {
	
	/**
	 * Constructor of the class FilterHelper. 
	 * Its visibility is private in order not to allow the other classes to create many instances of FilterHelper
	 */
	private FilterHelper(){
		
	}
	
	
	/**
	 * unique instance of FilterHelper.
	 */
	private static FilterHelper uniqueInstance;
	
	
	/**
	 *
	 * @return uniqueInstance
	 */
	public static FilterHelper getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new FilterHelper();
		}
		return uniqueInstance;
	}
	
	
	/**
	 * Predicate to get only "add" attribute
	 * @return
	 */
	public void filterAdd(List<String> childTree, Attribute attribute ) {
		if ((attribute.getName().equals("add"))&&(!attribute.getArgs().isEmpty())) {	
				childTree.add(attribute.getArgs().get(0));	
		}	
	}
	
	/**
	 * Filter the tree list to get only items that have no parent !!
	 * @param listOfTree
	 * @return
	 */
	public List<List<String>> filterTreeListTogetRoot(List<List<String>> listOfTree) {
		
		List<List<String>> found = new ArrayList<>();
		
		for (List<String> list1: listOfTree) {
			
			for(List<String> list2: listOfTree) {
				
				if(intersection(list1, list2)) {
					found.add(list1);
				}
			}
			
		}
		
		listOfTree.removeAll(found);
		
		return listOfTree;
	}
	
	/**
	 * Predicate to check if list2 contains the root Element of list1 !! 
	 * @param list1
	 * @param list2
	 * @return
	 */
	public boolean intersection(List<String> list1, List<String> list2) {
		
		boolean check = false;
		
		String root1 = list1.get(0);
		
		String root2 = list2.get(0); 
			
		if ( (!root1.equals(root2)) && (list2.contains(root1)) ) {				
			check = true;			
		}
		
		return check;
	}

	
	/**
	 * 
	 * @param page
	 * @return
	 */
	public String isPageImplementIsWidget(ClassDeclaration page) {
		
		String widgetNameString = null;
		
		if ( page.getSuperInterfaces().stream().filter( e -> e.getType().getName().equals("IsWidget")).findFirst().isPresent() ) {
			
			MethodDeclaration methodDeclaration = MethodDeclarationExtractor.getInstance().getMethodDeclarationFromClassDeclaration(page, "asWidget");
						
			widgetNameString = StatementExtractor.getInstance().getWidgtNameReturedByAsWidget(methodDeclaration);
		}
		
		return widgetNameString;
	}
	
	/**
	 * 
	 * @param page
	 * @return
	 */
	public String isPageContainInitWidget(ClassDeclaration page) {
		
		if ( page.getSuperClass().getType().getName().equals("Composite") ) {
			
		}
		
		return null;
	}
	
	
	public String getContainerElementPage(Page page, ClassDeclarationExtractor classDeclarationExtractor) {
		
		List<List<String>> listOfTree =  new ArrayList<>();
		
		ClassDeclaration viewClass = classDeclarationExtractor.getClassDeclaration(page);
				
		FragmentExtractor fragmentExtractor = FragmentExtractor.getInstance();		
		fragmentExtractor.setClassDeclaration(viewClass);
		

		for (Widget widget: page.getWidgets()) {
			
			VariableDeclarationFragment fragment = fragmentExtractor.getWidgetFromClassDeclaration(widget.getName());			
			List<Attribute> attributs = new ArrayList<>();			
			List<String> childTree = new ArrayList<>(); 
			
			if ( fragment != null ) {
				
				childTree.add(fragment.getName());  			
				if (fragment.getInitializer() !=null) {					
					attributs.add(fragmentExtractor.createAttributeFromVariableDeclaration(fragment));
				}
				
				for (SingleVariableAccess singleVariableAccess: fragment.getUsageInVariableAccess() ) {
					 
					if ( !fragmentExtractor.getAssignmentFromSVA(singleVariableAccess).isEmpty() 
															|| 
							!fragmentExtractor.getMethodInvocationsFromSVA(singleVariableAccess).isEmpty() ) {
						
						if ( !fragmentExtractor.createAttributesFromSva(singleVariableAccess).isEmpty() ) {
							
							FilterHelper.getInstance().filterAdd(childTree, fragmentExtractor.createAttributesFromSva(singleVariableAccess).get(0));
						}						 	
						 	
					} 
					
					else if ( !fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess).isEmpty() ) {												
						for (List<Attribute> attributes: fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess)) {							 
							   FilterHelper.getInstance().filterAdd(childTree ,attributes.get(0));
						}						
					}
				 
				}
				
			}
			
			if (childTree.size() > 1 ) {
				listOfTree.add(childTree);

			}
				
		}
		return getElementRootOfPage(viewClass, listOfTree);
	}
	
	public String getElementRootOfPage(ClassDeclaration page, List<List<String>> listElements) {
		
		String root =  isPageImplementIsWidget(page);
		
		if ( (root == null) && (listElements.size() > 0) ) {			
			root = listElements.get(0).get(0);			
		} 		
		return root;
	}
	
}
