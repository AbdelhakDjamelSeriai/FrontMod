package main.java.lirmm.angularGenerator.runner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;

import kdm.code.gwt.GwtModel;
import kdm.kdm.Segment;
import main.java.lirmm.angularGenerator.angular.ng.commands.AngularConfigurations;
import main.java.lirmm.angularGenerator.angular.ng.commands.Director;
import main.java.lirmm.angularGenerator.dao.GwtDaoImpl;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gwt.GwtModelExtractor;
import main.java.lirmm.angularGenerator.gwt.SegmentExtractor;
import main.java.lirmm.angularGenerator.iterators.AngularGenerator;
import main.java.lirmm.angularGenerator.iterators.PageIterator;
import main.java.lirmm.angularGenerator.iterators.PagesCollection;
import main.java.lirmm.angularGenerator.json.GWTModelFileReader;
import main.java.lirmm.angularGenerator.json.JSONFileReader;
import main.java.lirmm.angularGenerator.json.NavigationalModelFileReader;
import main.java.lirmm.angularGenerator.pivotModel.PivotModelReader;


public class Luncher {
	
	
	public static void main(String[] args) throws IOException {		
		
		/**
		 *  Generate Pivot Model as JSON File 
		 */
		
		List<Path> gwtKdmModelPaths =  Files.walk(Paths.get("models/inputs/gwt-kdm-model")).filter(Files::isRegularFile).collect(Collectors.toList());

		List<Path> javaModelPaths =  Files.walk(Paths.get("models/inputs/java-model")).filter(Files::isRegularFile).collect(Collectors.toList());

		List<Path> navigationModelPaths =  Files.walk(Paths.get("models/inputs/navigation-model")).filter(Files::isRegularFile).collect(Collectors.toList());
		
		/**
		 * 
		 * 
		 */
		
		SegmentExtractor segmentExtractor = SegmentExtractor.getInstance(gwtKdmModelPaths.get(0).toString());		
		
		Segment segment = segmentExtractor.getSegment();
		
		ClassDeclarationExtractor classDeclarationExtractor = ClassDeclarationExtractor.getInstance(javaModelPaths.get(0).toString());
				
		GwtModel gwtModel = GwtModelExtractor.getInstance().getGwtModelFromSegment(segment);
								
		NavigationalModelFileReader navigationalModel = new NavigationalModelFileReader(navigationModelPaths.get(0).toString());
		
		List<String> exptectedPages =  navigationalModel.getTruePagesNames();
		
		GwtDaoImpl gwtDaoImpl = new GwtDaoImpl("models/outputs/model_pivot_app.json", exptectedPages , gwtModel, classDeclarationExtractor);
		
		gwtDaoImpl.saveGwtWidgets();
		
		
		
		/**
		 * Create Angular Modules and Components 
		 * 
		 * Page -> Module, 
		 * 
		 * Widget -> Component
		 * 
		 */
	
		//(new Director(ngConfigurations)).make(pages);

		
		/*JSONFileReader pivotModel = new GWTModelFileReader("model_pivot_app.json");
		
		JSONArray pages = new PivotModelReader(pivotModel).getPages();
		
		// ---> inject configurations into this components !!
		
		AngularConfigurations ngConfigurations = new AngularConfigurations();
		
	    //(new Director("C:\\Users\\gm_be\\PhpstormProjects\\", "template-project-angular")).make(pages);
		
		(new Director(ngConfigurations)).make(pages);
		
		
	    /**
		 * 
		 * Fill Components and make routes
		 * 
		 */
	    /*AngularGenerator angularGenerator = new AngularGenerator();
	    
	    PageIterator pageIterator = new PageIterator(angularGenerator, ngConfigurations);
	    
		PagesCollection pagesCollection = new PagesCollection(pages, pageIterator);
		
		pagesCollection.iteratePages();*/
		
	}
	
	

}
