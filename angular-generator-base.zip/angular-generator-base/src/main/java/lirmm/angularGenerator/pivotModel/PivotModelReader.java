package main.java.lirmm.angularGenerator.pivotModel;

import org.json.simple.JSONArray;

import main.java.lirmm.angularGenerator.json.JSONFileReader;

public class PivotModelReader {
	
	
	private JSONArray pages;
	
	public PivotModelReader(JSONFileReader reader) {
		
		pages = (JSONArray)reader.parseData();
	}

	public JSONArray getPages() {
		
		return pages;
	}

}
