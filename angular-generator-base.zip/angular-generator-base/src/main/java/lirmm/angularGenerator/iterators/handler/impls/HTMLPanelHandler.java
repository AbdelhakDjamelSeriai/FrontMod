package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HTMLPanelHandler extends Handler{


    public HTMLPanelHandler(){
    	selector = "<lirmm-h-t-m-l-panel></lirmm-h-t-m-l-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("HTMLPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String addAndReplaceElement(JSONObject action) {
		// TODO Auto-generated addAndReplaceElement stub 
     // complete your Implementation 
		return selector;
	}




}