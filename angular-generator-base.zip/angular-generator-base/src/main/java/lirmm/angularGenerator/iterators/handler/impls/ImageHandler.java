package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ImageHandler extends Handler{


    public ImageHandler(){
    	selector = "<lirmm-image></lirmm-image>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Image");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String prefetch(JSONObject action) {
		// TODO Auto-generated prefetch stub 
     // complete your Implementation 
		return selector;
	}



	private String addClickListener(JSONObject action) {
		// TODO Auto-generated addClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addLoadListener(JSONObject action) {
		// TODO Auto-generated addLoadListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseListener(JSONObject action) {
		// TODO Auto-generated addMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseWheelListener(JSONObject action) {
		// TODO Auto-generated addMouseWheelListener stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String removeClickListener(JSONObject action) {
		// TODO Auto-generated removeClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeLoadListener(JSONObject action) {
		// TODO Auto-generated removeLoadListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseListener(JSONObject action) {
		// TODO Auto-generated removeMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseWheelListener(JSONObject action) {
		// TODO Auto-generated removeMouseWheelListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setAltText(JSONObject action) {
		// TODO Auto-generated setAltText stub 
     // complete your Implementation 
		return selector;
	}



	private String setResource(JSONObject action) {
		// TODO Auto-generated setResource stub 
     // complete your Implementation 
		return selector;
	}



	private String setUrl(JSONObject action) {
		// TODO Auto-generated setUrl stub 
     // complete your Implementation 
		return selector;
	}



	private String setUrlAndVisibleRect(JSONObject action) {
		// TODO Auto-generated setUrlAndVisibleRect stub 
     // complete your Implementation 
		return selector;
	}



	private String setVisibleRect(JSONObject action) {
		// TODO Auto-generated setVisibleRect stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String changeState(JSONObject action) {
		// TODO Auto-generated changeState stub 
     // complete your Implementation 
		return selector;
	}



	private String clearUnhandledEvent(JSONObject action) {
		// TODO Auto-generated clearUnhandledEvent stub 
     // complete your Implementation 
		return selector;
	}




}