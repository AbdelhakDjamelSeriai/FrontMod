package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class VerticalPanelHandler extends Handler{


    public VerticalPanelHandler(){
    	selector = "<lirmm-vertical-panel></lirmm-vertical-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("VerticalPanel");
	}


	@Override
	public String handle() {
		
		String ngContent = "";
		
		for (int i = 0; i< actions.size(); i++) {
			
			JSONObject action = (JSONObject) actions.get(i);
			
			if (action.get("add")!=null) {
				
				String nameComponent = "";
				
				if (! ((JSONArray)((JSONObject)(action.get("add"))).get("args")).isEmpty() ) {
					nameComponent = ((String)((JSONArray)((JSONObject)(action.get("add"))).get("args")).get(0)).toLowerCase();
				}

				
				String selector =  "<app-"+nameComponent+"></app-"+nameComponent+">";
								
				String warpper = "<tr><td align=\"left\" style=\"vertical-align: top;\">"+selector+"</td></tr>";

				ngContent += warpper;
			}
			
		}
		
		
		selector = "<lirmm-horizontal-panel>"+ ngContent +"</lirmm-horizontal-panel>";
		
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String setHorizontalAlignment(JSONObject action) {
		// TODO Auto-generated setHorizontalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setVerticalAlignment(JSONObject action) {
		// TODO Auto-generated setVerticalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}




}