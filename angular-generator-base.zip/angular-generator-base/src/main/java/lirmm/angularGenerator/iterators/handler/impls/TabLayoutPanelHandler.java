package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TabLayoutPanelHandler extends Handler{


    public TabLayoutPanelHandler(){
    	selector = "<lirmm-tab-layout-panel></lirmm-tab-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("TabLayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String animate(JSONObject action) {
		// TODO Auto-generated animate stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String forceLayout(JSONObject action) {
		// TODO Auto-generated forceLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String selectTab(JSONObject action) {
		// TODO Auto-generated selectTab stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationDuration(JSONObject action) {
		// TODO Auto-generated setAnimationDuration stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationVertical(JSONObject action) {
		// TODO Auto-generated setAnimationVertical stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabHTML(JSONObject action) {
		// TODO Auto-generated setTabHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabText(JSONObject action) {
		// TODO Auto-generated setTabText stub 
     // complete your Implementation 
		return selector;
	}



	private String checkChild(JSONObject action) {
		// TODO Auto-generated checkChild stub 
     // complete your Implementation 
		return selector;
	}



	private String checkIndex(JSONObject action) {
		// TODO Auto-generated checkIndex stub 
     // complete your Implementation 
		return selector;
	}




}