package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class CustomScrollPanelHandler extends Handler{


    public CustomScrollPanelHandler(){
    	selector = "<lirmm-custom-scroll-panel></lirmm-custom-scroll-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("CustomScrollPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String removeHorizontalScrollbar(JSONObject action) {
		// TODO Auto-generated removeHorizontalScrollbar stub 
     // complete your Implementation 
		return selector;
	}



	private String removeVerticalScrollbar(JSONObject action) {
		// TODO Auto-generated removeVerticalScrollbar stub 
     // complete your Implementation 
		return selector;
	}



	private String setAlwaysShowScrollBars(JSONObject action) {
		// TODO Auto-generated setAlwaysShowScrollBars stub 
     // complete your Implementation 
		return selector;
	}



	private String setHorizontalScrollbar(JSONObject action) {
		// TODO Auto-generated setHorizontalScrollbar stub 
     // complete your Implementation 
		return selector;
	}



	private String setVerticalScrollbar(JSONObject action) {
		// TODO Auto-generated setVerticalScrollbar stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String doAttachChildren(JSONObject action) {
		// TODO Auto-generated doAttachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String doDetachChildren(JSONObject action) {
		// TODO Auto-generated doDetachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String hideNativeScrollbars(JSONObject action) {
		// TODO Auto-generated hideNativeScrollbars stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeUpdateScrollbarPositions(JSONObject action) {
		// TODO Auto-generated maybeUpdateScrollbarPositions stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeUpdateScrollbars(JSONObject action) {
		// TODO Auto-generated maybeUpdateScrollbars stub 
     // complete your Implementation 
		return selector;
	}




}