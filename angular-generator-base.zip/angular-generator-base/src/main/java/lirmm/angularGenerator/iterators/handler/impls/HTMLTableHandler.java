package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HTMLTableHandler extends Handler{


    public HTMLTableHandler(){
    	selector = "<lirmm-h-t-m-l-table></lirmm-h-t-m-l-table>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("HTMLTable");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addTableListener(JSONObject action) {
		// TODO Auto-generated addTableListener stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String removeTableListener(JSONObject action) {
		// TODO Auto-generated removeTableListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setBorderWidth(JSONObject action) {
		// TODO Auto-generated setBorderWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellPadding(JSONObject action) {
		// TODO Auto-generated setCellPadding stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellSpacing(JSONObject action) {
		// TODO Auto-generated setCellSpacing stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String checkCellBounds(JSONObject action) {
		// TODO Auto-generated checkCellBounds stub 
     // complete your Implementation 
		return selector;
	}



	private String checkRowBounds(JSONObject action) {
		// TODO Auto-generated checkRowBounds stub 
     // complete your Implementation 
		return selector;
	}



	private String insertCell(JSONObject action) {
		// TODO Auto-generated insertCell stub 
     // complete your Implementation 
		return selector;
	}



	private String insertCells(JSONObject action) {
		// TODO Auto-generated insertCells stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareCell(JSONObject action) {
		// TODO Auto-generated prepareCell stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareColumn(JSONObject action) {
		// TODO Auto-generated prepareColumn stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareRow(JSONObject action) {
		// TODO Auto-generated prepareRow stub 
     // complete your Implementation 
		return selector;
	}



	private String removeCell(JSONObject action) {
		// TODO Auto-generated removeCell stub 
     // complete your Implementation 
		return selector;
	}



	private String removeRow(JSONObject action) {
		// TODO Auto-generated removeRow stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellFormatter(JSONObject action) {
		// TODO Auto-generated setCellFormatter stub 
     // complete your Implementation 
		return selector;
	}



	private String setColumnFormatter(JSONObject action) {
		// TODO Auto-generated setColumnFormatter stub 
     // complete your Implementation 
		return selector;
	}



	private String setRowFormatter(JSONObject action) {
		// TODO Auto-generated setRowFormatter stub 
     // complete your Implementation 
		return selector;
	}



	private String addCells(JSONObject action) {
		// TODO Auto-generated addCells stub 
     // complete your Implementation 
		return selector;
	}




}