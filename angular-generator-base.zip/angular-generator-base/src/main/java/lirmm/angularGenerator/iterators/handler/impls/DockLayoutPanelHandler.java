package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DockLayoutPanelHandler extends Handler{


    public DockLayoutPanelHandler(){
    	selector = "<lirmm-dock-layout-panel></lirmm-dock-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DockLayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String addEast(JSONObject action) {
		// TODO Auto-generated addEast stub 
     // complete your Implementation 
		return selector;
	}



	private String addLineEnd(JSONObject action) {
		// TODO Auto-generated addLineEnd stub 
     // complete your Implementation 
		return selector;
	}



	private String addLineStart(JSONObject action) {
		// TODO Auto-generated addLineStart stub 
     // complete your Implementation 
		return selector;
	}



	private String addNorth(JSONObject action) {
		// TODO Auto-generated addNorth stub 
     // complete your Implementation 
		return selector;
	}



	private String addSouth(JSONObject action) {
		// TODO Auto-generated addSouth stub 
     // complete your Implementation 
		return selector;
	}



	private String addWest(JSONObject action) {
		// TODO Auto-generated addWest stub 
     // complete your Implementation 
		return selector;
	}



	private String animate(JSONObject action) {
		// TODO Auto-generated animate stub 
     // complete your Implementation 
		return selector;
	}



	private String forceLayout(JSONObject action) {
		// TODO Auto-generated forceLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String insertEast(JSONObject action) {
		// TODO Auto-generated insertEast stub 
     // complete your Implementation 
		return selector;
	}



	private String insertLineEnd(JSONObject action) {
		// TODO Auto-generated insertLineEnd stub 
     // complete your Implementation 
		return selector;
	}



	private String insertLineStart(JSONObject action) {
		// TODO Auto-generated insertLineStart stub 
     // complete your Implementation 
		return selector;
	}



	private String insertNorth(JSONObject action) {
		// TODO Auto-generated insertNorth stub 
     // complete your Implementation 
		return selector;
	}



	private String insertSouth(JSONObject action) {
		// TODO Auto-generated insertSouth stub 
     // complete your Implementation 
		return selector;
	}



	private String insertWest(JSONObject action) {
		// TODO Auto-generated insertWest stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetHidden(JSONObject action) {
		// TODO Auto-generated setWidgetHidden stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetSize(JSONObject action) {
		// TODO Auto-generated setWidgetSize stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String assertIsChild(JSONObject action) {
		// TODO Auto-generated assertIsChild stub 
     // complete your Implementation 
		return selector;
	}



	private String doLayout(JSONObject action) {
		// TODO Auto-generated doLayout stub 
     // complete your Implementation 
		return selector;
	}




}