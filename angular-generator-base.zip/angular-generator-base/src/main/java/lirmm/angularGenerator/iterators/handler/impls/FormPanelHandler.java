package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class FormPanelHandler extends Handler{


    public FormPanelHandler(){
    	selector = "<lirmm-form-panel></lirmm-form-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("FormPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addFormHandler(JSONObject action) {
		// TODO Auto-generated addFormHandler stub 
     // complete your Implementation 
		return selector;
	}



	private String onFrameLoad(JSONObject action) {
		// TODO Auto-generated onFrameLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String removeFormHandler(JSONObject action) {
		// TODO Auto-generated removeFormHandler stub 
     // complete your Implementation 
		return selector;
	}



	private String reset(JSONObject action) {
		// TODO Auto-generated reset stub 
     // complete your Implementation 
		return selector;
	}



	private String setAction(JSONObject action) {
		// TODO Auto-generated setAction stub 
     // complete your Implementation 
		return selector;
	}



	private String setEncoding(JSONObject action) {
		// TODO Auto-generated setEncoding stub 
     // complete your Implementation 
		return selector;
	}



	private String setMethod(JSONObject action) {
		// TODO Auto-generated setMethod stub 
     // complete your Implementation 
		return selector;
	}



	private String submit(JSONObject action) {
		// TODO Auto-generated submit stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String createFrame(JSONObject action) {
		// TODO Auto-generated createFrame stub 
     // complete your Implementation 
		return selector;
	}



	private String onFrameLoadImpl(JSONObject action) {
		// TODO Auto-generated onFrameLoadImpl stub 
     // complete your Implementation 
		return selector;
	}



	private String setTarget(JSONObject action) {
		// TODO Auto-generated setTarget stub 
     // complete your Implementation 
		return selector;
	}




}