package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class CellPanelHandler extends Handler{


    public CellPanelHandler(){
    	selector = "<lirmm-cell-panel></lirmm-cell-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("CellPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setBorderWidth(JSONObject action) {
		// TODO Auto-generated setBorderWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellHeight(JSONObject action) {
		// TODO Auto-generated setCellHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellHorizontalAlignment(JSONObject action) {
		// TODO Auto-generated setCellHorizontalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellVerticalAlignment(JSONObject action) {
		// TODO Auto-generated setCellVerticalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellWidth(JSONObject action) {
		// TODO Auto-generated setCellWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setSpacing(JSONObject action) {
		// TODO Auto-generated setSpacing stub 
     // complete your Implementation 
		return selector;
	}




}