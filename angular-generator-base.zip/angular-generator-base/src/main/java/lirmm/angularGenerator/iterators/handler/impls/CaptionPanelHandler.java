package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class CaptionPanelHandler extends Handler{


    public CaptionPanelHandler(){
    	selector = "<lirmm-caption-panel></lirmm-caption-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("CaptionPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String setCaptionHTML(JSONObject action) {
		// TODO Auto-generated setCaptionHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setCaptionText(JSONObject action) {
		// TODO Auto-generated setCaptionText stub 
     // complete your Implementation 
		return selector;
	}



	private String setContentWidget(JSONObject action) {
		// TODO Auto-generated setContentWidget stub 
     // complete your Implementation 
		return selector;
	}




}