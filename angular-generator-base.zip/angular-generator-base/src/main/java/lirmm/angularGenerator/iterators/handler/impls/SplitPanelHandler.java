package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class SplitPanelHandler extends Handler{


    public SplitPanelHandler(){
    	selector = "<lirmm-split-panel></lirmm-split-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("SplitPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addAbsolutePositoning(JSONObject action) {
		// TODO Auto-generated addAbsolutePositoning stub 
     // complete your Implementation 
		return selector;
	}



	private String addClipping(JSONObject action) {
		// TODO Auto-generated addClipping stub 
     // complete your Implementation 
		return selector;
	}



	private String addScrolling(JSONObject action) {
		// TODO Auto-generated addScrolling stub 
     // complete your Implementation 
		return selector;
	}



	private String expandToFitParentUsingCssOffsets(JSONObject action) {
		// TODO Auto-generated expandToFitParentUsingCssOffsets stub 
     // complete your Implementation 
		return selector;
	}



	private String expandToFitParentUsingPercentages(JSONObject action) {
		// TODO Auto-generated expandToFitParentUsingPercentages stub 
     // complete your Implementation 
		return selector;
	}



	private String setBottom(JSONObject action) {
		// TODO Auto-generated setBottom stub 
     // complete your Implementation 
		return selector;
	}



	private String setClassname(JSONObject action) {
		// TODO Auto-generated setClassname stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeight(JSONObject action) {
		// TODO Auto-generated setHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setLeft(JSONObject action) {
		// TODO Auto-generated setLeft stub 
     // complete your Implementation 
		return selector;
	}



	private String setRight(JSONObject action) {
		// TODO Auto-generated setRight stub 
     // complete your Implementation 
		return selector;
	}



	private String setTop(JSONObject action) {
		// TODO Auto-generated setTop stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidth(JSONObject action) {
		// TODO Auto-generated setWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String setSplitPosition(JSONObject action) {
		// TODO Auto-generated setSplitPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onSplitterResize(JSONObject action) {
		// TODO Auto-generated onSplitterResize stub 
     // complete your Implementation 
		return selector;
	}



	private String onSplitterResizeStarted(JSONObject action) {
		// TODO Auto-generated onSplitterResizeStarted stub 
     // complete your Implementation 
		return selector;
	}



	private String startResizingFrom(JSONObject action) {
		// TODO Auto-generated startResizingFrom stub 
     // complete your Implementation 
		return selector;
	}



	private String stopResizing(JSONObject action) {
		// TODO Auto-generated stopResizing stub 
     // complete your Implementation 
		return selector;
	}




}