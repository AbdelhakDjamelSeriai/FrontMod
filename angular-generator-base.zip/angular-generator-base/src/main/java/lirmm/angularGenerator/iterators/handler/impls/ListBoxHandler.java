package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ListBoxHandler extends Handler{


    public ListBoxHandler(){
    	selector = "<lirmm-list-box></lirmm-list-box>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("ListBox");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addChangeListener(JSONObject action) {
		// TODO Auto-generated addChangeListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addItem(JSONObject action) {
		// TODO Auto-generated addItem stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String insertItem(JSONObject action) {
		// TODO Auto-generated insertItem stub 
     // complete your Implementation 
		return selector;
	}



	private String removeChangeListener(JSONObject action) {
		// TODO Auto-generated removeChangeListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeItem(JSONObject action) {
		// TODO Auto-generated removeItem stub 
     // complete your Implementation 
		return selector;
	}



	private String setDirectionEstimator(JSONObject action) {
		// TODO Auto-generated setDirectionEstimator stub 
     // complete your Implementation 
		return selector;
	}



	private String setItemSelected(JSONObject action) {
		// TODO Auto-generated setItemSelected stub 
     // complete your Implementation 
		return selector;
	}



	private String setItemText(JSONObject action) {
		// TODO Auto-generated setItemText stub 
     // complete your Implementation 
		return selector;
	}



	private String setMultipleSelect(JSONObject action) {
		// TODO Auto-generated setMultipleSelect stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String setSelectedIndex(JSONObject action) {
		// TODO Auto-generated setSelectedIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String setValue(JSONObject action) {
		// TODO Auto-generated setValue stub 
     // complete your Implementation 
		return selector;
	}



	private String setVisibleItemCount(JSONObject action) {
		// TODO Auto-generated setVisibleItemCount stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String setOptionText(JSONObject action) {
		// TODO Auto-generated setOptionText stub 
     // complete your Implementation 
		return selector;
	}



	private String checkIndex(JSONObject action) {
		// TODO Auto-generated checkIndex stub 
     // complete your Implementation 
		return selector;
	}




}