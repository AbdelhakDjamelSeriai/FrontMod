package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class MenuItemSeparatorHandler extends Handler{


    public MenuItemSeparatorHandler(){
    	selector = "<lirmm-menu-item-separator></lirmm-menu-item-separator>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("MenuItemSeparator");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setParentMenu(JSONObject action) {
		// TODO Auto-generated setParentMenu stub 
     // complete your Implementation 
		return selector;
	}




}