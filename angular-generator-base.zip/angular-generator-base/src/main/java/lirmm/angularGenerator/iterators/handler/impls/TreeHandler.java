package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TreeHandler extends Handler{


    public TreeHandler(){
    	selector = "<lirmm-tree></lirmm-tree>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Tree");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String addFocusListener(JSONObject action) {
		// TODO Auto-generated addFocusListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addItem(JSONObject action) {
		// TODO Auto-generated addItem stub 
     // complete your Implementation 
		return selector;
	}



	private String addKeyboardListener(JSONObject action) {
		// TODO Auto-generated addKeyboardListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseListener(JSONObject action) {
		// TODO Auto-generated addMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addTreeListener(JSONObject action) {
		// TODO Auto-generated addTreeListener stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String ensureSelectedItemVisible(JSONObject action) {
		// TODO Auto-generated ensureSelectedItemVisible stub 
     // complete your Implementation 
		return selector;
	}



	private String insertItem(JSONObject action) {
		// TODO Auto-generated insertItem stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String removeFocusListener(JSONObject action) {
		// TODO Auto-generated removeFocusListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeItem(JSONObject action) {
		// TODO Auto-generated removeItem stub 
     // complete your Implementation 
		return selector;
	}



	private String removeItems(JSONObject action) {
		// TODO Auto-generated removeItems stub 
     // complete your Implementation 
		return selector;
	}



	private String removeKeyboardListener(JSONObject action) {
		// TODO Auto-generated removeKeyboardListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseListener(JSONObject action) {
		// TODO Auto-generated removeMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeTreeListener(JSONObject action) {
		// TODO Auto-generated removeTreeListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setAccessKey(JSONObject action) {
		// TODO Auto-generated setAccessKey stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocus(JSONObject action) {
		// TODO Auto-generated setFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String setScrollOnSelectEnabled(JSONObject action) {
		// TODO Auto-generated setScrollOnSelectEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setSelectedItem(JSONObject action) {
		// TODO Auto-generated setSelectedItem stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabIndex(JSONObject action) {
		// TODO Auto-generated setTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String doAttachChildren(JSONObject action) {
		// TODO Auto-generated doAttachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String doDetachChildren(JSONObject action) {
		// TODO Auto-generated doDetachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String adopt(JSONObject action) {
		// TODO Auto-generated adopt stub 
     // complete your Implementation 
		return selector;
	}



	private String fireStateChanged(JSONObject action) {
		// TODO Auto-generated fireStateChanged stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeUpdateSelection(JSONObject action) {
		// TODO Auto-generated maybeUpdateSelection stub 
     // complete your Implementation 
		return selector;
	}



	private String orphan(JSONObject action) {
		// TODO Auto-generated orphan stub 
     // complete your Implementation 
		return selector;
	}



	private String showClosedImage(JSONObject action) {
		// TODO Auto-generated showClosedImage stub 
     // complete your Implementation 
		return selector;
	}



	private String showLeafImage(JSONObject action) {
		// TODO Auto-generated showLeafImage stub 
     // complete your Implementation 
		return selector;
	}



	private String showOpenImage(JSONObject action) {
		// TODO Auto-generated showOpenImage stub 
     // complete your Implementation 
		return selector;
	}



	private String collectElementChain(JSONObject action) {
		// TODO Auto-generated collectElementChain stub 
     // complete your Implementation 
		return selector;
	}



	private String init(JSONObject action) {
		// TODO Auto-generated init stub 
     // complete your Implementation 
		return selector;
	}



	private String keyboardNavigation(JSONObject action) {
		// TODO Auto-generated keyboardNavigation stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeCollapseTreeItem(JSONObject action) {
		// TODO Auto-generated maybeCollapseTreeItem stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeExpandTreeItem(JSONObject action) {
		// TODO Auto-generated maybeExpandTreeItem stub 
     // complete your Implementation 
		return selector;
	}



	private String moveFocus(JSONObject action) {
		// TODO Auto-generated moveFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String moveSelectionDown(JSONObject action) {
		// TODO Auto-generated moveSelectionDown stub 
     // complete your Implementation 
		return selector;
	}



	private String moveSelectionUp(JSONObject action) {
		// TODO Auto-generated moveSelectionUp stub 
     // complete your Implementation 
		return selector;
	}



	private String onSelection(JSONObject action) {
		// TODO Auto-generated onSelection stub 
     // complete your Implementation 
		return selector;
	}



	private String setImages(JSONObject action) {
		// TODO Auto-generated setImages stub 
     // complete your Implementation 
		return selector;
	}



	private String showImage(JSONObject action) {
		// TODO Auto-generated showImage stub 
     // complete your Implementation 
		return selector;
	}



	private String updateAriaAttributes(JSONObject action) {
		// TODO Auto-generated updateAriaAttributes stub 
     // complete your Implementation 
		return selector;
	}




}