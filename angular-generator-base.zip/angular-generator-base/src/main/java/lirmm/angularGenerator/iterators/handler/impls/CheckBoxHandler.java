package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class CheckBoxHandler extends Handler{


    public CheckBoxHandler(){
    	selector = "<lirmm-check-box></lirmm-check-box>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("CheckBox");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setAccessKey(JSONObject action) {
		// TODO Auto-generated setAccessKey stub 
     // complete your Implementation 
		return selector;
	}



	private String setChecked(JSONObject action) {
		// TODO Auto-generated setChecked stub 
     // complete your Implementation 
		return selector;
	}



	private String setDirectionEstimator(JSONObject action) {
		// TODO Auto-generated setDirectionEstimator stub 
     // complete your Implementation 
		return selector;
	}



	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocus(JSONObject action) {
		// TODO Auto-generated setFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String setFormValue(JSONObject action) {
		// TODO Auto-generated setFormValue stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabIndex(JSONObject action) {
		// TODO Auto-generated setTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String setValue(JSONObject action) {
		// TODO Auto-generated setValue stub 
     // complete your Implementation 
		return selector;
	}



	private String setWordWrap(JSONObject action) {
		// TODO Auto-generated setWordWrap stub 
     // complete your Implementation 
		return selector;
	}



	private String sinkEvents(JSONObject action) {
		// TODO Auto-generated sinkEvents stub 
     // complete your Implementation 
		return selector;
	}



	private String ensureDomEventHandlers(JSONObject action) {
		// TODO Auto-generated ensureDomEventHandlers stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String onUnload(JSONObject action) {
		// TODO Auto-generated onUnload stub 
     // complete your Implementation 
		return selector;
	}



	private String replaceInputElement(JSONObject action) {
		// TODO Auto-generated replaceInputElement stub 
     // complete your Implementation 
		return selector;
	}




}