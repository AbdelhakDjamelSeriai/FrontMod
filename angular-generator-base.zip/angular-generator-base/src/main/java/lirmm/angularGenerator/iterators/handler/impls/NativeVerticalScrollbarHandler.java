package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class NativeVerticalScrollbarHandler extends Handler{


    public NativeVerticalScrollbarHandler(){
    	selector = "<lirmm-native-vertical-scrollbar></lirmm-native-vertical-scrollbar>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("NativeVerticalScrollbar");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setScrollHeight(JSONObject action) {
		// TODO Auto-generated setScrollHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setVerticalScrollPosition(JSONObject action) {
		// TODO Auto-generated setVerticalScrollPosition stub 
     // complete your Implementation 
		return selector;
	}




}