package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class LayoutPanelHandler extends Handler{


    public LayoutPanelHandler(){
    	selector = "<lirmm-layout-panel></lirmm-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("LayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String animate(JSONObject action) {
		// TODO Auto-generated animate stub 
     // complete your Implementation 
		return selector;
	}



	private String forceLayout(JSONObject action) {
		// TODO Auto-generated forceLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetBottomHeight(JSONObject action) {
		// TODO Auto-generated setWidgetBottomHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetHorizontalPosition(JSONObject action) {
		// TODO Auto-generated setWidgetHorizontalPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetLeftRight(JSONObject action) {
		// TODO Auto-generated setWidgetLeftRight stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetLeftWidth(JSONObject action) {
		// TODO Auto-generated setWidgetLeftWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetRightWidth(JSONObject action) {
		// TODO Auto-generated setWidgetRightWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetTopBottom(JSONObject action) {
		// TODO Auto-generated setWidgetTopBottom stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetTopHeight(JSONObject action) {
		// TODO Auto-generated setWidgetTopHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetVerticalPosition(JSONObject action) {
		// TODO Auto-generated setWidgetVerticalPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetVisible(JSONObject action) {
		// TODO Auto-generated setWidgetVisible stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String assertIsChild(JSONObject action) {
		// TODO Auto-generated assertIsChild stub 
     // complete your Implementation 
		return selector;
	}




}