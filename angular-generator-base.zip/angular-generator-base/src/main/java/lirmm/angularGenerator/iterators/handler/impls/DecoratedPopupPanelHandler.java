package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DecoratedPopupPanelHandler extends Handler{


    public DecoratedPopupPanelHandler(){
    	selector = "<lirmm-decorated-popup-panel></lirmm-decorated-popup-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DecoratedPopupPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String doAttachChildren(JSONObject action) {
		// TODO Auto-generated doAttachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String doDetachChildren(JSONObject action) {
		// TODO Auto-generated doDetachChildren stub 
     // complete your Implementation 
		return selector;
	}




}