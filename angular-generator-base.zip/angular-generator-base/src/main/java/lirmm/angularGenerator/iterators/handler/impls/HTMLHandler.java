package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HTMLHandler extends Handler{


    public HTMLHandler(){
    	selector = "<lirmm-h-t-m-l></lirmm-h-t-m-l>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("HTML");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}




}