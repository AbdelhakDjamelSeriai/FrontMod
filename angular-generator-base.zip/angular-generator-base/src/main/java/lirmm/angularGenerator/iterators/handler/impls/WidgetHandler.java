package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class WidgetHandler extends Handler{


    public WidgetHandler(){
    	selector = "<lirmm-widget></lirmm-widget>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Widget");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String fireEvent(JSONObject action) {
		// TODO Auto-generated fireEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String removeFromParent(JSONObject action) {
		// TODO Auto-generated removeFromParent stub 
     // complete your Implementation 
		return selector;
	}



	private String setLayoutData(JSONObject action) {
		// TODO Auto-generated setLayoutData stub 
     // complete your Implementation 
		return selector;
	}



	private String sinkEvents(JSONObject action) {
		// TODO Auto-generated sinkEvents stub 
     // complete your Implementation 
		return selector;
	}



	private String unsinkEvents(JSONObject action) {
		// TODO Auto-generated unsinkEvents stub 
     // complete your Implementation 
		return selector;
	}



	private String delegateEvent(JSONObject action) {
		// TODO Auto-generated delegateEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String doAttachChildren(JSONObject action) {
		// TODO Auto-generated doAttachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String doDetachChildren(JSONObject action) {
		// TODO Auto-generated doDetachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String onUnload(JSONObject action) {
		// TODO Auto-generated onUnload stub 
     // complete your Implementation 
		return selector;
	}



	private String replaceElement(JSONObject action) {
		// TODO Auto-generated replaceElement stub 
     // complete your Implementation 
		return selector;
	}



	private String setParent(JSONObject action) {
		// TODO Auto-generated setParent stub 
     // complete your Implementation 
		return selector;
	}




}