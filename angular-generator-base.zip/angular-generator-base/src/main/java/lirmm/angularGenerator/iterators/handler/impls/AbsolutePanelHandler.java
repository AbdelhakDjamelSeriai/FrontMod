package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class AbsolutePanelHandler extends Handler{


    public AbsolutePanelHandler(){
    	selector = "<lirmm-absolute-panel></lirmm-absolute-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("AbsolutePanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String changeToStaticPositioning(JSONObject action) {
		// TODO Auto-generated changeToStaticPositioning stub 
     // complete your Implementation 
		return selector;
	}



	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetPosition(JSONObject action) {
		// TODO Auto-generated setWidgetPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetPositionImpl(JSONObject action) {
		// TODO Auto-generated setWidgetPositionImpl stub 
     // complete your Implementation 
		return selector;
	}



	private String checkWidgetParent(JSONObject action) {
		// TODO Auto-generated checkWidgetParent stub 
     // complete your Implementation 
		return selector;
	}



	private String verifyPositionNotStatic(JSONObject action) {
		// TODO Auto-generated verifyPositionNotStatic stub 
     // complete your Implementation 
		return selector;
	}




}