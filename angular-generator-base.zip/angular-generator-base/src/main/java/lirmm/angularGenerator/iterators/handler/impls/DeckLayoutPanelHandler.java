package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DeckLayoutPanelHandler extends Handler{


    public DeckLayoutPanelHandler(){
    	selector = "<lirmm-deck-layout-panel></lirmm-deck-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DeckLayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String animate(JSONObject action) {
		// TODO Auto-generated animate stub 
     // complete your Implementation 
		return selector;
	}



	private String forceLayout(JSONObject action) {
		// TODO Auto-generated forceLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationDuration(JSONObject action) {
		// TODO Auto-generated setAnimationDuration stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationVertical(JSONObject action) {
		// TODO Auto-generated setAnimationVertical stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String showWidget(JSONObject action) {
		// TODO Auto-generated showWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String assertIsChild(JSONObject action) {
		// TODO Auto-generated assertIsChild stub 
     // complete your Implementation 
		return selector;
	}



	private String doAfterLayout(JSONObject action) {
		// TODO Auto-generated doAfterLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String doBeforeLayout(JSONObject action) {
		// TODO Auto-generated doBeforeLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetVisible(JSONObject action) {
		// TODO Auto-generated setWidgetVisible stub 
     // complete your Implementation 
		return selector;
	}




}