package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;




public class CompositeHandler extends Handler{

	private Handler[] mChildHandlers;
	
	
	private void setHandler(Handler [] handlers) {
		mChildHandlers = handlers ;
	}

    public CompositeHandler(){
    	selector = "<lirmm-composite></lirmm-composite>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Composite");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        
		
		/*for (int i = 0; i < nestedWidgets.size(); i++) {
			
			for () {
				
			}
		}*/
		
		/*for (Handler child: mChildHandlers ) {
			if ( child.support(widget) ) {
				   child.setActions(widget);
				   selector += child.handle();
			}
		}*/
		
		return selector;
	}

	private String claimElement(JSONObject action) {
		// TODO Auto-generated claimElement stub 
     // complete your Implementation 
		return selector;
	}



	private String initializeClaimedElement(JSONObject action) {
		// TODO Auto-generated initializeClaimedElement stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String render(JSONObject action) {
		// TODO Auto-generated render stub 
     // complete your Implementation 
		return selector;
	}



	private String checkInit(JSONObject action) {
		// TODO Auto-generated checkInit stub 
     // complete your Implementation 
		return selector;
	}



	private String initWidget(JSONObject action) {
		// TODO Auto-generated initWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}




}