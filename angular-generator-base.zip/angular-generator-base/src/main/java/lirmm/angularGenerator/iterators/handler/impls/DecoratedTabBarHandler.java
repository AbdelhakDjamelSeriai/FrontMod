package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DecoratedTabBarHandler extends Handler{


    public DecoratedTabBarHandler(){
    	selector = "<lirmm-decorated-tab-bar></lirmm-decorated-tab-bar>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DecoratedTabBar");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}


}