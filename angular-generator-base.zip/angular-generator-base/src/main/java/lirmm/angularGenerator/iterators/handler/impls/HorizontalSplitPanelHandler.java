package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HorizontalSplitPanelHandler extends Handler{


    public HorizontalSplitPanelHandler(){
    	selector = "<lirmm-horizontal-split-panel></lirmm-horizontal-split-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("HorizontalSplitPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String setEndOfLineWidget(JSONObject action) {
		// TODO Auto-generated setEndOfLineWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setLeftWidget(JSONObject action) {
		// TODO Auto-generated setLeftWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setRightWidget(JSONObject action) {
		// TODO Auto-generated setRightWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setSplitPosition(JSONObject action) {
		// TODO Auto-generated setSplitPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setStartOfLineWidget(JSONObject action) {
		// TODO Auto-generated setStartOfLineWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String onUnload(JSONObject action) {
		// TODO Auto-generated onUnload stub 
     // complete your Implementation 
		return selector;
	}



	private String onSplitterResize(JSONObject action) {
		// TODO Auto-generated onSplitterResize stub 
     // complete your Implementation 
		return selector;
	}



	private String onSplitterResizeStarted(JSONObject action) {
		// TODO Auto-generated onSplitterResizeStarted stub 
     // complete your Implementation 
		return selector;
	}



	private String buildDOM(JSONObject action) {
		// TODO Auto-generated buildDOM stub 
     // complete your Implementation 
		return selector;
	}




}