package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class StackPanelHandler extends Handler{


    public StackPanelHandler(){
    	selector = "<lirmm-stack-panel></lirmm-stack-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("StackPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String setStackText(JSONObject action) {
		// TODO Auto-generated setStackText stub 
     // complete your Implementation 
		return selector;
	}



	private String showStack(JSONObject action) {
		// TODO Auto-generated showStack stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String addHeaderStyleName(JSONObject action) {
		// TODO Auto-generated addHeaderStyleName stub 
     // complete your Implementation 
		return selector;
	}



	private String removeHeaderStyleName(JSONObject action) {
		// TODO Auto-generated removeHeaderStyleName stub 
     // complete your Implementation 
		return selector;
	}



	private String setStackContentVisible(JSONObject action) {
		// TODO Auto-generated setStackContentVisible stub 
     // complete your Implementation 
		return selector;
	}



	private String setStackVisible(JSONObject action) {
		// TODO Auto-generated setStackVisible stub 
     // complete your Implementation 
		return selector;
	}



	private String updateIndicesFrom(JSONObject action) {
		// TODO Auto-generated updateIndicesFrom stub 
     // complete your Implementation 
		return selector;
	}




}