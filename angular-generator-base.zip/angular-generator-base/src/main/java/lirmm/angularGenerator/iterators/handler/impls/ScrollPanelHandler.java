package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ScrollPanelHandler extends Handler{


    public ScrollPanelHandler(){
    	selector = "<lirmm-scroll-panel></lirmm-scroll-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("ScrollPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addScrollListener(JSONObject action) {
		// TODO Auto-generated addScrollListener stub 
     // complete your Implementation 
		return selector;
	}



	private String ensureVisible(JSONObject action) {
		// TODO Auto-generated ensureVisible stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String removeScrollListener(JSONObject action) {
		// TODO Auto-generated removeScrollListener stub 
     // complete your Implementation 
		return selector;
	}



	private String scrollToBottom(JSONObject action) {
		// TODO Auto-generated scrollToBottom stub 
     // complete your Implementation 
		return selector;
	}



	private String scrollToLeft(JSONObject action) {
		// TODO Auto-generated scrollToLeft stub 
     // complete your Implementation 
		return selector;
	}



	private String scrollToRight(JSONObject action) {
		// TODO Auto-generated scrollToRight stub 
     // complete your Implementation 
		return selector;
	}



	private String scrollToTop(JSONObject action) {
		// TODO Auto-generated scrollToTop stub 
     // complete your Implementation 
		return selector;
	}



	private String setAlwaysShowScrollBars(JSONObject action) {
		// TODO Auto-generated setAlwaysShowScrollBars stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeight(JSONObject action) {
		// TODO Auto-generated setHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setHorizontalScrollPosition(JSONObject action) {
		// TODO Auto-generated setHorizontalScrollPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setScrollPosition(JSONObject action) {
		// TODO Auto-generated setScrollPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setSize(JSONObject action) {
		// TODO Auto-generated setSize stub 
     // complete your Implementation 
		return selector;
	}



	private String setVerticalScrollPosition(JSONObject action) {
		// TODO Auto-generated setVerticalScrollPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidth(JSONObject action) {
		// TODO Auto-generated setWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String ensureVisibleImpl(JSONObject action) {
		// TODO Auto-generated ensureVisibleImpl stub 
     // complete your Implementation 
		return selector;
	}



	private String initialize(JSONObject action) {
		// TODO Auto-generated initialize stub 
     // complete your Implementation 
		return selector;
	}




}