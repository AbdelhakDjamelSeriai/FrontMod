package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DisclosurePanelHandler extends Handler{


    public DisclosurePanelHandler(){
    	selector = "<lirmm-disclosure-panel></lirmm-disclosure-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DisclosurePanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String addEventHandler(JSONObject action) {
		// TODO Auto-generated addEventHandler stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String removeEventHandler(JSONObject action) {
		// TODO Auto-generated removeEventHandler stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setContent(JSONObject action) {
		// TODO Auto-generated setContent stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeader(JSONObject action) {
		// TODO Auto-generated setHeader stub 
     // complete your Implementation 
		return selector;
	}



	private String setOpen(JSONObject action) {
		// TODO Auto-generated setOpen stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String fireEvent(JSONObject action) {
		// TODO Auto-generated fireEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String setContentDisplay(JSONObject action) {
		// TODO Auto-generated setContentDisplay stub 
     // complete your Implementation 
		return selector;
	}




}