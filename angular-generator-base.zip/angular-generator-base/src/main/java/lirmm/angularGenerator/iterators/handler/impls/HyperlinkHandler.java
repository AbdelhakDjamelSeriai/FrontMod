package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HyperlinkHandler extends Handler{


    public HyperlinkHandler(){
    	selector = "<lirmm-hyperlink></lirmm-hyperlink>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Hyperlink");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addClickListener(JSONObject action) {
		// TODO Auto-generated addClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String removeClickListener(JSONObject action) {
		// TODO Auto-generated removeClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setDirectionEstimator(JSONObject action) {
		// TODO Auto-generated setDirectionEstimator stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setTargetHistoryToken(JSONObject action) {
		// TODO Auto-generated setTargetHistoryToken stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}




}