package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TextBoxHandler extends Handler{


    public TextBoxHandler(){
    	selector = "<lirmm-text-box></lirmm-text-box>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("TextBox");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setMaxLength(JSONObject action) {
		// TODO Auto-generated setMaxLength stub 
     // complete your Implementation 
		return selector;
	}



	private String setVisibleLength(JSONObject action) {
		// TODO Auto-generated setVisibleLength stub 
     // complete your Implementation 
		return selector;
	}




}