package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TabPanelHandler extends Handler{


    public TabPanelHandler(){
    	selector = "<lirmm-tab-panel></lirmm-tab-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("TabPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String addTabListener(JSONObject action) {
		// TODO Auto-generated addTabListener stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String onTabSelected(JSONObject action) {
		// TODO Auto-generated onTabSelected stub 
     // complete your Implementation 
		return selector;
	}



	private String removeTabListener(JSONObject action) {
		// TODO Auto-generated removeTabListener stub 
     // complete your Implementation 
		return selector;
	}



	private String selectTab(JSONObject action) {
		// TODO Auto-generated selectTab stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}




}