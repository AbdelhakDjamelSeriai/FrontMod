package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class VerticalSplitPanelHandler extends Handler{


    public VerticalSplitPanelHandler(){
    	selector = "<lirmm-vertical-split-panel></lirmm-vertical-split-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("VerticalSplitPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setBottomWidget(JSONObject action) {
		// TODO Auto-generated setBottomWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeight(JSONObject action) {
		// TODO Auto-generated setHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setSplitPosition(JSONObject action) {
		// TODO Auto-generated setSplitPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setTopWidget(JSONObject action) {
		// TODO Auto-generated setTopWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String onUnload(JSONObject action) {
		// TODO Auto-generated onUnload stub 
     // complete your Implementation 
		return selector;
	}



	private String onSplitterResize(JSONObject action) {
		// TODO Auto-generated onSplitterResize stub 
     // complete your Implementation 
		return selector;
	}



	private String onSplitterResizeStarted(JSONObject action) {
		// TODO Auto-generated onSplitterResizeStarted stub 
     // complete your Implementation 
		return selector;
	}



	private String buildDOM(JSONObject action) {
		// TODO Auto-generated buildDOM stub 
     // complete your Implementation 
		return selector;
	}




}