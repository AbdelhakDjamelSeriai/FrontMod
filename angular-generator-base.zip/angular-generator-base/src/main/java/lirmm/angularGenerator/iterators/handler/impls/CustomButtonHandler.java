package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class CustomButtonHandler extends Handler{


    public CustomButtonHandler(){
    	selector = "<lirmm-custom-button></lirmm-custom-button>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("CustomButton");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String setAccessKey(JSONObject action) {
		// TODO Auto-generated setAccessKey stub 
     // complete your Implementation 
		return selector;
	}



	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocus(JSONObject action) {
		// TODO Auto-generated setFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabIndex(JSONObject action) {
		// TODO Auto-generated setTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onClick(JSONObject action) {
		// TODO Auto-generated onClick stub 
     // complete your Implementation 
		return selector;
	}



	private String onClickCancel(JSONObject action) {
		// TODO Auto-generated onClickCancel stub 
     // complete your Implementation 
		return selector;
	}



	private String onClickStart(JSONObject action) {
		// TODO Auto-generated onClickStart stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String setDown(JSONObject action) {
		// TODO Auto-generated setDown stub 
     // complete your Implementation 
		return selector;
	}



	private String finishSetup(JSONObject action) {
		// TODO Auto-generated finishSetup stub 
     // complete your Implementation 
		return selector;
	}



	private String fireClickListeners(JSONObject action) {
		// TODO Auto-generated fireClickListeners stub 
     // complete your Implementation 
		return selector;
	}



	private String setCurrentFace(JSONObject action) {
		// TODO Auto-generated setCurrentFace stub 
     // complete your Implementation 
		return selector;
	}



	private String setHovering(JSONObject action) {
		// TODO Auto-generated setHovering stub 
     // complete your Implementation 
		return selector;
	}



	private String toggleDown(JSONObject action) {
		// TODO Auto-generated toggleDown stub 
     // complete your Implementation 
		return selector;
	}



	private String cleanupCaptureState(JSONObject action) {
		// TODO Auto-generated cleanupCaptureState stub 
     // complete your Implementation 
		return selector;
	}



	private String setAriaPressed(JSONObject action) {
		// TODO Auto-generated setAriaPressed stub 
     // complete your Implementation 
		return selector;
	}



	private String setCurrentFaceElement(JSONObject action) {
		// TODO Auto-generated setCurrentFaceElement stub 
     // complete your Implementation 
		return selector;
	}



	private String setDownDisabledFace(JSONObject action) {
		// TODO Auto-generated setDownDisabledFace stub 
     // complete your Implementation 
		return selector;
	}



	private String setDownFace(JSONObject action) {
		// TODO Auto-generated setDownFace stub 
     // complete your Implementation 
		return selector;
	}



	private String setDownHoveringFace(JSONObject action) {
		// TODO Auto-generated setDownHoveringFace stub 
     // complete your Implementation 
		return selector;
	}



	private String setUpDisabledFace(JSONObject action) {
		// TODO Auto-generated setUpDisabledFace stub 
     // complete your Implementation 
		return selector;
	}



	private String setUpFace(JSONObject action) {
		// TODO Auto-generated setUpFace stub 
     // complete your Implementation 
		return selector;
	}



	private String setUpHoveringFace(JSONObject action) {
		// TODO Auto-generated setUpHoveringFace stub 
     // complete your Implementation 
		return selector;
	}



	private String toggleDisabled(JSONObject action) {
		// TODO Auto-generated toggleDisabled stub 
     // complete your Implementation 
		return selector;
	}



	private String toggleHover(JSONObject action) {
		// TODO Auto-generated toggleHover stub 
     // complete your Implementation 
		return selector;
	}




}