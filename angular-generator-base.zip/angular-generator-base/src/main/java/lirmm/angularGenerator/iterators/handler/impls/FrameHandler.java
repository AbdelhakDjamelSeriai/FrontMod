package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class FrameHandler extends Handler{


    public FrameHandler(){
    	selector = "<lirmm-frame></lirmm-frame>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Frame");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setUrl(JSONObject action) {
		// TODO Auto-generated setUrl stub 
     // complete your Implementation 
		return selector;
	}




}