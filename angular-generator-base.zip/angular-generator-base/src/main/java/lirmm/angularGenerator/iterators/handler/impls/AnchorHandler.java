package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class AnchorHandler extends Handler{


    public AnchorHandler(){
    	selector = "<lirmm-anchor></lirmm-anchor>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Anchor");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setAccessKey(JSONObject action) {
		// TODO Auto-generated setAccessKey stub 
     // complete your Implementation 
		return selector;
	}



	private String setDirection(JSONObject action) {
		// TODO Auto-generated setDirection stub 
     // complete your Implementation 
		return selector;
	}



	private String setDirectionEstimator(JSONObject action) {
		// TODO Auto-generated setDirectionEstimator stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocus(JSONObject action) {
		// TODO Auto-generated setFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String setHorizontalAlignment(JSONObject action) {
		// TODO Auto-generated setHorizontalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setHref(JSONObject action) {
		// TODO Auto-generated setHref stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabIndex(JSONObject action) {
		// TODO Auto-generated setTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String setTarget(JSONObject action) {
		// TODO Auto-generated setTarget stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String setWordWrap(JSONObject action) {
		// TODO Auto-generated setWordWrap stub 
     // complete your Implementation 
		return selector;
	}




}