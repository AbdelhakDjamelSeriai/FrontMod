package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TextAreaHandler extends Handler{


    public TextAreaHandler(){
    	selector = "<lirmm-text-area></lirmm-text-area>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("TextArea");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setCharacterWidth(JSONObject action) {
		// TODO Auto-generated setCharacterWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setVisibleLines(JSONObject action) {
		// TODO Auto-generated setVisibleLines stub 
     // complete your Implementation 
		return selector;
	}




}