package main.java.lirmm.angularGenerator.iterators;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.angular.ng.commands.AngularConfigurations;

public class PageIterator {
	
	private JSONArray widgets;
	
	private String pageName;
	
	private AngularGenerator angularGenerator;
	
	private AngularConfigurations configurations;
	
	public PageIterator(AngularGenerator angularGenerator, AngularConfigurations configs) {
		
		this.angularGenerator = angularGenerator;
		
		configurations = configs;
	}
	
	
	public List<String> iteratePage(JSONObject page) {
		
		List<String> list = new ArrayList<>();
		
		pageName = (String)page.get("Page");
		
		widgets = (JSONArray) page.get("Widgets");
		
		widgets.forEach(widget -> list.add(analyseWidget( (JSONObject)widget)));
		
		return list;
	}
	
	private String analyseWidget(JSONObject widget) {
		
		String outerHtml = angularGenerator.iterateWidget(widget);
		
		fillComponenet(outerHtml,widget);
		
		return outerHtml;
		
	}
	
	private void fillComponenet(String content,JSONObject widget) {
		
		BufferedWriter output = null;
		
		String widgetName = ((String)widget.get("name")).toLowerCase();
		
		String componentPath = configurations.componentSpace+ "\\templates\\" + pageName.toLowerCase() + "\\" + widgetName ;
		
		
		try {
			
		    // add content of component 
		    output = new BufferedWriter(new FileWriter(componentPath+ "\\"+widgetName+".component.html"));
            output.write(content);
           
            
            output.close();
            
	   } catch (Exception e) {
		   e.printStackTrace();
		}
	}

}
