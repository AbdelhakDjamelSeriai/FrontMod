package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TabBarHandler extends Handler{


    public TabBarHandler(){
    	selector = "<lirmm-tab-bar></lirmm-tab-bar>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("TabBar");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addTab(JSONObject action) {
		// TODO Auto-generated addTab stub 
     // complete your Implementation 
		return selector;
	}



	private String addTabListener(JSONObject action) {
		// TODO Auto-generated addTabListener stub 
     // complete your Implementation 
		return selector;
	}



	private String insertTab(JSONObject action) {
		// TODO Auto-generated insertTab stub 
     // complete your Implementation 
		return selector;
	}



	private String onClick(JSONObject action) {
		// TODO Auto-generated onClick stub 
     // complete your Implementation 
		return selector;
	}



	private String onKeyDown(JSONObject action) {
		// TODO Auto-generated onKeyDown stub 
     // complete your Implementation 
		return selector;
	}



	private String onKeyPress(JSONObject action) {
		// TODO Auto-generated onKeyPress stub 
     // complete your Implementation 
		return selector;
	}



	private String onKeyUp(JSONObject action) {
		// TODO Auto-generated onKeyUp stub 
     // complete your Implementation 
		return selector;
	}



	private String removeTab(JSONObject action) {
		// TODO Auto-generated removeTab stub 
     // complete your Implementation 
		return selector;
	}



	private String removeTabListener(JSONObject action) {
		// TODO Auto-generated removeTabListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabEnabled(JSONObject action) {
		// TODO Auto-generated setTabEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabHTML(JSONObject action) {
		// TODO Auto-generated setTabHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabText(JSONObject action) {
		// TODO Auto-generated setTabText stub 
     // complete your Implementation 
		return selector;
	}



	private String insertTabWidget(JSONObject action) {
		// TODO Auto-generated insertTabWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String checkInsertBeforeTabIndex(JSONObject action) {
		// TODO Auto-generated checkInsertBeforeTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String checkTabIndex(JSONObject action) {
		// TODO Auto-generated checkTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String setSelectionStyle(JSONObject action) {
		// TODO Auto-generated setSelectionStyle stub 
     // complete your Implementation 
		return selector;
	}




}