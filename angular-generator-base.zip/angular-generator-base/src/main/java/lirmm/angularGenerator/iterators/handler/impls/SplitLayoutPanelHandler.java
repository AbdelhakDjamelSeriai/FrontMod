package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class SplitLayoutPanelHandler extends Handler{


    public SplitLayoutPanelHandler(){
    	selector = "<lirmm-split-layout-panel></lirmm-split-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("SplitLayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetHidden(JSONObject action) {
		// TODO Auto-generated setWidgetHidden stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetMinSize(JSONObject action) {
		// TODO Auto-generated setWidgetMinSize stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetSnapClosedSize(JSONObject action) {
		// TODO Auto-generated setWidgetSnapClosedSize stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidgetToggleDisplayAllowed(JSONObject action) {
		// TODO Auto-generated setWidgetToggleDisplayAllowed stub 
     // complete your Implementation 
		return selector;
	}



	private String insertSplitter(JSONObject action) {
		// TODO Auto-generated insertSplitter stub 
     // complete your Implementation 
		return selector;
	}




}