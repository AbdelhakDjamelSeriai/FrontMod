package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class MenuItemHandler extends Handler{


    public MenuItemHandler(){
    	selector = "<lirmm-menu-item></lirmm-menu-item>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("MenuItem");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setCommand(JSONObject action) {
		// TODO Auto-generated setCommand stub 
     // complete your Implementation 
		return selector;
	}



	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setScheduledCommand(JSONObject action) {
		// TODO Auto-generated setScheduledCommand stub 
     // complete your Implementation 
		return selector;
	}



	private String setSubMenu(JSONObject action) {
		// TODO Auto-generated setSubMenu stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String setSelectionStyle(JSONObject action) {
		// TODO Auto-generated setSelectionStyle stub 
     // complete your Implementation 
		return selector;
	}



	private String setParentMenu(JSONObject action) {
		// TODO Auto-generated setParentMenu stub 
     // complete your Implementation 
		return selector;
	}




}