package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class FileUploadHandler extends Handler{


    public FileUploadHandler(){
    	selector = "<lirmm-file-upload></lirmm-file-upload>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("FileUpload");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String click(JSONObject action) {
		// TODO Auto-generated click stub 
     // complete your Implementation 
		return selector;
	}




}