package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DeckPanelHandler extends Handler{


    public DeckPanelHandler(){
    	selector = "<lirmm-deck-panel></lirmm-deck-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DeckPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String showWidget(JSONObject action) {
		// TODO Auto-generated showWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String finishWidgetInitialization(JSONObject action) {
		// TODO Auto-generated finishWidgetInitialization stub 
     // complete your Implementation 
		return selector;
	}



	private String resetChildWidget(JSONObject action) {
		// TODO Auto-generated resetChildWidget stub 
     // complete your Implementation 
		return selector;
	}




}