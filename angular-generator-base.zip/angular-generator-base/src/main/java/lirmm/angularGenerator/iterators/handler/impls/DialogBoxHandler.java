package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DialogBoxHandler extends Handler{


    public DialogBoxHandler(){
    	selector = "<lirmm-dialog-box></lirmm-dialog-box>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DialogBox");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String hide(JSONObject action) {
		// TODO Auto-generated hide stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String onMouseDown(JSONObject action) {
		// TODO Auto-generated onMouseDown stub 
     // complete your Implementation 
		return selector;
	}



	private String onMouseEnter(JSONObject action) {
		// TODO Auto-generated onMouseEnter stub 
     // complete your Implementation 
		return selector;
	}



	private String onMouseLeave(JSONObject action) {
		// TODO Auto-generated onMouseLeave stub 
     // complete your Implementation 
		return selector;
	}



	private String onMouseMove(JSONObject action) {
		// TODO Auto-generated onMouseMove stub 
     // complete your Implementation 
		return selector;
	}



	private String onMouseUp(JSONObject action) {
		// TODO Auto-generated onMouseUp stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String show(JSONObject action) {
		// TODO Auto-generated show stub 
     // complete your Implementation 
		return selector;
	}



	private String beginDragging(JSONObject action) {
		// TODO Auto-generated beginDragging stub 
     // complete your Implementation 
		return selector;
	}



	private String continueDragging(JSONObject action) {
		// TODO Auto-generated continueDragging stub 
     // complete your Implementation 
		return selector;
	}



	private String doAttachChildren(JSONObject action) {
		// TODO Auto-generated doAttachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String doDetachChildren(JSONObject action) {
		// TODO Auto-generated doDetachChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String endDragging(JSONObject action) {
		// TODO Auto-generated endDragging stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String onPreviewNativeEvent(JSONObject action) {
		// TODO Auto-generated onPreviewNativeEvent stub 
     // complete your Implementation 
		return selector;
	}




}