package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class RootPanelHandler extends Handler{


    public RootPanelHandler(){
    	selector = "<lirmm-root-panel></lirmm-root-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("RootPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String detachNow(JSONObject action) {
		// TODO Auto-generated detachNow stub 
     // complete your Implementation 
		return selector;
	}



	private String detachOnWindowClose(JSONObject action) {
		// TODO Auto-generated detachOnWindowClose stub 
     // complete your Implementation 
		return selector;
	}



	private String detachWidgets(JSONObject action) {
		// TODO Auto-generated detachWidgets stub 
     // complete your Implementation 
		return selector;
	}



	private String hookWindowClosing(JSONObject action) {
		// TODO Auto-generated hookWindowClosing stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}




}