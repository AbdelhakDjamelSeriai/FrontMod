package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class StackLayoutPanelHandler extends Handler{


    public StackLayoutPanelHandler(){
    	selector = "<lirmm-stack-layout-panel></lirmm-stack-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("StackLayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String animate(JSONObject action) {
		// TODO Auto-generated animate stub 
     // complete your Implementation 
		return selector;
	}



	private String clear(JSONObject action) {
		// TODO Auto-generated clear stub 
     // complete your Implementation 
		return selector;
	}



	private String forceLayout(JSONObject action) {
		// TODO Auto-generated forceLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationDuration(JSONObject action) {
		// TODO Auto-generated setAnimationDuration stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeaderHTML(JSONObject action) {
		// TODO Auto-generated setHeaderHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeaderText(JSONObject action) {
		// TODO Auto-generated setHeaderText stub 
     // complete your Implementation 
		return selector;
	}



	private String showWidget(JSONObject action) {
		// TODO Auto-generated showWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onLoad(JSONObject action) {
		// TODO Auto-generated onLoad stub 
     // complete your Implementation 
		return selector;
	}



	private String checkChild(JSONObject action) {
		// TODO Auto-generated checkChild stub 
     // complete your Implementation 
		return selector;
	}



	private String checkIndex(JSONObject action) {
		// TODO Auto-generated checkIndex stub 
     // complete your Implementation 
		return selector;
	}




}