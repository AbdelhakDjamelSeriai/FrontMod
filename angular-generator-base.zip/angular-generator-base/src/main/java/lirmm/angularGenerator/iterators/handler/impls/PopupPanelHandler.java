package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class PopupPanelHandler extends Handler{


    public PopupPanelHandler(){
    	selector = "<lirmm-popup-panel></lirmm-popup-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("PopupPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addAutoHidePartner(JSONObject action) {
		// TODO Auto-generated addAutoHidePartner stub 
     // complete your Implementation 
		return selector;
	}



	private String addPopupListener(JSONObject action) {
		// TODO Auto-generated addPopupListener stub 
     // complete your Implementation 
		return selector;
	}



	private String center(JSONObject action) {
		// TODO Auto-generated center stub 
     // complete your Implementation 
		return selector;
	}



	private String hide(JSONObject action) {
		// TODO Auto-generated hide stub 
     // complete your Implementation 
		return selector;
	}



	private String removeAutoHidePartner(JSONObject action) {
		// TODO Auto-generated removeAutoHidePartner stub 
     // complete your Implementation 
		return selector;
	}



	private String removePopupListener(JSONObject action) {
		// TODO Auto-generated removePopupListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setAutoHideEnabled(JSONObject action) {
		// TODO Auto-generated setAutoHideEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setAutoHideOnHistoryEventsEnabled(JSONObject action) {
		// TODO Auto-generated setAutoHideOnHistoryEventsEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setGlassEnabled(JSONObject action) {
		// TODO Auto-generated setGlassEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setGlassStyleName(JSONObject action) {
		// TODO Auto-generated setGlassStyleName stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeight(JSONObject action) {
		// TODO Auto-generated setHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setModal(JSONObject action) {
		// TODO Auto-generated setModal stub 
     // complete your Implementation 
		return selector;
	}



	private String setPopupPosition(JSONObject action) {
		// TODO Auto-generated setPopupPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setPopupPositionAndShow(JSONObject action) {
		// TODO Auto-generated setPopupPositionAndShow stub 
     // complete your Implementation 
		return selector;
	}



	private String setPreviewingAllNativeEvents(JSONObject action) {
		// TODO Auto-generated setPreviewingAllNativeEvents stub 
     // complete your Implementation 
		return selector;
	}



	private String setTitle(JSONObject action) {
		// TODO Auto-generated setTitle stub 
     // complete your Implementation 
		return selector;
	}



	private String setVisible(JSONObject action) {
		// TODO Auto-generated setVisible stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidth(JSONObject action) {
		// TODO Auto-generated setWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String show(JSONObject action) {
		// TODO Auto-generated show stub 
     // complete your Implementation 
		return selector;
	}



	private String showRelativeTo(JSONObject action) {
		// TODO Auto-generated showRelativeTo stub 
     // complete your Implementation 
		return selector;
	}



	private String onPreviewNativeEvent(JSONObject action) {
		// TODO Auto-generated onPreviewNativeEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String onUnload(JSONObject action) {
		// TODO Auto-generated onUnload stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeUpdateSize(JSONObject action) {
		// TODO Auto-generated maybeUpdateSize stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimation(JSONObject action) {
		// TODO Auto-generated setAnimation stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationType(JSONObject action) {
		// TODO Auto-generated setAnimationType stub 
     // complete your Implementation 
		return selector;
	}



	private String blur(JSONObject action) {
		// TODO Auto-generated blur stub 
     // complete your Implementation 
		return selector;
	}



	private String position(JSONObject action) {
		// TODO Auto-generated position stub 
     // complete your Implementation 
		return selector;
	}



	private String previewNativeEvent(JSONObject action) {
		// TODO Auto-generated previewNativeEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String updateHandlers(JSONObject action) {
		// TODO Auto-generated updateHandlers stub 
     // complete your Implementation 
		return selector;
	}




}