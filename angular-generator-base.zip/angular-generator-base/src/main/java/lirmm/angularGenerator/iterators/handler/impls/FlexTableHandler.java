package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class FlexTableHandler extends Handler{


    public FlexTableHandler(){
    	selector = "<lirmm-flex-table></lirmm-flex-table>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("FlexTable");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addCell(JSONObject action) {
		// TODO Auto-generated addCell stub 
     // complete your Implementation 
		return selector;
	}



	private String insertCell(JSONObject action) {
		// TODO Auto-generated insertCell stub 
     // complete your Implementation 
		return selector;
	}



	private String removeAllRows(JSONObject action) {
		// TODO Auto-generated removeAllRows stub 
     // complete your Implementation 
		return selector;
	}



	private String removeCell(JSONObject action) {
		// TODO Auto-generated removeCell stub 
     // complete your Implementation 
		return selector;
	}



	private String removeCells(JSONObject action) {
		// TODO Auto-generated removeCells stub 
     // complete your Implementation 
		return selector;
	}



	private String removeRow(JSONObject action) {
		// TODO Auto-generated removeRow stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareCell(JSONObject action) {
		// TODO Auto-generated prepareCell stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareRow(JSONObject action) {
		// TODO Auto-generated prepareRow stub 
     // complete your Implementation 
		return selector;
	}




}