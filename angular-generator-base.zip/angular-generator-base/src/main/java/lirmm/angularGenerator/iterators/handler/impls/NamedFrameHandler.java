package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class NamedFrameHandler extends Handler{


    public NamedFrameHandler(){
    	selector = "<lirmm-named-frame></lirmm-named-frame>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("NamedFrame");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String initStatics(JSONObject action) {
		// TODO Auto-generated initStatics stub 
     // complete your Implementation 
		return selector;
	}




}