package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class NativeHorizontalScrollbarHandler extends Handler{


    public NativeHorizontalScrollbarHandler(){
    	selector = "<lirmm-native-horizontal-scrollbar></lirmm-native-horizontal-scrollbar>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("NativeHorizontalScrollbar");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setHorizontalScrollPosition(JSONObject action) {
		// TODO Auto-generated setHorizontalScrollPosition stub 
     // complete your Implementation 
		return selector;
	}



	private String setScrollWidth(JSONObject action) {
		// TODO Auto-generated setScrollWidth stub 
     // complete your Implementation 
		return selector;
	}




}