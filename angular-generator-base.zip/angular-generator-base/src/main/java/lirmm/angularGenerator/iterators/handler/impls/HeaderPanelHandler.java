package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HeaderPanelHandler extends Handler{


    public HeaderPanelHandler(){
    	selector = "<lirmm-header-panel></lirmm-header-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("HeaderPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String onResize(JSONObject action) {
		// TODO Auto-generated onResize stub 
     // complete your Implementation 
		return selector;
	}



	private String setContentWidget(JSONObject action) {
		// TODO Auto-generated setContentWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setFooterWidget(JSONObject action) {
		// TODO Auto-generated setFooterWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String setHeaderWidget(JSONObject action) {
		// TODO Auto-generated setHeaderWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String forceLayout(JSONObject action) {
		// TODO Auto-generated forceLayout stub 
     // complete your Implementation 
		return selector;
	}



	private String scheduledLayout(JSONObject action) {
		// TODO Auto-generated scheduledLayout stub 
     // complete your Implementation 
		return selector;
	}




}