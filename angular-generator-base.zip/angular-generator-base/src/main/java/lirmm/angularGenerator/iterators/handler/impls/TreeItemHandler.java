package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class TreeItemHandler extends Handler{


    public TreeItemHandler(){
    	selector = "<lirmm-tree-item></lirmm-tree-item>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("TreeItem");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addItem(JSONObject action) {
		// TODO Auto-generated addItem stub 
     // complete your Implementation 
		return selector;
	}



	private String setTitle(JSONObject action) {
		// TODO Auto-generated setTitle stub 
     // complete your Implementation 
		return selector;
	}



	private String insertItem(JSONObject action) {
		// TODO Auto-generated insertItem stub 
     // complete your Implementation 
		return selector;
	}



	private String remove(JSONObject action) {
		// TODO Auto-generated remove stub 
     // complete your Implementation 
		return selector;
	}



	private String removeItem(JSONObject action) {
		// TODO Auto-generated removeItem stub 
     // complete your Implementation 
		return selector;
	}



	private String removeItems(JSONObject action) {
		// TODO Auto-generated removeItems stub 
     // complete your Implementation 
		return selector;
	}



	private String setHTML(JSONObject action) {
		// TODO Auto-generated setHTML stub 
     // complete your Implementation 
		return selector;
	}



	private String setSelected(JSONObject action) {
		// TODO Auto-generated setSelected stub 
     // complete your Implementation 
		return selector;
	}



	private String setState(JSONObject action) {
		// TODO Auto-generated setState stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String setUserObject(JSONObject action) {
		// TODO Auto-generated setUserObject stub 
     // complete your Implementation 
		return selector;
	}



	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String addTreeItems(JSONObject action) {
		// TODO Auto-generated addTreeItems stub 
     // complete your Implementation 
		return selector;
	}



	private String initChildren(JSONObject action) {
		// TODO Auto-generated initChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String maybeRemoveItemFromParent(JSONObject action) {
		// TODO Auto-generated maybeRemoveItemFromParent stub 
     // complete your Implementation 
		return selector;
	}



	private String setParentItem(JSONObject action) {
		// TODO Auto-generated setParentItem stub 
     // complete your Implementation 
		return selector;
	}



	private String setTree(JSONObject action) {
		// TODO Auto-generated setTree stub 
     // complete your Implementation 
		return selector;
	}



	private String updateState(JSONObject action) {
		// TODO Auto-generated updateState stub 
     // complete your Implementation 
		return selector;
	}



	private String updateStateRecursive(JSONObject action) {
		// TODO Auto-generated updateStateRecursive stub 
     // complete your Implementation 
		return selector;
	}



	private String convertToFullNode(JSONObject action) {
		// TODO Auto-generated convertToFullNode stub 
     // complete your Implementation 
		return selector;
	}



	private String updateStateRecursiveHelper(JSONObject action) {
		// TODO Auto-generated updateStateRecursiveHelper stub 
     // complete your Implementation 
		return selector;
	}




}