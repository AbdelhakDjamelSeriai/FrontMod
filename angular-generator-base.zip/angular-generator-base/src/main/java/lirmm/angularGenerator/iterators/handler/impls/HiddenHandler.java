package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class HiddenHandler extends Handler{


    public HiddenHandler(){
    	selector = "<lirmm-hidden></lirmm-hidden>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Hidden");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setDefaultValue(JSONObject action) {
		// TODO Auto-generated setDefaultValue stub 
     // complete your Implementation 
		return selector;
	}



	private String setID(JSONObject action) {
		// TODO Auto-generated setID stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String setValue(JSONObject action) {
		// TODO Auto-generated setValue stub 
     // complete your Implementation 
		return selector;
	}




}