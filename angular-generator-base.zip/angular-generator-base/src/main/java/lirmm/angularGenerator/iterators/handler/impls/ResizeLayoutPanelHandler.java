package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ResizeLayoutPanelHandler extends Handler{


    public ResizeLayoutPanelHandler(){
    	selector = "<lirmm-resize-layout-panel></lirmm-resize-layout-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("ResizeLayoutPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setWidget(JSONObject action) {
		// TODO Auto-generated setWidget stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String handleResize(JSONObject action) {
		// TODO Auto-generated handleResize stub 
     // complete your Implementation 
		return selector;
	}



	private String scheduleResize(JSONObject action) {
		// TODO Auto-generated scheduleResize stub 
     // complete your Implementation 
		return selector;
	}




}