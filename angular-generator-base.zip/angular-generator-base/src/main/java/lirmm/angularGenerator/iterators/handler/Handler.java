package main.java.lirmm.angularGenerator.iterators.handler;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public abstract class Handler {
	
	
	protected JSONArray actions;
	
	protected String token;
	
	protected JSONArray nestedWidgets;
		
	protected String selector;
	
	public abstract boolean support(JSONObject widget);
	
	public void setActions(JSONObject widget) { actions = (JSONArray) widget.get("actions"); }
	 	
	public void setToken(String givenToken) { token = givenToken;}
	
	public void setNestedWidgets(JSONObject widget) { nestedWidgets = (JSONArray) widget.get("nestedWidgets"); }
	
	public abstract String handle();
	
    //public abstract Document handle();

	//protected Document outerHtml;
	
	//public void setOuterHtml(Document html) { outerHtml = html; }
	
	/*public Document decorate() {
		try { for (int j = 0; j < actions.size(); j++) {			
				JSONObject action = (JSONObject) actions.get(j);			
				this.getClass().getDeclaredMethod((String)action.get("insert"),JSONObject.class);				
			}	
		} catch (Exception e) {
			
		}
		return outerHtml;
	}*/
}
