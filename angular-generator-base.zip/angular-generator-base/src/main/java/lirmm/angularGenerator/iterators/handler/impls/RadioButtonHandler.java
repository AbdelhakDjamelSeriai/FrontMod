package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class RadioButtonHandler extends Handler{


    public RadioButtonHandler(){
    	selector = "<lirmm-radio-button></lirmm-radio-button>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("RadioButton");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String sinkEvents(JSONObject action) {
		// TODO Auto-generated sinkEvents stub 
     // complete your Implementation 
		return selector;
	}



	private String ensureDomEventHandlers(JSONObject action) {
		// TODO Auto-generated ensureDomEventHandlers stub 
     // complete your Implementation 
		return selector;
	}




}