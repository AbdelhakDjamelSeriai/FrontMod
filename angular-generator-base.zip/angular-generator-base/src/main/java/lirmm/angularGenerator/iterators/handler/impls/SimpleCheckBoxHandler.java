package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class SimpleCheckBoxHandler extends Handler{


    public SimpleCheckBoxHandler(){
    	selector = "<lirmm-simple-check-box></lirmm-simple-check-box>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("SimpleCheckBox");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setChecked(JSONObject action) {
		// TODO Auto-generated setChecked stub 
     // complete your Implementation 
		return selector;
	}



	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setFormValue(JSONObject action) {
		// TODO Auto-generated setFormValue stub 
     // complete your Implementation 
		return selector;
	}



	private String setName(JSONObject action) {
		// TODO Auto-generated setName stub 
     // complete your Implementation 
		return selector;
	}



	private String setValue(JSONObject action) {
		// TODO Auto-generated setValue stub 
     // complete your Implementation 
		return selector;
	}



	private String ensureDomEventHandlers(JSONObject action) {
		// TODO Auto-generated ensureDomEventHandlers stub 
     // complete your Implementation 
		return selector;
	}



	private String onUnload(JSONObject action) {
		// TODO Auto-generated onUnload stub 
     // complete your Implementation 
		return selector;
	}




}