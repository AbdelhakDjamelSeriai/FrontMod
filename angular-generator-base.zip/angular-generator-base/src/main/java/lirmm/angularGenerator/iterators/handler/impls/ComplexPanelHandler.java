package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ComplexPanelHandler extends Handler{


    public ComplexPanelHandler(){
    	selector = "<lirmm-complex-panel></lirmm-complex-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("ComplexPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String checkIndexBoundsForAccess(JSONObject action) {
		// TODO Auto-generated checkIndexBoundsForAccess stub 
     // complete your Implementation 
		return selector;
	}



	private String checkIndexBoundsForInsertion(JSONObject action) {
		// TODO Auto-generated checkIndexBoundsForInsertion stub 
     // complete your Implementation 
		return selector;
	}



	private String insert(JSONObject action) {
		// TODO Auto-generated insert stub 
     // complete your Implementation 
		return selector;
	}



	private String doLogicalClear(JSONObject action) {
		// TODO Auto-generated doLogicalClear stub 
     // complete your Implementation 
		return selector;
	}




}