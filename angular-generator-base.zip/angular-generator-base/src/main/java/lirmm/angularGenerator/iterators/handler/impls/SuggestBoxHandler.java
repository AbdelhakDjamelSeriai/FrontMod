package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class SuggestBoxHandler extends Handler{


    public SuggestBoxHandler(){
    	selector = "<lirmm-suggest-box></lirmm-suggest-box>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("SuggestBox");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addChangeListener(JSONObject action) {
		// TODO Auto-generated addChangeListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addClickListener(JSONObject action) {
		// TODO Auto-generated addClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addEventHandler(JSONObject action) {
		// TODO Auto-generated addEventHandler stub 
     // complete your Implementation 
		return selector;
	}



	private String addFocusListener(JSONObject action) {
		// TODO Auto-generated addFocusListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addKeyboardListener(JSONObject action) {
		// TODO Auto-generated addKeyboardListener stub 
     // complete your Implementation 
		return selector;
	}



	private String hideSuggestionList(JSONObject action) {
		// TODO Auto-generated hideSuggestionList stub 
     // complete your Implementation 
		return selector;
	}



	private String refreshSuggestionList(JSONObject action) {
		// TODO Auto-generated refreshSuggestionList stub 
     // complete your Implementation 
		return selector;
	}



	private String removeChangeListener(JSONObject action) {
		// TODO Auto-generated removeChangeListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeClickListener(JSONObject action) {
		// TODO Auto-generated removeClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeEventHandler(JSONObject action) {
		// TODO Auto-generated removeEventHandler stub 
     // complete your Implementation 
		return selector;
	}



	private String removeFocusListener(JSONObject action) {
		// TODO Auto-generated removeFocusListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeKeyboardListener(JSONObject action) {
		// TODO Auto-generated removeKeyboardListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setAccessKey(JSONObject action) {
		// TODO Auto-generated setAccessKey stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setAutoSelectEnabled(JSONObject action) {
		// TODO Auto-generated setAutoSelectEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocus(JSONObject action) {
		// TODO Auto-generated setFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String setLimit(JSONObject action) {
		// TODO Auto-generated setLimit stub 
     // complete your Implementation 
		return selector;
	}



	private String setPopupStyleName(JSONObject action) {
		// TODO Auto-generated setPopupStyleName stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabIndex(JSONObject action) {
		// TODO Auto-generated setTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}



	private String setValue(JSONObject action) {
		// TODO Auto-generated setValue stub 
     // complete your Implementation 
		return selector;
	}



	private String showSuggestionList(JSONObject action) {
		// TODO Auto-generated showSuggestionList stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String showSuggestions(JSONObject action) {
		// TODO Auto-generated showSuggestions stub 
     // complete your Implementation 
		return selector;
	}



	private String addEventsToTextBox(JSONObject action) {
		// TODO Auto-generated addEventsToTextBox stub 
     // complete your Implementation 
		return selector;
	}



	private String fireSuggestionEvent(JSONObject action) {
		// TODO Auto-generated fireSuggestionEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String refreshSuggestions(JSONObject action) {
		// TODO Auto-generated refreshSuggestions stub 
     // complete your Implementation 
		return selector;
	}



	private String setNewSelection(JSONObject action) {
		// TODO Auto-generated setNewSelection stub 
     // complete your Implementation 
		return selector;
	}



	private String setOracle(JSONObject action) {
		// TODO Auto-generated setOracle stub 
     // complete your Implementation 
		return selector;
	}




}