package main.java.lirmm.angularGenerator.iterators;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;



public class PagesCollection {
	
	private PageIterator pageIterator;
	
	private JSONArray pages;
	
	public PagesCollection(JSONArray pages, PageIterator pageIterator1) {
		
		this.pages = pages;
		
		pageIterator = pageIterator1;
	}
	
	public List<List<String>> iteratePages() {
		
		List<List<String>> sList = new ArrayList<>();
		
		pages.forEach(page -> sList.add(analysePage((JSONObject)page)));
		return sList;
	
	}
	
	private List<String> analysePage(JSONObject page) {

		return pageIterator.iteratePage(page);
		
	}
}
