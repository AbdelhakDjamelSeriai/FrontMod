package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ToggleButtonHandler extends Handler{


    public ToggleButtonHandler(){
    	selector = "<lirmm-toggle-button></lirmm-toggle-button>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("ToggleButton");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String setDown(JSONObject action) {
		// TODO Auto-generated setDown stub 
     // complete your Implementation 
		return selector;
	}



	private String setValue(JSONObject action) {
		// TODO Auto-generated setValue stub 
     // complete your Implementation 
		return selector;
	}



	private String onClick(JSONObject action) {
		// TODO Auto-generated onClick stub 
     // complete your Implementation 
		return selector;
	}




}