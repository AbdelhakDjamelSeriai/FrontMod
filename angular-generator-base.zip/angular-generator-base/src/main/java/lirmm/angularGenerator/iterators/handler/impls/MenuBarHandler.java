package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class MenuBarHandler extends Handler{


    public MenuBarHandler(){
    	selector = "<lirmm-menu-bar></lirmm-menu-bar>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("MenuBar");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String clearItems(JSONObject action) {
		// TODO Auto-generated clearItems stub 
     // complete your Implementation 
		return selector;
	}



	private String closeAllChildren(JSONObject action) {
		// TODO Auto-generated closeAllChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String focus(JSONObject action) {
		// TODO Auto-generated focus stub 
     // complete your Implementation 
		return selector;
	}



	private String moveSelectionDown(JSONObject action) {
		// TODO Auto-generated moveSelectionDown stub 
     // complete your Implementation 
		return selector;
	}



	private String moveSelectionUp(JSONObject action) {
		// TODO Auto-generated moveSelectionUp stub 
     // complete your Implementation 
		return selector;
	}



	private String onBrowserEvent(JSONObject action) {
		// TODO Auto-generated onBrowserEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String onPopupClosed(JSONObject action) {
		// TODO Auto-generated onPopupClosed stub 
     // complete your Implementation 
		return selector;
	}



	private String removeItem(JSONObject action) {
		// TODO Auto-generated removeItem stub 
     // complete your Implementation 
		return selector;
	}



	private String removeSeparator(JSONObject action) {
		// TODO Auto-generated removeSeparator stub 
     // complete your Implementation 
		return selector;
	}



	private String selectItem(JSONObject action) {
		// TODO Auto-generated selectItem stub 
     // complete your Implementation 
		return selector;
	}



	private String setAnimationEnabled(JSONObject action) {
		// TODO Auto-generated setAnimationEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setAutoOpen(JSONObject action) {
		// TODO Auto-generated setAutoOpen stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocusOnHoverEnabled(JSONObject action) {
		// TODO Auto-generated setFocusOnHoverEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String onDetach(JSONObject action) {
		// TODO Auto-generated onDetach stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String closeAllParents(JSONObject action) {
		// TODO Auto-generated closeAllParents stub 
     // complete your Implementation 
		return selector;
	}



	private String closeAllParentsAndChildren(JSONObject action) {
		// TODO Auto-generated closeAllParentsAndChildren stub 
     // complete your Implementation 
		return selector;
	}



	private String doItemAction(JSONObject action) {
		// TODO Auto-generated doItemAction stub 
     // complete your Implementation 
		return selector;
	}



	private String itemOver(JSONObject action) {
		// TODO Auto-generated itemOver stub 
     // complete your Implementation 
		return selector;
	}



	private String setMenuItemDebugIds(JSONObject action) {
		// TODO Auto-generated setMenuItemDebugIds stub 
     // complete your Implementation 
		return selector;
	}



	private String updateSubmenuIcon(JSONObject action) {
		// TODO Auto-generated updateSubmenuIcon stub 
     // complete your Implementation 
		return selector;
	}



	private String addItemElement(JSONObject action) {
		// TODO Auto-generated addItemElement stub 
     // complete your Implementation 
		return selector;
	}



	private String close(JSONObject action) {
		// TODO Auto-generated close stub 
     // complete your Implementation 
		return selector;
	}



	private String eatEvent(JSONObject action) {
		// TODO Auto-generated eatEvent stub 
     // complete your Implementation 
		return selector;
	}



	private String init(JSONObject action) {
		// TODO Auto-generated init stub 
     // complete your Implementation 
		return selector;
	}



	private String moveToNextItem(JSONObject action) {
		// TODO Auto-generated moveToNextItem stub 
     // complete your Implementation 
		return selector;
	}



	private String moveToPrevItem(JSONObject action) {
		// TODO Auto-generated moveToPrevItem stub 
     // complete your Implementation 
		return selector;
	}



	private String onHide(JSONObject action) {
		// TODO Auto-generated onHide stub 
     // complete your Implementation 
		return selector;
	}



	private String openPopup(JSONObject action) {
		// TODO Auto-generated openPopup stub 
     // complete your Implementation 
		return selector;
	}



	private String selectNextItem(JSONObject action) {
		// TODO Auto-generated selectNextItem stub 
     // complete your Implementation 
		return selector;
	}



	private String selectPrevItem(JSONObject action) {
		// TODO Auto-generated selectPrevItem stub 
     // complete your Implementation 
		return selector;
	}



	private String setItemColSpan(JSONObject action) {
		// TODO Auto-generated setItemColSpan stub 
     // complete your Implementation 
		return selector;
	}




}