package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class ButtonHandler extends Handler{



    public ButtonHandler(){
    	selector = "<lirmm-button [text]=\""+ "'x'" +"\" [ngClass]=\""+ "'remove'" + "\" (click)=\"onClick()\"></lirmm-button>";
    	
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Button");
	}


	@Override
	public String handle() {
		
		String text = "";
		
		String ngClass = "";
		
		for (int i = 0; i< actions.size(); i++) {
			
			JSONObject action = (JSONObject) actions.get(i);
			
			if (action.get("addStyleDependentName")!=null && !((JSONArray)((JSONObject)(action.get("addStyleDependentName"))).get("args")).isEmpty() ) {
				
				ngClass = (String)((JSONArray)((JSONObject)(action.get("addStyleDependentName"))).get("args")).get(0);
				
				ngClass = ngClass.substring(1, ngClass.length()-1);
			}
			
			if ( (action.get("affectedType")!=null) && 
					
					! ((JSONArray)((JSONObject) ( (JSONObject) (action.get("affectedType")) ).get("Button")).get("args")).isEmpty()  ) {
				
				   text = (String)((JSONArray)((JSONObject) ( (JSONObject) (action.get("affectedType")) ).get("Button")).get("args")).get(0);
					
				   text = text.substring(1, text.length()-1) ;
				
			}
			
			if ( ( action.get("setText") !=null )  && !((JSONArray)((JSONObject)(action.get("setText"))).get("args")).isEmpty() ) {
					
			   text = (String)((JSONArray)((JSONObject)(action.get("setText"))).get("args")).get(0);
					
			   text =  text.substring(1, text.length()-1) ;

		    }
			
		}
		
		selector = "<lirmm-button [text]=\""+ "'" +text+ "'" +"\" [ngClass]=\""+ "'" + ngClass+ "'" + "\" (click)=\"onClick()\"></lirmm-button>";
		
		return selector;
	}

	private String click(JSONObject action) {
		// TODO Auto-generated click stub 
     // complete your Implementation 
		return selector;
	}




}