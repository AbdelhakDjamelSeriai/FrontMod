package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class FocusWidgetHandler extends Handler{


    public FocusWidgetHandler(){
    	selector = "<lirmm-focus-widget></lirmm-focus-widget>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("FocusWidget");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addClickListener(JSONObject action) {
		// TODO Auto-generated addClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addFocusListener(JSONObject action) {
		// TODO Auto-generated addFocusListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addKeyboardListener(JSONObject action) {
		// TODO Auto-generated addKeyboardListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseListener(JSONObject action) {
		// TODO Auto-generated addMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseWheelListener(JSONObject action) {
		// TODO Auto-generated addMouseWheelListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeClickListener(JSONObject action) {
		// TODO Auto-generated removeClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeFocusListener(JSONObject action) {
		// TODO Auto-generated removeFocusListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeKeyboardListener(JSONObject action) {
		// TODO Auto-generated removeKeyboardListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseListener(JSONObject action) {
		// TODO Auto-generated removeMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseWheelListener(JSONObject action) {
		// TODO Auto-generated removeMouseWheelListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setAccessKey(JSONObject action) {
		// TODO Auto-generated setAccessKey stub 
     // complete your Implementation 
		return selector;
	}



	private String setEnabled(JSONObject action) {
		// TODO Auto-generated setEnabled stub 
     // complete your Implementation 
		return selector;
	}



	private String setFocus(JSONObject action) {
		// TODO Auto-generated setFocus stub 
     // complete your Implementation 
		return selector;
	}



	private String setTabIndex(JSONObject action) {
		// TODO Auto-generated setTabIndex stub 
     // complete your Implementation 
		return selector;
	}



	private String onAttach(JSONObject action) {
		// TODO Auto-generated onAttach stub 
     // complete your Implementation 
		return selector;
	}




}