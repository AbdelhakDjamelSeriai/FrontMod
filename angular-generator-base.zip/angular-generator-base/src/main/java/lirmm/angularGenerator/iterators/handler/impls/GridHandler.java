package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class GridHandler extends Handler{


    public GridHandler(){
    	selector = "<lirmm-grid></lirmm-grid>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Grid");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String addRows(JSONObject action) {
		// TODO Auto-generated addRows stub 
     // complete your Implementation 
		return selector;
	}



	private String removeRow(JSONObject action) {
		// TODO Auto-generated removeRow stub 
     // complete your Implementation 
		return selector;
	}



	private String resize(JSONObject action) {
		// TODO Auto-generated resize stub 
     // complete your Implementation 
		return selector;
	}



	private String resizeColumns(JSONObject action) {
		// TODO Auto-generated resizeColumns stub 
     // complete your Implementation 
		return selector;
	}



	private String resizeRows(JSONObject action) {
		// TODO Auto-generated resizeRows stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareCell(JSONObject action) {
		// TODO Auto-generated prepareCell stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareColumn(JSONObject action) {
		// TODO Auto-generated prepareColumn stub 
     // complete your Implementation 
		return selector;
	}



	private String prepareRow(JSONObject action) {
		// TODO Auto-generated prepareRow stub 
     // complete your Implementation 
		return selector;
	}




}