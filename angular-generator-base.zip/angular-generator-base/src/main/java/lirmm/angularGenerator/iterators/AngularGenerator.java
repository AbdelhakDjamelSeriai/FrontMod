package main.java.lirmm.angularGenerator.iterators;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;
import main.java.lirmm.angularGenerator.iterators.handler.impls.*;

public class AngularGenerator {
	
	
	/*private Handler componentHandler = new CompositeHandler();*/
	
	
	private Handler [] leafHandlers = {
			// generated automatically
			new DeckPanelHandler (),
			new TreeItemHandler (),
			new TextAreaHandler (),
			new TabBarHandler (),
			new FocusWidgetHandler (),
			new LabelHandler (),
			new WidgetHandler (),
			new HTMLHandler (),
			new TextBoxHandler (),
			new ImageHandler (),
			new MenuItemSeparatorHandler (),
			new NativeHorizontalScrollbarHandler (),
			new LongBoxHandler (),
			new RichTextAreaHandler (),
			new ButtonHandler (),
			new NativeVerticalScrollbarHandler (),
			new InlineLabelHandler (),
			new TreeHandler (),
			new HiddenHandler (),
			new CaptionPanelHandler (),
			new SplitPanelHandler (),
			new DialogBoxHandler (),
			new SimpleRadioButtonHandler (),
			new TabLayoutPanelHandler (),
			new StackPanelHandler (),
			new FlexTableHandler (),
			new ResetButtonHandler (),
			new SimplePanelHandler (),
			new CustomScrollPanelHandler (),
			new RadioButtonHandler (),
			new SplitLayoutPanelHandler (),
			new PasswordTextBoxHandler (),
			new RootLayoutPanelHandler (),
			new LayoutPanelHandler (),
			new DecoratedStackPanelHandler (),
			new DecoratedPopupPanelHandler (),
			new CheckBoxHandler (),
			new HorizontalSplitPanelHandler (),
			new DecoratorPanelHandler (),
			new LazyPanelHandler (),
			new PushButtonHandler (),
			new HTMLTableHandler (),
			new ListBoxHandler (),
			new ScrollPanelHandler (),
			new HTMLPanelHandler (),
			new DecoratedTabBarHandler (),
			new FrameHandler (),
			new GridHandler (),
			new PopupPanelHandler (),
			new InlineHTMLHandler (),
			new MenuBarHandler (),
			new DisclosurePanelHandler (),
			new AbsolutePanelHandler (),
			new RootPanelHandler (),
			new VerticalSplitPanelHandler (),
			new FocusPanelHandler (),
			new DateLabelHandler (),
			new StackLayoutPanelHandler (),
			new InlineHyperlinkHandler (),
			new CustomButtonHandler (),
			new HorizontalPanelHandler (),
			new ComplexPanelHandler (),
			new DeckLayoutPanelHandler (),
			new SimpleCheckBoxHandler (),
			new SubmitButtonHandler (),
			new FileUploadHandler (),
			new TabPanelHandler (),
			new ToggleButtonHandler (),
			new CellPanelHandler (),
			new CompositeHandler (),
			new SimpleLayoutPanelHandler (),
			new ResizeCompositeHandler (),
			new MenuItemHandler (),
			new NamedFrameHandler (),
			new IntegerBoxHandler (),
			new PanelHandler (),
			new SuggestBoxHandler (),
			new VerticalPanelHandler (),
			new AnchorHandler (),
			new FormPanelHandler (),
			new DockLayoutPanelHandler (),
			new DockPanelHandler (),
			new HeaderPanelHandler (),
			new FlowPanelHandler (),
			new DecoratedTabPanelHandler (),
			new DoubleBoxHandler (),
			new ResizeLayoutPanelHandler (),
			new HyperlinkHandler (),	
	};

	
	
	public AngularGenerator() {
		
	}
	
	public String iterateWidget(JSONObject widget) {
	
		
		for (Handler handler: leafHandlers) {
			if (handler.support(widget)) {
			   handler.setActions(widget);
			   return handler.handle();
			}
		}
		return "";
	}
	
	
}
