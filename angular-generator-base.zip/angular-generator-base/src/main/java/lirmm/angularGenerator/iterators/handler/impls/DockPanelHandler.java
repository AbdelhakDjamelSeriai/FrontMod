package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class DockPanelHandler extends Handler{


    public DockPanelHandler(){
    	selector = "<lirmm-dock-panel></lirmm-dock-panel>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("DockPanel");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String add(JSONObject action) {
		// TODO Auto-generated add stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellHeight(JSONObject action) {
		// TODO Auto-generated setCellHeight stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellHorizontalAlignment(JSONObject action) {
		// TODO Auto-generated setCellHorizontalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellVerticalAlignment(JSONObject action) {
		// TODO Auto-generated setCellVerticalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setCellWidth(JSONObject action) {
		// TODO Auto-generated setCellWidth stub 
     // complete your Implementation 
		return selector;
	}



	private String setHorizontalAlignment(JSONObject action) {
		// TODO Auto-generated setHorizontalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String setVerticalAlignment(JSONObject action) {
		// TODO Auto-generated setVerticalAlignment stub 
     // complete your Implementation 
		return selector;
	}



	private String onEnsureDebugId(JSONObject action) {
		// TODO Auto-generated onEnsureDebugId stub 
     // complete your Implementation 
		return selector;
	}



	private String realizeTable(JSONObject action) {
		// TODO Auto-generated realizeTable stub 
     // complete your Implementation 
		return selector;
	}




}