package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class LabelHandler extends Handler{


    public LabelHandler(){
    	selector = "<lirmm-label></lirmm-label>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("Label");
	}


	@Override
	public String handle() {
		
		String textContent = "";
		

		
		for (int i = 0; i< actions.size(); i++) {
			
			JSONObject action = (JSONObject) actions.get(i);
			
			
			/*if ( (action.get("affectedType")!=null) && 
					
					 ((JSONArray) ((JSONObject) (JSONObject) ( (JSONObject) (action.get("affectedType")) ).get("Label")).get("args")).size() > 0 ) {
				
				textContent = (String)((JSONArray)((JSONObject) ( (JSONObject) (action.get("affectedType")) ).get("Label")).get("args")).get(0);
					
				textContent = textContent.substring(1, textContent.length()-1) ;
				
			}*/
			
			if ( ( action.get("setText") !=null )  && !((JSONArray)((JSONObject)(action.get("setText"))).get("args")).isEmpty() ) {
					
				textContent = (String)((JSONArray)((JSONObject)(action.get("setText"))).get("args")).get(0);
					
				textContent =  textContent.substring(1, textContent.length()-1) ;

		    }
			
		}
		
		selector = "<lirmm-label [textContent]="+ "'" + textContent + "'" +"></lirmm-label>";
		
		return selector;

	}

	private String addClickListener(JSONObject action) {
		// TODO Auto-generated addClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseListener(JSONObject action) {
		// TODO Auto-generated addMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String addMouseWheelListener(JSONObject action) {
		// TODO Auto-generated addMouseWheelListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeClickListener(JSONObject action) {
		// TODO Auto-generated removeClickListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseListener(JSONObject action) {
		// TODO Auto-generated removeMouseListener stub 
     // complete your Implementation 
		return selector;
	}



	private String removeMouseWheelListener(JSONObject action) {
		// TODO Auto-generated removeMouseWheelListener stub 
     // complete your Implementation 
		return selector;
	}



	private String setDirection(JSONObject action) {
		// TODO Auto-generated setDirection stub 
     // complete your Implementation 
		return selector;
	}



	private String setText(JSONObject action) {
		// TODO Auto-generated setText stub 
     // complete your Implementation 
		return selector;
	}




}