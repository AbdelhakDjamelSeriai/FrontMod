package main.java.lirmm.angularGenerator.iterators.handler.impls;

import org.json.simple.JSONObject;

import main.java.lirmm.angularGenerator.iterators.handler.Handler;



public class PushButtonHandler extends Handler{


    public PushButtonHandler(){
    	selector = "<lirmm-push-button></lirmm-push-button>";
    }

	@Override
	public boolean support(JSONObject widget) {
		// Auto-generated method 
        String type = (String) widget.get("type");
		return type.equals("PushButton");
	}


	@Override
	public String handle() {
		// Auto-generated method 
        //complete your business here !!! 
		return selector;
	}

	private String onClick(JSONObject action) {
		// TODO Auto-generated onClick stub 
     // complete your Implementation 
		return selector;
	}



	private String onClickCancel(JSONObject action) {
		// TODO Auto-generated onClickCancel stub 
     // complete your Implementation 
		return selector;
	}



	private String onClickStart(JSONObject action) {
		// TODO Auto-generated onClickStart stub 
     // complete your Implementation 
		return selector;
	}




}