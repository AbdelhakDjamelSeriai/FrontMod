package main.java.lirmm.angularGenerator.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class GWTElementsFileReader extends JSONFileReader{
	
	
	public GWTElementsFileReader(String pathToFile) {
		try {
			this.fileReader = new FileReader(pathToFile);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public Object parseData() {
		
		JSONParser parser = new JSONParser();
		
		JSONArray elements = null;
		
		try {
			
	        Object obj = parser.parse(this.fileReader);
	        
	        elements = (JSONArray) obj;
            
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return elements;
	}

}
