package main.java.lirmm.angularGenerator.json;

public class Transition {
	
	public String actualPage;
	
	public String byElement;
	
	public String token;
	
	public String nextPage;
	
	public Transition(String actualPage, String byElement, String nextPage) {
		this.actualPage = actualPage;
		this.byElement = byElement;
		this.token = generateToken(actualPage, nextPage);
		this.nextPage = nextPage;
	}
	
	public Transition() {} 

	public String generateToken(String actualPage, String nextPage) {
		return actualPage + nextPage;
	}
	
	/**
	 * Getters
	 * 
	 */
	public String getActualPage() { return actualPage; }
	
	public String getByElement() { return byElement; }
	
	public String getToken() { return token; }
	
	public String getNextPage() { return nextPage; }
	
	/**
	 * Setters
	 */
    public void setActualPage(String actualPage) { this.actualPage = actualPage; }
	
	public void setByElement(String byElement) {  this.byElement = byElement; }
	
	public void setToken(String token) { this.token = token; }
	
	public void setNextPage(String nextPage) { this.nextPage = nextPage; }
}
