package main.java.lirmm.angularGenerator.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class GWTModelFileReader extends JSONFileReader{
	
	public GWTModelFileReader(String pathToFile) {
		try {
			this.fileReader = new FileReader(pathToFile);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public Object parseData() {
		
		JSONParser parser = new JSONParser();
		
		JSONArray pages = null;
		
		try {
			
	        Object obj = parser.parse(this.fileReader);
	        
            JSONObject jsonObject = (JSONObject) obj;
            
             pages = (JSONArray)jsonObject.get("Pages");
            

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return pages;
	}
	
	
	
	
}
