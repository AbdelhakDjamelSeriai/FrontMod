package main.java.lirmm.angularGenerator.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class NavigationalModelFileReader extends JSONFileReader {
	
	public NavigationalModelFileReader(String pathToFile) {
		try {
			this.fileReader = new FileReader(pathToFile);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public Object parseData() {
		
		JSONParser parser = new JSONParser();
		
		JSONArray transitions = null;
		
		try {
			
	        Object obj = parser.parse(this.fileReader);
	        
            JSONObject jsonObject = (JSONObject) obj;
            
            transitions = (JSONArray)jsonObject.get("transitions");
            

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return transitions;
	}
	
	/**
	 * Get All Transitions from Pages
	 * @return
	 */
	private List<Transition> getTransitions() {
		
		List<Transition> transitions = new ArrayList<>();
		
		JSONArray arrayTransitions = (JSONArray)this.parseData();
		
		for (int i = 0; i < arrayTransitions.size() ; i++) {
			
			JSONObject transitionAsObject = (JSONObject) arrayTransitions.get(i);
				
			Transition transition = new Transition( 
				(String)transitionAsObject.get("from"), 
				(String) transitionAsObject.get("by"), 
				(String) transitionAsObject.get("to"));
			transitions.add(transition);
		}
		
		return transitions;
	}
	
	/**
	 * Get Only From
	 * @param transitions
	 * @return
	 */
	private List<String> getFromPages(List<Transition> transitions) {
		
		return transitions.stream().map(Transition::getActualPage).collect(Collectors.toList());
	}
	
	/**
	 * Get Only To
	 * @param transitions
	 * @return
	 */
	private List<String> getToPages(List<Transition> transitions) {
		return transitions.stream().map(Transition::getNextPage).collect(Collectors.toList());
	}
	
	
	/**
	 * Get True Pages
	 * @return
	 */
	public List<String> getTruePagesNames() {
		
		List<Transition> transitions = getTransitions();
		
		List<String> froms = getFromPages(transitions);
		
		List<String> tos = getToPages(transitions);
		
		froms.removeAll(tos);
		froms.addAll(tos);
		
		return froms;
	}

}
