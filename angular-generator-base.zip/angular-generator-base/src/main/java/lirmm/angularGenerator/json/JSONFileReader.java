package main.java.lirmm.angularGenerator.json;

import java.io.FileReader;

abstract public class JSONFileReader {
	
	protected FileReader fileReader;
	
	abstract public Object parseData();
	
}
