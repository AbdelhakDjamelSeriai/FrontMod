package main.java.lirmm.angularGenerator.tests.features;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmt.modisco.java.AbstractMethodDeclaration;
import org.eclipse.gmt.modisco.java.AbstractMethodInvocation;
import org.eclipse.gmt.modisco.java.Assignment;
import org.eclipse.gmt.modisco.java.BodyDeclaration;
import org.eclipse.gmt.modisco.java.BooleanLiteral;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.Expression;
import org.eclipse.gmt.modisco.java.FieldDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.NumberLiteral;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.StringLiteral;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;
import org.eclipse.gmt.modisco.java.VariableDeclarationStatement;
import org.junit.Before;
import org.junit.Test;

import kdm.code.gwt.GwtModel;
import kdm.code.gwt.Page;
import kdm.kdm.Segment;
import main.java.lirmm.angularGenerator.dao.Attribute;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gwt.GwtModelExtractor;
import main.java.lirmm.angularGenerator.gwt.SegmentExtractor;

public class VarExtractorTest {
	
	Page  mainPageView;
	
	ClassDeclaration mainPageViewJava;
		
	@Before
	public void TestSetup() {
		
		Segment segment = SegmentExtractor.getInstance("gwt-app-11_kdm_gwt.xmi").getSegment();
		
		GwtModel gwtModel = GwtModelExtractor.getInstance().getGwtModelFromSegment(segment);

		mainPageView =  gwtModel.getPages().get(1);
		
		mainPageViewJava = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(mainPageView);
		
	}

	
	@Test
	public void check_if_can_get_classDeclaration() {		
		
		
		
		assertEquals(mainPageViewJava.getName(),"MainPageView");
		
	}
	
	
	@Test
	public void check_if_can_get_FieldDeclaration() {
		
		ClassDeclaration mainPageViewJava = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(mainPageView);

		String nameWidget = "nameLabel";
		 
		assertNotNull(getWidgetFromClassDeclaration(mainPageViewJava,nameWidget));

	}
	
	/**
	 * get Widget From Class Declaration
	 * @param mainPageViewJava
	 * @param nameWidget
	 * @return
	 */
	public VariableDeclarationFragment getWidgetFromClassDeclaration(ClassDeclaration mainPageViewJava, String nameWidget) {
		
		VariableDeclarationFragment fragment = null;

		for(BodyDeclaration bodyDeclaration: mainPageViewJava.getBodyDeclarations()) {
			
			if (getVariableDeclarationFragmentAsFieldDeclaration(bodyDeclaration, nameWidget) !=  null) {
				
				fragment = getVariableDeclarationFragmentAsFieldDeclaration(bodyDeclaration, nameWidget);
				
			}else if (getVariableDeclarationFragmentAsVarDecStmt(bodyDeclaration, nameWidget) != null) {
				
				fragment = getVariableDeclarationFragmentAsVarDecStmt(bodyDeclaration, nameWidget);
			}
		}
		
		return fragment;
	}
	
	
	/**
	 * Get Fragment case Field Declaration
	 * @param bodyDeclaration
	 * @param nameWidget
	 * @return
	 */
	public VariableDeclarationFragment getVariableDeclarationFragmentAsFieldDeclaration(BodyDeclaration bodyDeclaration, String nameWidget) {
		
		VariableDeclarationFragment fragment = null;
		
		if ( (bodyDeclaration instanceof FieldDeclaration) && (((FieldDeclaration)bodyDeclaration).getFragments().get(0).getName().equals(nameWidget)) ) {
			
			fragment = (((FieldDeclaration)bodyDeclaration).getFragments().get(0));
		}
		
		return fragment;
	}
	

	/**
	 * Get Fragment case VarDecStmt <--> Variable Declaration Statement 
	 * @param bodyDeclaration
	 * @param nameWidget
	 * @return
	 */
	public VariableDeclarationFragment getVariableDeclarationFragmentAsVarDecStmt(BodyDeclaration bodyDeclaration, String nameWidget) {
		
		VariableDeclarationFragment fragment = null;
		
		if ((bodyDeclaration instanceof AbstractMethodDeclaration)) {
			
			EList<Statement> statements = ((AbstractMethodDeclaration)bodyDeclaration).getBody().getStatements();
			
			for(Statement s : statements) {
				
				if ((s instanceof VariableDeclarationStatement) && ( ((VariableDeclarationStatement)s).getFragments().get(0).getName().equals(nameWidget) ) ) {
					
					fragment = ((VariableDeclarationStatement)s).getFragments().get(0);
					
					break;
					
				}
				
			}
		}
		
		 
		 return fragment;
	}
	

	
	@Test
	public void check_if_we_can_get_data_from_single_sva() {
		
		ClassDeclaration mainPageViewJava = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(mainPageView);

		String nameWidget = "rightPanel";
		 
		VariableDeclarationFragment fragment = getWidgetFromClassDeclaration(mainPageViewJava,nameWidget);	
		
		SingleVariableAccess singleVariableAccess = fragment.getUsageInVariableAccess().get(1);
		
		List<Attribute> attributes = new ArrayList<Attribute>();
		
		attributes.addAll( createAttributesFromSva(singleVariableAccess) );
		
		attributes.add( createAttributeFromVariableDeclaration(fragment) );
		
		
		
		//attributes.get(0).showAttribute();
		
		assertEquals(createAttributesFromFromSVAMethodCase(singleVariableAccess).size(), 7);
	}
	
	
	
	/**
	 * 
	 * @param fragment
	 * @return
	 */
	private Attribute createAttributeFromVariableDeclaration(VariableDeclarationFragment fragment) {
		
		Expression expression = fragment.getInitializer();
		
		Attribute attribute = new Attribute();
		
		attribute.setName("setText");

		if (( expression instanceof ClassInstanceCreation ) && ( ((ClassInstanceCreation)expression).getArguments().size() > 0 ) ) {
			
			attribute.setArgs( transformArgsToStringList(((ClassInstanceCreation)expression).getArguments()) );
			
			
		}
		return attribute;
	}


	/**
	 * 
	 */
	public List<Attribute> createAttributesFromSva(SingleVariableAccess singleVariableAccess) {
		
		EList<MethodInvocation> methodInvocations = getMethodInvocationsFromSVA(singleVariableAccess);
		
		List<Attribute> attributes = new ArrayList<Attribute>();

		if (methodInvocations.size() > 0) {
			
			if (checkIfSvaIsSource(singleVariableAccess, methodInvocations)) {
				
				for (MethodInvocation methodInvocation: methodInvocations) {
				    
					Attribute attribute = new Attribute();
				    attribute.setName(methodInvocation.getMethod().getName());
				    attribute.setArgs( transformArgsToStringList(methodInvocation.getArguments()) );
				    
					attributes.add(attribute);
					
				}
				

			}
			
		} else if (getAssignmentFromSVA(singleVariableAccess).size() > 0) {
			Attribute attribute = new Attribute();
		    attribute.setName("setText");
		    attribute.setArgs(getAssignmentFromSVA(singleVariableAccess));
		    attributes.add(attribute);

		}
		
		

		return linkedAttributes(attributes);
	}
	
	
	
	public List<List<Attribute>>  createAttributesFromFromSVAMethodCase(SingleVariableAccess singleVariableAccess) {
		
		List<MethodInvocation> methodInvocations = (List<MethodInvocation>)(List<?>)getMethodInvocationsFromSVAMethodCase(singleVariableAccess);
		
		List<List<Attribute>> attributes1 = new ArrayList<List<Attribute>>();

		for (MethodInvocation methodInvocation: methodInvocations) {
			 
			  List<Attribute> attributes = new ArrayList<Attribute>();
			  
			  if (checkIfMiIsSource(methodInvocation, getMethodInvocationsFromSVA(methodInvocation))) {
				  for (MethodInvocation methodInvocation2: getMethodInvocationsFromSVA(methodInvocation)) {
					    
						Attribute attribute = new Attribute();
					    attribute.setName(methodInvocation2.getMethod().getName());
					    attribute.setArgs( transformArgsToStringList(methodInvocation2.getArguments()) );
					    
						attributes.add(attribute);
						
					}
				  
				  attributes1.add(attributes);
			  }
			  
			  
			
		}
		
		return attributes1;
	}
	
	
	
	
	/**
	 * get the case of ---> "variable.method1().method2().method3().......method4();"
	 * @param singleVariableAccess
	 * @return
	 */
	public EList<MethodInvocation> getMethodInvocationsFromSVA(Expression singleVariableAccess) {
		
		EList<MethodInvocation> methodInvocations = new BasicEList<MethodInvocation>();
		
		EObject econtainer = singleVariableAccess.eContainer();
		
		while (!(econtainer instanceof Statement)) {
			
			if (econtainer instanceof MethodInvocation) {
				methodInvocations.add((MethodInvocation)econtainer);
			}
			
			econtainer = econtainer.eContainer();
		}
		
		return methodInvocations;
	}
	
	
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
	public List<AbstractMethodInvocation> getMethodInvocationsFromSVAMethodCase(Expression singleVariableAccess) {
		
		List<AbstractMethodInvocation> methodInvocations = new ArrayList<AbstractMethodInvocation>();
		
		EObject econtainer = singleVariableAccess.eContainer();
		
		if (!(econtainer instanceof Assignment) && !(econtainer instanceof MethodInvocation) ) {
			
			while (!(econtainer instanceof MethodDeclaration)) {
				
				
				econtainer = econtainer.eContainer();

				if (econtainer instanceof MethodDeclaration) {
					
					MethodDeclaration methodDeclaration = (MethodDeclaration)econtainer;
					
					methodInvocations = methodDeclaration
							.getUsages()
							.stream()
							.filter( e -> predicatForMethodInvocationSelection(mainPageViewJava,e)).collect(Collectors.toList());
				}
				
			}
			
			
		}
		
		
		return methodInvocations;
	}
	
	
	/**
	 * 
	 * @param mainPageViewJava
	 * @param methodInvocation
	 * @return
	 */
	public boolean predicatForMethodInvocationSelection(ClassDeclaration mainPageViewJava, AbstractMethodInvocation methodInvocation) {
		
		boolean check = false;
		
		EObject container = methodInvocation.eContainer();
		
		while (! ((container instanceof ClassDeclaration) )) {
			
			container = container.eContainer();
			
			if ( ((container instanceof ClassDeclaration) ) && ((ClassDeclaration)container).getName().equals(mainPageViewJava.getName())  ) {
				
				check = true;
				
			}
			  
		}
		
		return check;
		
	}
	
	
	
	
	
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
	public List<String> getAssignmentFromSVA(SingleVariableAccess singleVariableAccess) {
		
		EObject econtainer = singleVariableAccess.eContainer();
		
		List<String> argAsString = new ArrayList<String>(); 
				
		if ( (econtainer instanceof Assignment) && ( ((Assignment) econtainer).getRightHandSide() instanceof ClassInstanceCreation) ){
			
			argAsString = transformArgsToStringList( ((ClassInstanceCreation)(((Assignment) econtainer).getRightHandSide())).getArguments() );
			
		}
		
		return argAsString;
	}
	
	
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @param methodInvocations
	 * @return
	 */
	public boolean checkIfSvaIsSource(SingleVariableAccess singleVariableAccess, EList<MethodInvocation> methodInvocations) {
		
		List<Expression> arguments =  methodInvocations.stream().flatMap(s -> s.getArguments().stream()).collect(Collectors.toList()) ; 
		
		return arguments.stream().filter(e -> compareTwoSva(singleVariableAccess, e)).collect(Collectors.toList()).size() == 0 ;
	}
	
	/***
	 * 
	 * 
	 */
	public boolean checkIfMiIsSource(MethodInvocation methodInvocation, EList<MethodInvocation> methodInvocations) {
		List<Expression> arguments =  methodInvocations.stream().flatMap(s -> s.getArguments().stream()).collect(Collectors.toList()) ; 
		return arguments.stream().filter( e -> compareTwoMi(methodInvocation,e)).collect(Collectors.toList()).size() == 0;
	}
	
	/**
	 * 
	 */
	public boolean compareTwoMi(MethodInvocation methodInvocation, EObject eObject) {
		return ((eObject instanceof MethodInvocation) && ( ((MethodInvocation)eObject).getMethod().getName().equals(methodInvocation.getMethod().getName()) ));
	}
	
	/**
	 * 
	 * @param sva1
	 * @param sva2
	 * @return
	 */
	public boolean compareTwoSva(SingleVariableAccess sva1, EObject sva2) {
		return ((sva2 instanceof SingleVariableAccess) && ( ((SingleVariableAccess)sva2).getVariable().getName().equals(sva1.getVariable().getName()) ));
	}
	
	/**
	 * 
	 * @param arguments
	 * @return
	 */
	public List<String> transformArgsToStringList(List<Expression> arguments) {
		
		List<String> argsList = new ArrayList<String>();
		
		for (Expression expression: arguments ) {
			
			if (expression instanceof BooleanLiteral) {
				argsList.add( ((BooleanLiteral)expression).isValue() ? "true" : "false" );
			}
			
			if (expression instanceof NumberLiteral) {
				argsList.add( ((NumberLiteral)expression).getTokenValue() ); 
			}
					
			if (expression instanceof StringLiteral) {
				argsList.add( ((StringLiteral)expression).getEscapedValue() );
			}
			
			if (expression instanceof SingleVariableAccess) {
				argsList.add( ((SingleVariableAccess)expression).getVariable().getName() );
			}
			
			if (expression instanceof MethodInvocation) {
				
					MethodDeclaration methodDeclaration = (MethodDeclaration)((MethodInvocation)expression).getMethod() ;
					
					ReturnStatement returnStatement = (ReturnStatement)methodDeclaration.getBody().getStatements().get( methodDeclaration.getBody().getStatements().size() - 1 );
					
					argsList.add(((SingleVariableAccess)(returnStatement.getExpression())).getVariable().getName()) ;
			 
				
			}
				
		}
		
		return argsList;
	}
	
	private List<Attribute> linkedAttributes(List<Attribute> attributes) {
			
			if (attributes.size()>0) {
				for(int j = 0; j < attributes.size(); j++) {
						
					if (j+1<attributes.size()) {
						attributes.get(j).setAttribute(attributes.get(j+1));
					} 
				}
				attributes.get(attributes.size()-1).setAttribute(null);
			}
			
			return attributes;
	}
	
	
	
	
 
}
