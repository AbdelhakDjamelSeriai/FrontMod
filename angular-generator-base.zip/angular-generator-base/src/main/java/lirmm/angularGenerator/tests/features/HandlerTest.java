package main.java.lirmm.angularGenerator.tests.features;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.AnonymousClassDeclaration;
import org.eclipse.gmt.modisco.java.Block;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ClassInstanceCreation;
import org.eclipse.gmt.modisco.java.ExpressionStatement;
import org.eclipse.gmt.modisco.java.FieldDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.TryStatement;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;
import org.junit.Before;
import org.junit.Test;

import kdm.code.gwt.Page;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gamba.FragmentExtractor;
import main.java.lirmm.angularGenerator.gwt.GwtModelExtractor;
import main.java.lirmm.angularGenerator.gwt.SegmentExtractor;

public class HandlerTest {
	
	SingleVariableAccess singleVariableAccess;
	
	@Before 
	public void setUp() {
		
		Page page = GwtModelExtractor.getInstance().getGwtModelFromSegment(SegmentExtractor.getInstance("gwt-app-11_kdm_gwt.xmi").getSegment()).getPages().get(0);
		
		ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance("gwt-app-1_java.xmi").getClassDeclaration(page);
		
		FieldDeclaration fieldDeclaration = (FieldDeclaration) viewClass.getBodyDeclarations().get(2);
		
		VariableDeclarationFragment variableDeclarationFragment = fieldDeclaration.getFragments().get(0);
		
		EList<SingleVariableAccess> singleVariableAccesses = variableDeclarationFragment.getUsageInVariableAccess();
		
		singleVariableAccess = singleVariableAccesses.get(1); 
	}

	
	/*@Test
	public void can_check_if_super_parent_is_handler() {		
		assertTrue( FragmentExtractor.getInstance().isInHandler(singleVariableAccess) );
	}*/
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
    public MethodDeclaration getOnHandlerMethodCaseOfAnonymousDeclaration(SingleVariableAccess singleVariableAccess)  {
		
		MethodInvocation methodInvocation = (MethodInvocation)singleVariableAccess.eContainer();
		
		ClassInstanceCreation objectHandler = (ClassInstanceCreation)methodInvocation.getArguments().get(0);
		
		AnonymousClassDeclaration anonymousClassDeclaration = objectHandler.getAnonymousClassDeclaration();
		
		MethodDeclaration methodDeclaration = (MethodDeclaration) anonymousClassDeclaration.getBodyDeclarations()
				.stream().filter(MethodDeclaration.class::isInstance).collect(Collectors.toList()).get(0);
		
		return methodDeclaration;
	}
	
	@Test
	public void can_get_handler_method_inside_Anonymous_Type() {
		assertEquals( getOnHandlerMethodCaseOfAnonymousDeclaration(singleVariableAccess).getName(), "onDoubleClick");
	}
    
	
	/**
	 * 
	 * @param singleVariableAccess
	 * @return
	 */
	public List<Statement> getAllStatementsInsideMethodHandler(SingleVariableAccess singleVariableAccess){
		return getAllStatementOfGivenStatement(
						getOnHandlerMethodCaseOfAnonymousDeclaration(singleVariableAccess).getBody()
		) ;
	}
	
	/**
	 * 
	 * @param block
	 * @return
	 */
	public List<Statement> getAllStatementOfGivenStatement(Block block){	
		List<Statement> statements = new ArrayList<>();
		for (Statement statement: block.getStatements()) {
			if ( (!(statement instanceof TryStatement)) && (!(statement instanceof Block)) ) {
					statements.add(statement);	
			} else {															
				if (statement instanceof Block) {
					statements.addAll(getAllStatementOfGivenStatement( (Block) statement));						
				}		
				if (statement instanceof TryStatement) {
					statements.addAll(getAllStatementOfGivenStatement( ((TryStatement) statement).getBody()) );
				}
			}	
		}		
		return statements;
	}
	
	@Test
	public void can_get_all_statements_of_click_Handler() {
		assertEquals( getAllStatementsInsideMethodHandler(singleVariableAccess).size(), 2);
	}
	

	/**
	 * 
	 * @param block
	 * @return
	 */
	
	
	public List<ExpressionStatement> getExpressionStmts(List<Statement> statements) {
		return (List<ExpressionStatement>)(List<?>)statements.stream().filter(ExpressionStatement.class::isInstance).collect(Collectors.toList());
	}
	
	@Test
	public void can_get_Expression_Statements() {
		
		List<Statement> statements = getAllStatementsInsideMethodHandler(singleVariableAccess);
		
		assertEquals(getExpressionStmts(statements).size(), 2 );
	}
	
	/**
	 * 
	 * @param expressionStatements
	 * @return
	 */
	public List<MethodInvocation> getMethodInovcations(List<ExpressionStatement> expressionStatements) {
		return (List<MethodInvocation>)(List<?>)expressionStatements.stream().map(e -> e.getExpression())
									.filter(MethodInvocation.class::isInstance).collect(Collectors.toList());
	}
	
	public void can_get_all_method_Invocations() {
		
		List<Statement> statements = getAllStatementsInsideMethodHandler(singleVariableAccess);
		
		List<ExpressionStatement> expressionStatement = getExpressionStmts(statements);
		
		assertEquals( getMethodInovcations(expressionStatement).size(), 2);
	}
	 
	
	/**
	 * 
	 * @param methodInvocations
	 * @return
	 */
	public List<SingleVariableAccess> getAllSingleVariableAccesses(List<MethodInvocation> methodInvocations) {
		List<SingleVariableAccess> singleVariableAccesses = new ArrayList<>();
		
		for (MethodInvocation methodInvocation: methodInvocations) {
			if(methodInvocation.getExpression() instanceof SingleVariableAccess) {
				singleVariableAccesses.add((SingleVariableAccess)methodInvocation.getExpression());
			} else {
				
				
			}
		}		
		return singleVariableAccesses;
	}
	
	
	

}
