package main.java.lirmm.angularGenerator.tests.features;

import static org.junit.Assert.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Test;

public class JsoupTest {

	@Test
	public void test() {
		Document document = Jsoup.parse("<lirmm-hyperlink [hrefAnchor]=\"ffgfd\"></lirmm-hyperlink>");
		
		document.addClass("helloWorld");

		
		assertEquals(document.getElementsByAttribute("[hrefAnchor]"),"fsdsds");
	}

}
