package main.java.lirmm.angularGenerator.tests.features;

import static org.junit.Assert.*;

import org.junit.Test;

public class MethodInvocationExtractorTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
