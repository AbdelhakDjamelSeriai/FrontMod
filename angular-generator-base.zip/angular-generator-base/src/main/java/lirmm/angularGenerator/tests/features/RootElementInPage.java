package main.java.lirmm.angularGenerator.tests.features;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


import org.eclipse.gmt.modisco.java.Block;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.ConstructorDeclaration;
import org.eclipse.gmt.modisco.java.ExpressionStatement;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.MethodInvocation;
import org.eclipse.gmt.modisco.java.PrimitiveType;
import org.eclipse.gmt.modisco.java.ReturnStatement;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.Statement;
import org.eclipse.gmt.modisco.java.ThisExpression;
import org.eclipse.gmt.modisco.java.TryStatement;
import org.eclipse.gmt.modisco.java.TypeAccess;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;
import org.junit.Test;

import kdm.code.gwt.Page;
import kdm.code.gwt.Widget;
import kdm.kdm.Segment;
import main.java.lirmm.angularGenerator.dao.Attribute;
import main.java.lirmm.angularGenerator.dao.RootElement;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gamba.FragmentExtractor;
import main.java.lirmm.angularGenerator.gwt.GwtModelExtractor;
import main.java.lirmm.angularGenerator.gwt.SegmentExtractor;
import main.java.lirmm.angularGenerator.helpers.FilterHelper;
import main.java.lirmm.angularGenerator.helpers.RootElementHelper;

public class RootElementInPage {
	
	String source_model = "gwt-app-18_kdm_gwt.xmi";
	String java_model = "gwt-app-18_java.xmi";
	
	
	@Test
	public void can_we_check_element_root_for_given_page() {
		
		Segment segment = SegmentExtractor.getInstance(source_model).getSegment();
		
		ClassDeclarationExtractor classDeclarationExtractor = ClassDeclarationExtractor.getInstance(java_model);
		
		Page page = GwtModelExtractor.getInstance().getGwtModelFromSegment(segment).getPages().get(5);
		
		System.err.println(page.getName());
	
		assertEquals(RootElementHelper.getInstance(classDeclarationExtractor).getRootElement(page).getName(),"dialogPanel");
		
		
	}

	public RootElement getRootElement(Page page) {
		
		if (pageInstanceOfComposite(page) != null) {
			return pageInstanceOfComposite(page);
		}
		
		if (rootPanelInstanceUsed(page) != null) {

			return rootPanelInstanceUsed(page);
		}
		
		if (pageExtendsFromWidget(page) != null) {

			return pageExtendsFromWidget(page);
		}
		
		if (getContainerElementPage(page) != null) {
			return getContainerElementPage(page);
		}
		
		return null;		
	}

	public RootElement pageExtendsFromWidget(Page page) {
		
		RootElement rootElement = null;

		if ( Boolean.TRUE.equals(page.getIsKindOfWidget()) ) {
			
			rootElement = getContainerElementPage(page);
	
			rootElement.setTypeElement(page.getTypeOfWidget());
			
		}
		
		return rootElement;
	}
	

	public List<MethodInvocation> getAddInvokedByThisExpression(List<MethodInvocation> addInvocations) {
		return addInvocations.stream().filter(e -> e.getExpression() instanceof ThisExpression).collect(Collectors.toList()) ;
	}
	
	public List<String> getArgumentsOfmethodInvocation(List<MethodInvocation> methodInvocations){
		
		List<String> args = new ArrayList<>();
		for (MethodInvocation methodInvocation: methodInvocations) {
			if (methodInvocation.getArguments().get(0) instanceof SingleVariableAccess) {
				args.add( ((SingleVariableAccess)(methodInvocation.getArguments().get(0))).getVariable().getName() );
			}
		}
		return args ;
	}
	
	
	

	public RootElement rootPanelInstanceUsed(Page page) {
		
		RootElement rootElement = null;
		
		// 1- get all constructors + method declarations
		ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance(java_model).getClassDeclaration(page);
		
		// 2- get all constructors Declaration
		List<ConstructorDeclaration> constructorDeclarations = getClassConstructors(viewClass);			
		
		// 3- get all methods Declaration
		List<MethodDeclaration> methodDeclarations = getMethodDeclarations(viewClass);
		
		// 4- get all statements of constructors declaration
		List<Statement> statementsFromConstructors = getAllStatementsOfConstructors(constructorDeclarations);
		
		// 5- get all statements of methods declaration
		List<Statement> statementsFromMethods = getAllStatementsOfMethods(methodDeclarations);
		
		// 6- combine the two list
		statementsFromConstructors.addAll(statementsFromMethods);
		
		// 7- Get All Expression Statements
		List<ExpressionStatement> expressionStatements = getExpressionStmts(statementsFromConstructors);
		
		// 6- Get All Method Invocations
		List<MethodInvocation> methodInvocations = getMethodInovcations(expressionStatements);
		
		// 7- Get only the add methods
		List<MethodInvocation> addInvocations = getAddMethodInvocations(methodInvocations);
		
		// 8- Search for primary for RootPanel.get() 
		String element = getRootPanelIfExist(addInvocations);
		
		if (element != null) {
			rootElement = new RootElement();
			rootElement.setTypeElement(element);
		}
		
		
		return rootElement;
	}
	
	public String getRootPanelIfExist(List<MethodInvocation> addInvocations) {
		
		for (MethodInvocation methodInvocation: addInvocations) {
			if (checkIfRootPanelExist(methodInvocation,"RootPanel")) {
				return "RootPanel"; // <-- may you will change this , case when you have multiples : RootPanel.get("id1"), RootPanel.get("id2") 
			}
			
			if (checkIfRootPanelExist(methodInvocation, "RootLayoutPanel")) {
				return "RootLayoutPanel";  
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param methodInvocation
	 * @param typeElement : RootPanel || RootLayoutPanel
	 * @return
	 */
	public boolean checkIfRootPanelExist(MethodInvocation methodInvocation, String typeElement) { 
		return (
				( methodInvocation.getExpression() instanceof MethodInvocation) && 				
				( ((MethodInvocation)methodInvocation.getExpression()).getMethod().getName().equals("get") ) && 				
				( ((MethodInvocation)methodInvocation.getExpression()).getExpression() instanceof TypeAccess ) &&				
				( ((TypeAccess)((MethodInvocation)methodInvocation.getExpression()).getExpression()).getType() instanceof ClassDeclaration ) &&				
				( (((ClassDeclaration)((TypeAccess)((MethodInvocation)methodInvocation.getExpression()).getExpression()).getType())
						.getName().equals(typeElement)) )								
		); 
	}
	
	
	
	public RootElement pageInstanceOfComposite(Page page) {
			
		RootElement rootElement = null;
		
		if (Boolean.TRUE.equals(page.getIsKindOfComposite())) {
			
			// 1- Get Class Declaration 
			ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance(java_model).getClassDeclaration(page);
			// 2- Get Constructor declaration 
			List<ConstructorDeclaration> constructorDeclarations = getClassConstructors(viewClass);
			// 3- Get All(general/nested) statements of constructor declaration
			List<Statement> statements =  getAllStatementsOfConstructors(constructorDeclarations);
			// 4- Get All Expression Statements
			List<ExpressionStatement> expressionStatements = getExpressionStmts(statements);
			// 5- Get All Method Invocations
			List<MethodInvocation> methodInvocations = getMethodInovcations(expressionStatements);
			// 6- Search for initWidget method Invocation
			MethodInvocation methodInvocation = searchForInitWidgetMethod(methodInvocations);
			// 7- If it exists Then get the name widget from argument
			String rootName = getArgumentOfInitWidget(methodInvocation);
			rootElement = new RootElement();
			rootElement.setName(rootName);	
			rootElement.setTypeOfCreationString("initWidget");
		}
		
		return rootElement;
	}
	
	// will be in the helper
	public List<ConstructorDeclaration> getClassConstructors(ClassDeclaration classDeclaration) {
		
	    return  classDeclaration.getBodyDeclarations().stream().filter(ConstructorDeclaration.class::isInstance)
	    		.map(ConstructorDeclaration.class::cast).collect(Collectors.toList());
	}
	
	// will be also in the helper
	public List<MethodDeclaration> getMethodDeclarations(ClassDeclaration classDeclaration) {
		return classDeclaration.getBodyDeclarations().stream().filter(MethodDeclaration.class::isInstance)
				.map(MethodDeclaration.class::cast).collect(Collectors.toList());
	}
	
	/**
	 * 
	 * @param block
	 * @return
	 */
	public List<Statement> getAllStatementOfGivenStatement(Block block){	
		List<Statement> statements = new ArrayList<>();
		for (Statement statement: block.getStatements()) {
			if ( (!(statement instanceof TryStatement)) && (!(statement instanceof Block)) ) {
					statements.add(statement);	
			} else {															
				if (statement instanceof Block) {
					statements.addAll(getAllStatementOfGivenStatement( (Block) statement));						
				}		
				if (statement instanceof TryStatement) {
					statements.addAll(getAllStatementOfGivenStatement( ((TryStatement) statement).getBody()) );
				}
			}	
		}		
		return statements;
	}
	
	public List<Statement> getAllStatementsOfConstructors(List<ConstructorDeclaration> 
	  			constructorDeclarations) {
		List<Statement> statements = new ArrayList<>();
		
		for (ConstructorDeclaration constructorDeclaration: constructorDeclarations) {
			if (constructorDeclaration.getBody()!=null) {
				statements.addAll(getAllStatementOfGivenStatement(constructorDeclaration.getBody()));
			}
		}
		
		/*return constructorDeclarations.stream().map(c -> getAllStatementOfGivenStatement(c.getBody()))
				.collect(Collectors.toList());*/
		return statements;
	}
	
	public List<Statement> getAllStatementsOfMethods(List<MethodDeclaration>
			methodDeclarations) {
		List<Statement> statements = new ArrayList<>();
		
		for (MethodDeclaration constructorDeclaration: methodDeclarations) {
			if (constructorDeclaration.getBody()!=null) {
				statements.addAll(getAllStatementOfGivenStatement(constructorDeclaration.getBody()));
			}
		}
		
		return statements;
		
	}
	
	
	public List<ExpressionStatement> getExpressionStmts(List<Statement> statements) {
		return statements.stream().filter(ExpressionStatement.class::isInstance).map(ExpressionStatement.class::cast).collect(Collectors.toList());
	}
	
	public List<MethodInvocation> getMethodInovcations(List<ExpressionStatement> expressionStatements) {
		return expressionStatements.stream().map(e -> e.getExpression())
									.filter(MethodInvocation.class::isInstance).map(MethodInvocation.class::cast).collect(Collectors.toList());
	}
	
	public List<MethodInvocation> getAddMethodInvocations(List<MethodInvocation> methodInvocations) {
		return methodInvocations.stream().filter(e -> isAddMethod(e) ).collect(Collectors.toList());
	}
	
	
	public boolean isAddMethod(MethodInvocation methodInvocation) {
		return methodInvocation.getMethod().getName().equals("add");
	}
	
	public MethodInvocation searchForInitWidgetMethod(List<MethodInvocation> methodInvocations) {
		
		MethodInvocation myInitWidget = null ;
		for (MethodInvocation methodInvocation: methodInvocations) {
			
			if (methodInvocation.getMethod().getName().equals("initWidget")) {

				myInitWidget =  methodInvocation;
				
				return myInitWidget;

			} else {
				
				myInitWidget = searchForInitWidgetMethodFromMethodBody((MethodDeclaration)methodInvocation.getMethod());
			}
		}

		return myInitWidget;
	}
	
	public MethodInvocation searchForInitWidgetMethodFromMethodBody(MethodDeclaration methodDeclaration) {
		
		MethodInvocation methodInvocation = null;
		
		if (methodDeclaration.getBody() != null) {
			List<Statement> statements =  getAllStatementOfGivenStatement(methodDeclaration.getBody());
			List<MethodInvocation> methodInvocations = getMethodInovcations( getExpressionStmts(statements) );
			methodInvocation = searchForInitWidgetMethod(methodInvocations);
		}
		
		return methodInvocation;
	}
	
	/**
	 * Analyser puis retourner le nom de la variable repr�senter comme argument dans la m�thode initWidget(...)
	 * @param methodInvocation
	 * @return
	 */
	public String getArgumentOfInitWidget(MethodInvocation methodInvocation) {
		
		String rootWidgetName = null;
		
		// si on a un type variable, p.ex:  initWidget(addPanel)
		if ( (methodInvocation != null) && (methodInvocation.getArguments().get(0) instanceof SingleVariableAccess) ) {
			// sva -> &addPanel
			SingleVariableAccess expression = (SingleVariableAccess)methodInvocation.getArguments().get(0);
			// rootWidget = "addPanel"
			rootWidgetName = expression.getVariable().getName();	
		}
		
		// si on a un appel � une fonction qui retourne un element de la page ou l'interface "Exportation des �l�ments"
		if ( (methodInvocation != null) && (methodInvocation.getArguments().get(0) instanceof MethodInvocation)  ) {
			MethodInvocation mtdInvocation = (MethodInvocation)methodInvocation.getArguments().get(0);
			// si la m�thode invocation dont la m�thode a un body accessible, � � dire non nil dans le mod�le 
			if (mtdInvocation.getMethod().getBody()!=null) {
				// on r�cup�re le contenu de la m�thode invoqu�e, � � dire on acc�de � la d�claration de la m�thode invoqu�e
				MethodDeclaration methodDeclaration = (MethodDeclaration)mtdInvocation.getMethod();
				// la m�thode doit etre une m�thode retournable
				if (!(methodDeclaration.getReturnType().getType() instanceof PrimitiveType)) {
					// on cherche le return statement
					for (Statement statement: methodDeclaration.getBody().getStatements()) {
						// si on le trouve
						// on v�rifie si le return est un type d'access � une variable  
						if ( (statement instanceof ReturnStatement)  && ((ReturnStatement)statement).getExpression() instanceof SingleVariableAccess) {
							// on r�cup�re cette variable
							SingleVariableAccess expression = (SingleVariableAccess)((ReturnStatement)statement).getExpression();
							// on r�cup�re le nom
							rootWidgetName = expression.getVariable().getName();
						}
					}
				}
			}
		}
		
		return rootWidgetName;
	}
	
	
    public RootElement getContainerElementPage(Page page) {
		
    	RootElement rootElement = new RootElement();
    	
		List<List<String>> listOfTree =  new ArrayList<>();
		
		ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance(java_model).getClassDeclaration(page);
				
		FragmentExtractor fragmentExtractor = FragmentExtractor.getInstance();	
		
		fragmentExtractor.setClassDeclaration(viewClass);
		
		for (Widget widget: page.getWidgets()) {
			
			VariableDeclarationFragment  fragment = fragmentExtractor.getWidgetFromClassDeclaration(widget.getName());	
		
			List<Attribute> attributs = new ArrayList<>();	
	
			List<String> childTree = new ArrayList<>(); 
			
			if ( fragment != null ) {
				
				childTree.add(fragment.getName());  			
				if (fragment.getInitializer() !=null) {					
					attributs.add(fragmentExtractor.createAttributeFromVariableDeclaration(fragment));
				}
				for (SingleVariableAccess singleVariableAccess: fragment.getUsageInVariableAccess() ) {
					 
					if ( !fragmentExtractor.getAssignmentFromSVA(singleVariableAccess).isEmpty() 
															|| 
							!fragmentExtractor.getMethodInvocationsFromSVA(singleVariableAccess).isEmpty() ) {
						
						if ( !fragmentExtractor.createAttributesFromSva(singleVariableAccess).isEmpty() ) {
														
							FilterHelper.getInstance().filterAdd(childTree, fragmentExtractor.createAttributesFromSva(singleVariableAccess).get(0));
						}						 	
						 	
					} 
					
					else if ( !fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess).isEmpty() ) {												
						 
						for (List<Attribute> attributes: fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess)) {							 
							if (!attributes.isEmpty()) {

								FilterHelper.getInstance().filterAdd(childTree ,attributes.get(0));
							}
						}						
					}
				 
				}
				
			}
			
			if (childTree.size() > 1 ) {
				listOfTree.add(childTree);

			}
				
		}
		
		if (getElementRootOfPage(viewClass, FilterHelper.getInstance().filterTreeListTogetRoot(listOfTree)) != null) {
		    rootElement = new RootElement();
			rootElement.setName(getElementRootOfPage(viewClass, FilterHelper.getInstance().filterTreeListTogetRoot(listOfTree)));
		}
		
		
		
		return rootElement; 
	}
	
	public String getElementRootOfPage(ClassDeclaration page, List<List<String>> listElements) {
		
		String root =  null;
		
		if ( (root == null) && (!listElements.isEmpty()) ) {
			
			root = listElements.get(0).get(0);	
			
		} 		
		
		return root;
	}
	
	public void printListElements(List<List<String>> listElements) {
		
		for (List<String> strings : listElements) {			
			System.out.print(strings.get(0) + " : ");			
			for (int i = 1; i < strings.size(); i++) {
				System.out.println(strings.get(i) + " ,");
			}	
			System.out.println("\n");
		}
		
	}
 
	

	
	
	
	
	
}
