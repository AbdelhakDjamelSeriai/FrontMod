package main.java.lirmm.angularGenerator.tests.features;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.MethodDeclaration;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;
import org.junit.Test;

import kdm.code.gwt.Page;
import kdm.code.gwt.Widget;
import kdm.kdm.Segment;
import main.java.lirmm.angularGenerator.dao.Attribute;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gamba.FragmentExtractor;
import main.java.lirmm.angularGenerator.gwt.GwtModelExtractor;
import main.java.lirmm.angularGenerator.gwt.SegmentExtractor;
import main.java.lirmm.angularGenerator.helpers.FilterHelper;
import main.java.lirmm.angularGenerator.helpers.MethodDeclarationExtractor;
import main.java.lirmm.angularGenerator.helpers.StatementExtractor;

public class RootWidgetPageTest {

	@Test
	public void check_if_we_can_get_list_of_rootwidget_with_its_children() {
		
		Segment segment = SegmentExtractor.getInstance("gwt-app-11_kdm_gwt.xmi").getSegment();
		
		Page page = GwtModelExtractor.getInstance().getGwtModelFromSegment(segment).getPages().get(0);
		
		List<List<String>> listOfTree =  new ArrayList<List<String>>();
		
		ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(page);
		
		System.err.println(viewClass.getName());
		
		FragmentExtractor fragmentExtractor = FragmentExtractor.getInstance();
		
		fragmentExtractor.setClassDeclaration(viewClass);
		

		for (Widget widget: page.getWidgets()) {
			
			VariableDeclarationFragment fragment = fragmentExtractor.getWidgetFromClassDeclaration(widget.getName());
			
			List<Attribute> attributs = new ArrayList<Attribute>();
			
			List<String> childTree = new ArrayList<String>(); 
			
			if ( fragment != null ) {
				
				childTree.add(fragment.getName());  
				
				if (fragment.getInitializer() !=null) {
					
					attributs.add(fragmentExtractor.createAttributeFromVariableDeclaration(fragment));

				}
				
				for (SingleVariableAccess singleVariableAccess: fragment.getUsageInVariableAccess() ) {
					 
					if ( fragmentExtractor.getAssignmentFromSVA(singleVariableAccess).size() > 0 || fragmentExtractor.getMethodInvocationsFromSVA(singleVariableAccess).size() > 0 ) {
						
						if (fragmentExtractor.createAttributesFromSva(singleVariableAccess).size() > 0) {
							
							FilterHelper.getInstance().filterAdd(childTree, fragmentExtractor.createAttributesFromSva(singleVariableAccess).get(0));
						}
						 	
						 	
					} 
					
					else if ( fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess).size() > 0 ) {
						
						System.out.println(fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess).size());
						
						for (List<Attribute> attributes: fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess)) {							 
							FilterHelper.getInstance().filterAdd(childTree ,attributes.get(0));
						}
						
						
					}
					
					
					 
				}
				
			}
			
			if (childTree.size() > 1 ) {
				listOfTree.add(childTree);

			}
		}
		 
		assertEquals(FilterHelper.getInstance().filterTreeListTogetRoot(listOfTree).size(), 45);

		
	}
	
	
	
	@Test
	public void check_is_page_implement_is_widget() {
		
		Segment segment = SegmentExtractor.getInstance("gwt-app-11_kdm_gwt.xmi").getSegment();
		
		Page page = GwtModelExtractor.getInstance().getGwtModelFromSegment(segment).getPages().get(0);
		
		ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(page);
		
		assertEquals(isPageImplementIsWidget(viewClass), "container");

	}
	
	public void check_is_page_contain_init_widget() {
		
		Segment segment = SegmentExtractor.getInstance("gwt-app-11_kdm_gwt.xmi").getSegment();
		
		Page page = GwtModelExtractor.getInstance().getGwtModelFromSegment(segment).getPages().get(0);
		
		ClassDeclaration viewClass = ClassDeclarationExtractor.getInstance("mvp_java.xmi").getClassDeclaration(page);
		
		assertEquals(isPageContainInitWidget(viewClass), "container");
	}
	
	/**
	 * 
	 * @param page
	 * @return
	 */
	public String isPageImplementIsWidget(ClassDeclaration page) {
		
		String widgetNameString = null;
		
		if ( page.getSuperInterfaces().stream().filter( e -> e.getType().getName().equals("IsWidget")).findFirst().isPresent() ) {
			
			MethodDeclaration methodDeclaration = MethodDeclarationExtractor.getInstance().getMethodDeclarationFromClassDeclaration(page, "asWidget");
			
			
			widgetNameString = StatementExtractor.getInstance().getWidgtNameReturedByAsWidget(methodDeclaration);
		}
		
		return widgetNameString;
	}
	
	/**
	 * 
	 * @param page
	 * @return
	 */
	public String isPageContainInitWidget(ClassDeclaration page) {
		
		if ( page.getSuperClass().getType().getName().equals("Composite") ) {
			
		}
		
		return null;
	}
	
	
	
	
	

}
