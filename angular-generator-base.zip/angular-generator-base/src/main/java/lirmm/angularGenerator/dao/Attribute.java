package main.java.lirmm.angularGenerator.dao;

import java.util.List;

public class Attribute {
	
	private String name;
	
	private List<String> args;
	
	private String token;
	
	private Attribute attribute;
	
	public Attribute() {
		
	}
	
	public String getName() {
		return this.name ;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<String> getArgs() {
		return this.args;
	}
	public void setArgs(List<String> args) {
		this.args = args;
	}
	
	public void setToken(String token) {
		this.token = token;
	}
	
	public String getToken() {
		return this.token;
	}
	
	public Attribute getAttribute() {		
		return this.attribute ;
	}
	
	
	public void setAttribute(Attribute attribute) {
		
		this.attribute = attribute;
		
	}
	
	public void showAttribute() {
		
		System.out.println("{");
		
		System.out.println("name :" + name + ",");
		
		System.out.println("token :" + token + ",");
		
		System.out.println("args : {");
		
		for(String string: args) {
			
			System.out.println(string + ",");
		}
				
		System.out.println("}");
		
		
		
		showInternalMethod();

		
	}
	
	public void showInternalMethod() {
		if (attribute != null) {
			
			attribute.showAttribute();
			
		} else {
			System.out.println("this's the end Object");
		}
		
		
	}
	
	
}
