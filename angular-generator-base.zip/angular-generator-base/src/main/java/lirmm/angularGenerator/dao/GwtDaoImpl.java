package main.java.lirmm.angularGenerator.dao;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gmt.modisco.java.ClassDeclaration;
import org.eclipse.gmt.modisco.java.SingleVariableAccess;
import org.eclipse.gmt.modisco.java.VariableDeclarationFragment;
import org.json.JSONArray;
import org.json.JSONObject;

import kdm.code.ClassUnit;
import kdm.code.gwt.GwtModel;
import kdm.code.gwt.Page;
import kdm.code.gwt.Route;
import kdm.code.gwt.Widget;
import main.java.lirmm.angularGenerator.gamba.ClassDeclarationExtractor;
import main.java.lirmm.angularGenerator.gamba.FragmentExtractor;
import main.java.lirmm.angularGenerator.gwt.PagesExtractor;
import main.java.lirmm.angularGenerator.gwt.WidgetsExtractor;
import main.java.lirmm.angularGenerator.helpers.RootElementHelper;

public class GwtDaoImpl implements GwtDao{
	
	private static FileWriter file;
	private GwtModel gwtModel ;
	private EList<Page> pages;
	private ClassDeclarationExtractor classDeclarationExtractor;
	private String fileName;
	private List<String> exptectedPages;
	
	public GwtDaoImpl(String fileName, List<String> exptectedPages ,GwtModel gwtModel, ClassDeclarationExtractor classDeclarationExtractor) {
		this.gwtModel = gwtModel;
		this.pages =  PagesExtractor.getInstance().getPagesFromGwtModel(gwtModel);
		this.classDeclarationExtractor = classDeclarationExtractor;
		this.fileName = fileName;
		this.exptectedPages = exptectedPages; 
	}
	

	public void saveGwtWidgets() {

		JSONObject template = new JSONObject();

		template.put("AppName", gwtModel.getName());
		
		template.put("Pages",savePagesOfAppIntoJsonArray());
				
		toFileJson(template);
		
	}
	
	
	public JSONObject saveInternalAttribute(JSONObject internalTempalte ,Attribute attribut){
		
		JSONObject internalTempalte1 = new JSONObject();
		
		internalTempalte1.put("args", attribut.getArgs());
		
		internalTempalte.put(attribut.getName(), internalTempalte1);
		
		return internalTempalte ;
	}
	
	public JSONObject saveAttribut(Attribute attribute) {
		
		JSONObject rootObjectTemplate = new JSONObject();
		
		JSONObject internalTempalte = new JSONObject();	
				
		internalTempalte.put("args", attribute.getArgs());		
		
		rootObjectTemplate.put(attribute.getName(), internalTempalte);
		
		if (attribute.getAttribute()!=null) {		
			
			saveInternalAttribute(internalTempalte, attribute.getAttribute());			
		}
		
		toFileJson(rootObjectTemplate);
		return rootObjectTemplate;
	}
	/**
	 * 
	 * @return
	 */
	private JSONArray savePagesOfAppIntoJsonArray() {
		
		JSONArray pagesTemplate = new JSONArray();	
		
		List<Page> truePages = pages.stream().filter( e -> exptectedPages.contains(e.getName()) ).collect(Collectors.toList());
		
		for(Page page: truePages){
			
			JSONObject pageTempate = new JSONObject();	
			
			pageTempate.put("Page", page.getName());
			
			pageTempate.put("Widgets",saveWidgetsOfPageIntoJsonArray(page) );
			
			pageTempate.put("elementRoot", 
					
					RootElementHelper.getInstance(classDeclarationExtractor).getRootElement(page).getName());
			
			pagesTemplate.put(pageTempate);		
			
		}		
		return pagesTemplate;
	}
	
	/**
	 * 
	 * @param page
	 * @return
	 */
	private JSONArray saveWidgetsOfPageIntoJsonArray(Page page) {
		
		JSONArray widgetsTemplate = new JSONArray();
		for(Widget widget: WidgetsExtractor.getInstance().getWidgetsFromPage(page)) {
			
			JSONObject widgetTemplate = new JSONObject();
			
			widgetTemplate.put("name", widget.getName());
			
			widgetTemplate.put("type", widget.getTypeWidget().getName()); 		
			
			/*Route route =  page.getRoutes().stream().filter( e -> e.getBy().getName().equals(widget.getName()) && e.getToken()!=null ).findFirst().orElse(null);		
			
			if (route!=null) { widgetTemplate.put("token", route.getToken()); }*/		
		
			widgetTemplate.put("actions", saveAttributesOfWidget(page, widget));
			
			widgetTemplate.put("containsWidgets", widget.getIsContainer());
			
			if ( Boolean.TRUE.equals(widget.getIsContainer()) ) {				
				
				widgetTemplate.put("elementRootComponent", RootElementHelper.getInstance(classDeclarationExtractor).getRootElement(page).getName());
				widgetTemplate.put("nestedWidget", saveNestedWidgetsIntoJsonArray(widget));
				
			}
			
			widgetsTemplate.put(widgetTemplate);			
		
		}		
		return widgetsTemplate;		
	}
	
	
	/**
	 * 
	 */
	private JSONArray saveNestedWidgetsIntoJsonArray(Widget widget1) {		
		JSONArray widgetsTemplate = new JSONArray();	
		for(Widget widget: widget1.getNestedWidgets()) {		
			JSONObject widgetTemplate = new JSONObject();
			widgetTemplate.put("name", widget.getName());
			widgetTemplate.put("type", widget.getTypeWidget().getName()); //this.cleanWord(widget.getClass().getSimpleName(),"Impl")					
			widgetTemplate.put("actions", saveAttributesOfWidget(widget1.getTypeWidget(), widget));
			//widgetTemplate.put("containsWidgets", widget.getIsContainer());			
			widgetsTemplate.put(widgetTemplate);				
		}		
		return widgetsTemplate;		
	}
	
	
	/**
	 * 
	 * @param word
	 * @param which
	 * @return
	 */
	private String cleanWord(String word, String which) {		
        String target=word.copyValueOf(which.toCharArray());      
        word=word.replace(target, "");     
        return word;
	}
	
	/**
	 * 
	 * @param widget
	 * @return
	 */
	/*private JSONArray saveAttributesOfWidget(Widget widget) {
		
		JSONArray actionsTemplate = new JSONArray();
		
		
		for (ActionElement actionElement: AttributesExtractor.getInstance().getAttributesOfWidget(widget)) {
			 
			
			 List<Attribute> attributs = AttributesExtractor.getInstance().createAttributesFromCodeItems(
					 AttributesExtractor.getInstance().getAttributesFromMethodInvocation(actionElement)
					 );
			 
			 if (attributs.size()>0) {
				 actionsTemplate.put(saveAttribut(attributs.get(0)));
			 }

		}
		
		
		return actionsTemplate;
	}*/
	
	/**
	 * 
	 * @param widget
	 * @return
	 */
	private JSONArray saveAttributesOfWidget(ClassUnit page ,ClassUnit widget) {
		
			JSONArray actionsTemplate = new JSONArray();
			
			List<Attribute> attributs = new ArrayList<>();
			//"gwt-app-11_kdm_gwt.xmi"
			ClassDeclaration viewClass = classDeclarationExtractor.getClassDeclaration(page);
			
			System.err.println(widget.getName());
			
			FragmentExtractor fragmentExtractor = FragmentExtractor.getInstance();
			
			fragmentExtractor.setClassDeclaration(viewClass);

			VariableDeclarationFragment fragment = fragmentExtractor.getWidgetFromClassDeclaration(widget.getName());
			
			//System.out.println(fragment.getName() +"---");
		
			if ( fragment != null ) {
				
				if (fragment.getInitializer() !=null ) {					
					attributs.add(fragmentExtractor.createAttributeFromVariableDeclaration(fragment));
					actionsTemplate.put(saveAttribut(attributs.get(0)));
				}
				
				for (SingleVariableAccess singleVariableAccess: fragment.getUsageInVariableAccess() ) {
					 
					if (  !fragmentExtractor.getAssignmentFromSVA(singleVariableAccess).isEmpty() 
							                           || 
					      !fragmentExtractor.getMethodInvocationsFromSVA(singleVariableAccess).isEmpty() 
					   ) 
					{
						
						 attributs = fragmentExtractor.createAttributesFromSva(singleVariableAccess);

						 if (! attributs.isEmpty()) {	
							 actionsTemplate.put(saveAttribut(attributs.get(0)));							 
						 }
					} 
					
					else if ( !fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess).isEmpty() ) {
						
						for (List<Attribute> attributes: fragmentExtractor.createAttributesFromFromSVAMethodCase(singleVariableAccess)) {
								 
							actionsTemplate.put(saveAttribut(attributes.get(0)));
						}
					}
					 
				}
				
			}
			
		return actionsTemplate;

	}
	
	
	
	private JSONObject saveAttribute(Attribute attribut) {
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(attribut.getName(), attribut.getArgs());
		return jsonObject;
		
	}
	
		
	/**
	 * 
	 * @param template
	 */
	private void toFileJson(JSONObject template) {
		
		try {			 
            // Constructs a FileWriter given a file name, using the platform's default charset
           file =  (new FileWriter(fileName));
           file.write(template.toString());
          
 
        } catch (IOException e) {
            e.printStackTrace();
 
        } finally {
 
            try {
                file.flush();
                file.close();
            } catch (IOException e) {
                e.printStackTrace();
            }		
	    }
	}
	
	
	
	
}
