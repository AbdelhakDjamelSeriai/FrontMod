package main.java.lirmm.angularGenerator.dao;

public class RootElement {

	private String id;
	
	private String name;
	
	private String typeElement;
	
	private String firstElement;
	
	private String typeOfCreationString;
	
	
	public RootElement() { }
	
	/*** Sets ***/
	public void setId(String id) { this.id = id; }
	
	public void setName(String name) { this.name = name; }
	
	public void setTypeElement(String typeElement) { this.typeElement = typeElement; }
	
	public void setFirstElement(String firstElement) { this.firstElement = firstElement; }
	
	public void setTypeOfCreationString(String typeOfCreatingString) { this.typeOfCreationString = typeOfCreatingString; }
	
	
	/*** Gets ***/
	public String getId() { return id; }
	
	public String getName() { return name; }
	
	public String getTypeElement() { return typeElement; }
	
	public String typeOfCreationString() { return typeOfCreationString; }
	
	public String getFirstElement() { return firstElement; }
	
	
	
	
}
