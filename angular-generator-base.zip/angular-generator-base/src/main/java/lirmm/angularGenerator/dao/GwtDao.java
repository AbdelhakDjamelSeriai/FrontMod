package main.java.lirmm.angularGenerator.dao;


public interface GwtDao {
	
	public void saveGwtWidgets();
}
