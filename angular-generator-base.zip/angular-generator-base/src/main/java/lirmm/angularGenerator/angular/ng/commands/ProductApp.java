package main.java.lirmm.angularGenerator.angular.ng.commands;

public class ProductApp {

}
