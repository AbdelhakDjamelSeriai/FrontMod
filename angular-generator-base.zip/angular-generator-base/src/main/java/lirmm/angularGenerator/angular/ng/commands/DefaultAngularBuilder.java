package main.java.lirmm.angularGenerator.angular.ng.commands;

public class DefaultAngularBuilder implements AngularBuilder{

	@Override
	public void prepareRootComponent() {
		
		
	}

	@Override
	public void createAppRoutingModule() {
		
		
	}

	@Override
	public void registerAppModuleModuleRouting() {
		
		
	}

	@Override
	public void createModule(String moduleName) {
		
		
	}

	@Override
	public void createComponent(String componentName) {
		
		
	}
	
	@Override
	public void activateLazyLoading() {
		
		
	}
	

}
