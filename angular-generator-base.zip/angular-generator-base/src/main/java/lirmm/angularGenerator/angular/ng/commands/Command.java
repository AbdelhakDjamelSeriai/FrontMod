package main.java.lirmm.angularGenerator.angular.ng.commands;

abstract public class Command {
	
	/**
	 * The name and signature of the console command.
	 */
	protected String signature;
	
	/**
	 * The console command name.
	 */
	protected String name;
	
	/**
	 * The path
	 */
	protected String path;
	
	/**
	 * 
	 */
	abstract public void run();
	
	/**
	 * 
	 */ 
	
	protected String projectPath;
	
	
	protected String componentSpace;
	 
	
	
	


}
