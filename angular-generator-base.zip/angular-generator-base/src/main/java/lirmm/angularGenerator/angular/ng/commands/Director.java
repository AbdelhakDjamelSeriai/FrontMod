package main.java.lirmm.angularGenerator.angular.ng.commands;


import java.io.File;
import java.io.FileWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;




public class Director {
	
	/**
	 * this function will prepare the angular env , 
	 * 
	 * flush the content of App component 
	 * 
	 * Page --> Module
	 * 
	 * Widget --> Componenet 
	 */
	
	
	
	private AngularConfigurations configs;
	
	
	
	public Director(AngularConfigurations config) {
		configs = config;
	}
	
	
	public void make(JSONArray pages) {
		
		//
		preparRootComponent();
		
		
		for (int i = 0; i < pages.size(); i++) {
			
			System.out.println("----------create a module----------");
			
			JSONObject page = (JSONObject)pages.get(i);
			
			String pageName = ((String)page.get("Page")).toLowerCase();
			
			(new ModuleCreator(configs.projectPath, configs.componentSpace, pageName, page)).run();
			
			
			JSONArray widgets = (JSONArray) page.get("Widgets");
			
			for (int j = 0; j < widgets.size(); j++) {
				
				System.out.println("----------create a component----------");
				
				JSONObject widget = (JSONObject) widgets.get(j);
				
				String widgetName = ((String) widget.get("name")).toLowerCase() ;
				
				( new ComponentCreator(configs.projectPath, "templates/" + pageName + "/" + widgetName) ).run();
			}
			
		}
		
		
		// 
		createAppRoutingModule(pages);
		
		//
		registerAppModuleRouting();
	}
	
	
	/**
	 * Add <router-outlet></router-outlet> to super Component
	 * @param  
	 * @return void
	 */
	private void preparRootComponent() {
		
		try {
			FileWriter fileWriter = new FileWriter(new File( configs.componentSpace + "app.component.html"));

			fileWriter.write("<router-outlet></router-outlet>");
			
			fileWriter.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 */
	private void registerAppModuleRouting() {
		try {
			FileWriter fileWriter = new FileWriter(new File( configs.componentSpace + "app.module.ts"));
			
			fileWriter.flush();
			
			String content = "import { BrowserModule } from '@angular/platform-browser';\r\n"
					+ "import { NgModule } from '@angular/core';\r\n"
					+ "\r\n"
					+ "import { AppComponent } from './app.component';\r\n"
					+ "import { AppRoutingModule } from './app-routing.module';\r\n"
					+ "\r\n"
					+ "\r\n"
					+ "@NgModule({\r\n"
					+ "  declarations: [\r\n"
					+ "    AppComponent\r\n"
					+ "  ],\r\n"
					+ "  imports: [\r\n"
					+ "    BrowserModule,\r\n"
					+ "    AppRoutingModule,\r\n"
					+ "  ],\r\n"
					+ "  providers: [],\r\n"
					+ "  bootstrap: [AppComponent]\r\n"
					+ "})\r\n"
					+ "export class AppModule { }\r\n"
					+ "";
			
			fileWriter.write(content);
			
			fileWriter.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Create a root Module for Module 
	 * @param pages
	 */
	private void createAppRoutingModule(JSONArray pages) {
		
		String content = "";
		
		System.out.println("----------------------------------create a App Routing Component----------------------------------");
		
		try {
			
			FileWriter fileWriter = new FileWriter(new File( configs.componentSpace + "app-routing.module.ts"));
			
			fileWriter.flush();
			
			
			/*for (Page page : pages) {
				
				// pageRoute.getFrom().getName().substring(0, 1).toUpperCase() + pageRoute.getFrom().getName().substring(1);
				
				for (Route pageRoute: page.getRoutes()) {
					
					if(pageRoute.getName() != null) {
						content += "  {path: '"+pageRoute.getToken()+"', loadChildren: () => import('./"+pageRoute.getTo().getName().toLowerCase()+"/"
								+pageRoute.getTo().getName().toLowerCase()+
								".module').then(mod => mod."+pageRoute.getTo().getName().substring(0, 1).toUpperCase() + pageRoute.getTo().getName().substring(1).toLowerCase()+"Module)},\r\n";
						
					}

				}
			
			}*/
			
			content = "import {NgModule} from '@angular/core';\r\n"
					+ "import {RouterModule, Routes} from '@angular/router';\r\n"
					+ "\r\n"
					+ "const routes: Routes = [\r\n"
					+ content
					+ "];\r\n"
					+ "\r\n"
					+ "@NgModule({\r\n"
					+ "  imports: [RouterModule.forRoot(\r\n"
					+ "    routes,\r\n"
					+ "    {enableTracing: true} // <-- debugging purposes only\r\n"
					+ "  )],\r\n"
					+ "  exports: [RouterModule]\r\n"
					+ "})\r\n"
					+ "export class AppRoutingModule {"
					+ "   //\r\n"
					+ "}";
			
			fileWriter.write(content);
			
			fileWriter.close();
			
		} catch (Exception e) {

		}
	}
	
	
}
