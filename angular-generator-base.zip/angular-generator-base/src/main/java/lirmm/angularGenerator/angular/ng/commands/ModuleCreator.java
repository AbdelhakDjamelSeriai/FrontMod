package main.java.lirmm.angularGenerator.angular.ng.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import org.json.simple.JSONObject;


public class ModuleCreator extends Command {
	
	
	//private Page page;
	
	private JSONObject page;
	
	/**
	 * Constructor of Module Creator
	 * @param modulePath
	 */
	public ModuleCreator(String projectPath, String componentSpace, String modulePath, JSONObject page) {
		
		this.name = "generate module";
		
		//this.signature = "ng g m {modulePath}";

		signature = "ng g m ";
		
		this.path = modulePath;
		
		this.page = page;
		
		this.projectPath = projectPath;
		
		this.componentSpace = componentSpace;
		
	}
	
	@Override
	public void run() {
		
		String command = this.signature + "templates" + "/" + path + " --routing";
		
		ProcessBuilder builder = new ProcessBuilder();
		
		if (System.getProperty("os.name").contains("Windows")) {
			
			builder.command("cmd.exe","/c",command);

		
		} else {
			
			builder.command("bash","-c",command);
		
		}


		builder = builder.directory( new File(super.projectPath) );
		

		try {
			
			Process p = builder.start();
			
			BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	        
	        String line;
	        
	        while (true) {
	        	
	            line = r.readLine();
	            
	            if (line == null) { break; }
	            
	            System.out.println(line);
	            
	        }
	        
	        // create a root component !
	        (new ComponentCreator(projectPath, "templates/" + path)).run();
	        
	        // why this update ???
	        // Update the Routing of Module 
	        updatePageRoutingModule();
	        
	        // 
	       changeRootComponentTempalte();
	        
	        //
	        updatePageModule();
	        
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
	}
	 
	
	private void updatePageModule() throws IOException {
		

		Path path = Paths.get(componentSpace + "templates"+ "\\" + this.path + "\\" + this.path + ".module.ts");
		
		List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		
		int offset = lines.stream().filter( e -> e.contains("import {")).collect(Collectors.toList()).size() ;
		
		
		for (String line : lines) {
			if (line.contains("import {")) {
				lines.set(offset + 1, "import { GwtLibModule } from \"../../../../projects/gwt-lib/src/lib/gwt-lib.module\";");
				break;
			}
		}
		
		for (int l = 0; l < lines.size(); l++ ) {
			if (lines.get(l).contains("imports: [")) {
				lines.add(l+2, lines.get(l+2) + ",");
				lines.set(l+3, "    GwtLibModule");
			}
		}
		
	
		
		
	    Files.write(path, lines, StandardCharsets.UTF_8);
	
	}

	/**
	 * Apply root element in root component !!!!!!!!!!
	 */
	private void changeRootComponentTempalte() {
		
		try {
			
			String path = componentSpace + "templates"+ "\\" + this.path + "\\" + this.path + ".component.html";
			
			System.err.println(path);
			
			FileWriter fileWriter = new FileWriter(path);
			
			String rootWidget = ((String) page.get("elementRoot")).toLowerCase();
			
			String appTemplate = "<app-"+rootWidget+"></app-"+rootWidget+">";
			
			fileWriter.write(appTemplate);
			
			fileWriter.close();
			
			System.err.println(appTemplate);
		
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
		
	}
	
	/**
	 * valid operation
	 */
	private void updatePageRoutingModule() {
		try {
			
			String pageName = ((String) page.get("Page")).toLowerCase();
			
			Path path = Paths.get(componentSpace + "templates"+ "\\" + this.path + "\\" + this.path + "-routing.module.ts");
			
			List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
			
		
			String importComponents = "import { "+pageName.substring(0, 1).toUpperCase() + 
					pageName.substring(1).toLowerCase()+"Component} " +"from './" + pageName.toLowerCase() + ".component';\r\n";
			
			
			
			System.out.println(importComponents);
			
			
			String arrayContent = "  {path: '', component: "+ pageName.substring(0, 1).toUpperCase() 
					+ pageName.substring(1).toLowerCase() +"Component },\r\n";
			

		
			String routes = "const routes: Routes = [\r\n" + arrayContent + "];\r\n";

			
			lines.set(3, routes);
			
			lines.set(2, importComponents);
			
			
			
		    Files.write(path, lines, StandardCharsets.UTF_8);
			
		} catch (Exception e) {
			
		}
		
		
	}

}
