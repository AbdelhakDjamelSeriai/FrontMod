package main.java.lirmm.angularGenerator.angular.ng.commands;

public interface AngularBuilder {
	
	//
	public void prepareRootComponent();
	
	//
	public void createAppRoutingModule();
	
	//
	public void registerAppModuleModuleRouting();
	
	// create a module
	public void createModule(String moduleName);
	
	// create a component
	public void createComponent(String componentName);
	
	//
	public void activateLazyLoading();

}
