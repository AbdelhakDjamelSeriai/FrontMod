package main.java.lirmm.angularGenerator.angular;

public class ServiceCreator {

}
