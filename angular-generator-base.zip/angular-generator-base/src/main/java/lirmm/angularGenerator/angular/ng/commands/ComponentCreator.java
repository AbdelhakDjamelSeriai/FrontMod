package main.java.lirmm.angularGenerator.angular.ng.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class ComponentCreator extends Command{
	
	
	
	/**
	 * Component Creator 
	 * @param componentPath
	 */
	public ComponentCreator(String projectPath, String componentPath) {
		
		this.name = "generate component";
		
		this.signature = "ng g c ";
		
		this.path = componentPath;
		
		this.projectPath = projectPath;
		
	}
	
	
	
	@Override
	public void run() {
		
		String command = this.signature + this.path;
		
		ProcessBuilder builder = new ProcessBuilder();
		
		if (System.getProperty("os.name").contains("Windows")) {
			
			builder.command("cmd.exe","/c",command);

		
		} else {
			
			builder.command("bash","-c",command);
		
		}
		
		builder = builder.directory(new File(projectPath));
		
		try {
			
			Process p = builder.start();
			
	        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	        
	        String line;
	        
	        while (true) {
	        	
	            line = r.readLine();
	            
	            if (line == null) { break; }
	            
	            System.out.println(line);
	            
	        }
	        
	        
		} catch (Exception e) {
			
			System.err.println(e.getMessage());
		}
	}
	
	

}
