package main.java.lirmm.angularGenerator.angular.ng.commands;

import org.json.simple.JSONArray;

public class AngularDirector {
	
	
	private AngularBuilder angularBuilder;
	
	
	public AngularDirector(AngularBuilder angularBuilder) {
		this.angularBuilder = angularBuilder;
	}
	
	
	public void changeBuilder(AngularBuilder angularBuilder) {
		this.angularBuilder = angularBuilder;
	}

	
	public void make(JSONArray pages) {
		
	}
}
