package main.java.lirmm.angularGenerator.angular.ng.commands;

public class AngularConfigurations {
	
	// you should change the workspace path 
	public String workspacePath = "C:\\Users\\gm_be\\PhpstormProjects\\" ;
		
	// the name of the repository locally in you machine, can change this name
	public String projectName = "template-project-angular" ; 
		
	// calculated projectPath
	public String projectPath = workspacePath + projectName ; 
		
	// component workspace in Angular app
	public String componentSpace = projectPath + "\\src\\app\\";
		
	// you should the application Name
	public String applicationName = "stockwatcher";
		
	// where i should generate module and components 
	public String templateSpace = "templates";
		
	// not used actually
	public String applicationSpace = applicationName + "\\" +templateSpace;
	

}
