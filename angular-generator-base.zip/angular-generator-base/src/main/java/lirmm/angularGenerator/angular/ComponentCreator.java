package main.java.lirmm.angularGenerator.angular;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import kdm.code.gwt.Widget;

public class ComponentCreator {

	
	private String widgetName;
	
	private String componentPath;
		
	/**
	 * 
	 */
	public ComponentCreator(String modulePath,Widget widget) {
		
		widgetName = widget.getName().toLowerCase();
				
		componentPath = modulePath + "/" + widgetName ;

	}
	
	/**
	 * 
	 */
	public void createComponent() {
		
		File moduleDir = new File(componentPath);
		if (!moduleDir.exists()){
		    moduleDir.mkdirs();
		}
		
		createScss();
		createHtml();
		createTs();

	}
	
	private void createScss() {
		BufferedWriter output = null;
		try { 
		
			 output = new BufferedWriter(new FileWriter(componentPath+ "/"+widgetName+".component.scss"));
			 output.close();
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void createHtml() {
		BufferedWriter output = null;
		try { 
			 
			 output = new BufferedWriter(new FileWriter(componentPath+ "/"+widgetName+".component.html"));
			 output.write("<p>"+widgetName+" works!</p>");   
	         output.close();
	         
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void createTs() {
		BufferedWriter output = null;
		try { 
			 output = new BufferedWriter(new FileWriter(componentPath+ "/"+widgetName+".component.ts"));
			 output.write("import { Component, OnInit } from '@angular/core';\n"
	            		+ "\n"
	            		+ "@Component({\n"
	            		+ "  selector: 'app-"+widgetName+"',\n"
	            		+ "  templateUrl: './"+widgetName+".component.html',\n"
	            		+ "  styleUrls: ['./"+widgetName+".component.scss']\n"
	            		+ "})\n"
	            		+ "export class "+toProperCase(widgetName)+"Component implements OnInit {\n"
	            		+ "\n"
	            		+ "  constructor() { }\n"
	            		+ "\n"
	            		+ "  ngOnInit(): void {\n"
	            		+ "  }\n"
	            		+ "\n"
	            		+ "}\n"
	            		+ "\n"
	            		+ "\n"
	            		+ "");
			 output.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private String toProperCase(String s) {
	    return s.substring(0, 1).toUpperCase() +
	               s.substring(1).toLowerCase();
	}

	/**
	 * 
	 */
	public void updateComponent() {
		
	}

}
