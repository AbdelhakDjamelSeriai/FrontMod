package main.java.lirmm.angularGenerator.angular;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;

import kdm.code.gwt.Page;
import kdm.code.gwt.Widget;
import main.java.lirmm.angularGenerator.gwt.PagesExtractor;
import main.java.lirmm.angularGenerator.gwt.WidgetsExtractor;


public class ModuleCreator {
	
	private Page page;
	
	private String pageName;
	
	private String modulePath;
	
	private String moduleName;
	
	
	public ModuleCreator(Page page) {
		
		this.page = page;
		
		pageName = page.getName().toLowerCase();
		
		modulePath = "src/resources/" + pageName ;
		
		moduleName = pageName + ".module.ts";
		
	}
	
	public void createModule() {
		
		BufferedWriter output = null;
		
		
		try {
			// create module directory 
			File moduleDir = new File(modulePath);
			if (!moduleDir.exists()){
			    moduleDir.mkdirs();
			}
			
		    // add content of directory 
		    output = new BufferedWriter(new FileWriter(modulePath+ "/"+moduleName));
            output.write("import { NgModule } from '@angular/core';\n"
            		+ "import { CommonModule } from '@angular/common';\n"
            		+ "\n"
            		+ "\n"
            		+ "\n"
            		+ "@NgModule({\n"
            		+ " declarations: [],\n"
            		+ " imports: [\n"
            		+ "   CommonModule\n"
            		+ " ]\n"
            		+ "})\n"
            		+ "export class "+toProperCase(pageName)+"Module { }");
           
            
            output.close();
		    
            createRootComponent();
            
            createComponenets();
		    
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	private String toProperCase(String s) {
	    return s.substring(0, 1).toUpperCase() +
	               s.substring(1).toLowerCase();
	}
	
	private void createScss() {
		BufferedWriter output = null;
		try { 
		
			 output = new BufferedWriter(new FileWriter(modulePath+ "/"+pageName+".component.scss"));
			 output.close();
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void createHtml() {
		BufferedWriter output = null;
		try { 
			 
			 output = new BufferedWriter(new FileWriter(modulePath+ "/"+pageName+".component.html"));
			 output.write("<p>"+pageName+" works!</p>");   
	         output.close();
	         
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void createTs() {
		BufferedWriter output = null;
		try { 
			 output = new BufferedWriter(new FileWriter(modulePath+ "/"+pageName+".component.ts"));
			 output.write("import { Component, OnInit } from '@angular/core';\n"
	            		+ "\n"
	            		+ "@Component({\n"
	            		+ "  selector: 'app-"+pageName+"',\n"
	            		+ "  templateUrl: './"+pageName+".component.html',\n"
	            		+ "  styleUrls: ['./"+pageName+".component.scss']\n"
	            		+ "})\n"
	            		+ "export class "+toProperCase(pageName)+"Component implements OnInit {\n"
	            		+ "\n"
	            		+ "  constructor() { }\n"
	            		+ "\n"
	            		+ "  ngOnInit(): void {\n"
	            		+ "  }\n"
	            		+ "\n"
	            		+ "}\n"
	            		+ "\n"
	            		+ "\n"
	            		+ "");
			 output.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void createRootComponent() {
		createScss();
		createHtml();
		createTs();
		updateContentModule();
	}
	
	private void createComponenets(){
		for (Widget widget : page.getWidgets()) {
			
			(new ComponentCreator(modulePath,widget)).createComponent();
		
		}
	}
	
    public  void updateContentModule() {
		
	

	}

    private void addString() {
    	
    }
}
