package main.java.lirmm.angularGenerator.gwt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

import kdm.action.ActionElement;
import kdm.action.Calls;
import kdm.code.AbstractCodeElement;
import kdm.code.CodeItem;
import kdm.code.MethodUnit;
import kdm.code.Value;
import kdm.code.gwt.Widget;
import main.java.lirmm.angularGenerator.dao.Attribute;

public class AttributesExtractor {
	
	
	private AttributesExtractor(){
		
	}
	
	
	private static AttributesExtractor uniqueInstance;
	
 	
	public static AttributesExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new AttributesExtractor();
		}
		return uniqueInstance;
	}
	
	/**
	 * get the actionElement codeElement of widget when actionElement Name equals "expression statement" else get the actionElement
	 * @param widget
	 * @return
	 */
	public EList<ActionElement> getAttributesOfWidget(Widget widget) {
		EList<ActionElement> methodInvocations = new BasicEList<ActionElement>();
		for (AbstractCodeElement abstractCodeElement : widget.getActions()) {
			   if (((ActionElement)abstractCodeElement).getName().equals("expression statement")) {
				   methodInvocations.addAll((EList<ActionElement>)(EList<?>)((ActionElement)abstractCodeElement).getCodeElement());
			   } else {
				   methodInvocations.add(((ActionElement)abstractCodeElement));
			   }
			   
		}
		return methodInvocations;
	}
	
	/***
	 * From MethodInvocation get The method and it's arguments
	 * this's for expression statement and other but not for "variable declaration" and "class instance creation"
	 * @param actionElement
	 * @return
	 */
	public List<CodeItem> getAttributesFromMethodInvocation(ActionElement actionElement) {
		
		List<CodeItem> codeItems = new ArrayList<CodeItem>();
	    if (!((actionElement.getName().toString().equals("variable declaration")) /*|| 
	    		((actionElement.getName().toString().equals("class instance creation") ))*/)) {
		  
	    	if (actionElement.getActionRelation().size() > 0 && actionElement.getActionRelation().get(0) instanceof Calls ) {
				//strings.add(((Calls)actionElement.getActionRelation().get(0)).getTo().getName());
	    		codeItems.add(((Calls)actionElement.getActionRelation().get(0)).getTo());
		   }
			for (AbstractCodeElement abstractCodeElement: actionElement.getCodeElement()) {
				/*if (abstractCodeElement instanceof ActionElement) {
					//strings.add( ((Calls)actionElement.getActionRelation().get(0)).getTo().getName() );
					
					codeItems.addAll(getAttributesFromMethodInvocation((ActionElement)abstractCodeElement));
				}*/
				/*else*/ if (abstractCodeElement instanceof kdm.code.Value) {
					//System.out.print( + " ");
					//strings.add(((kdm.code.Value)abstractCodeElement).getExt());
					codeItems.add(((kdm.code.Value)abstractCodeElement));
				}
				/*if (abstractCodeElement instanceof ActionElement) {
					//strings.add( ((Calls)actionElement.getActionRelation().get(0)).getTo().getName() );
					
					strings.addAll(showAttribut((ActionElement)abstractCodeElement));
				}*/
			}
			
			if ((actionElement.getCodeElement().size()>0) &&(actionElement.getCodeElement().get(0) instanceof ActionElement) 
					//)//&&( !((ActionElement)actionElement.getCodeElement().get(0)).getName().toString().equals("class instance creation") )
					) {
				//strings.add( ((Calls)actionElement.getActionRelation().get(0)).getTo().getName() );
				
				codeItems.addAll(getAttributesFromMethodInvocation((ActionElement)actionElement.getCodeElement().get(0)));
			}
			
			
	   } 
		
		return codeItems;
	}
	
	
	/**
	 * 
	 * @param codeItems
	 * @return
	 */
	public List<Attribute> createAttributesFromCodeItems(List<CodeItem> codeItems) {
		List<Attribute> methods = new ArrayList<Attribute>();
		
		
	//	List<String> tmps = new ArrayList<String>();
		for (int i = 0; i < codeItems.size();i++) {
			
			if (codeItems.get(i) instanceof MethodUnit) {
				int j = /*i-1*/i+1;
			
				Attribute method = new Attribute();
				List<String> args = new ArrayList<String>();
				method.setName(((MethodUnit)codeItems.get(i)).getName());
				boolean check = false;
				
				while (!(check)&&(j < codeItems.size())/*&&(j != -1)*/) { /*j < i*/
					
					if (/*(j+1 < codeItems.size())&&*/(codeItems.get(j) instanceof MethodUnit )) {
						check = true;
					}
					if (codeItems.get(j) instanceof Value) {
						args.add(((Value)codeItems.get(j)).getExt());
					}
					//j--;
					j++;
				}	
				//Collections.reverse(args);				
				method.setArgs(args);				

				methods.add(method);
				//tmps.removeAll(args);
			}
			
			

	}
		//Collections.reverse(methods);
		// link attributes
		return linkedAttributes(methods);//methods;

	}
	
	
	
	private List<Attribute> linkedAttributes(List<Attribute> attributes) {
		
		if (attributes.size()>0) {
			for(int j = 0; j < attributes.size(); j++) {
					
				if (j+1<attributes.size()) {
					attributes.get(j).setAttribute(attributes.get(j+1));
				} 
			}
			attributes.get(attributes.size()-1).setAttribute(null);
		}
		
		return attributes;
	}
}
