package main.java.lirmm.angularGenerator.gwt;

import org.eclipse.emf.common.util.EList;

import kdm.code.gwt.Page;
import kdm.code.gwt.Route;


public class RoutesExtractor {
	/**
	 * Constructor of the class RoutesExtractor. 
	 * Its visibility is private in order not to allow the other classes to create many instances of RoutesExtractor
	 */
	private RoutesExtractor(){
		
	}
	
	/**
	 * unique instance of RoutesExtractor.
	 */
	private static RoutesExtractor uniqueInstance;
	
	/**
	 *Method insuring that a unique instance of MethodUnitsExtractor is created.
	 * @return uniqueInstance
	 */
	public static RoutesExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new RoutesExtractor();
		}
		return uniqueInstance;
	}
	
	public EList<Route> getWidgetsFromPage(Page page) {
		return page.getRoutes();
	}
}
