package main.java.lirmm.angularGenerator.gwt;

import org.eclipse.emf.common.util.EList;

import kdm.code.gwt.GwtModel;
import kdm.code.gwt.Page;

public class PagesExtractor {
	
	/**
	 * Constructor of the class MethodUnitsExtractor. 
	 * Its visibility is private in order not to allow the other classes to create many instances of MethodUnitsExtractor
	 */
	private PagesExtractor(){
		
	}
	
	/**
	 * unique instance of MethodUnitsExtractor.
	 */
	private static PagesExtractor uniqueInstance;
	
	/**
	 *Method insuring that a unique instance of MethodUnitsExtractor is created.
	 * @return uniqueInstance
	 */
	public static PagesExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new PagesExtractor();
		}
		return uniqueInstance;
	}
	
	public EList<Page> getPagesFromGwtModel(GwtModel gwtModel) {
		return gwtModel.getPages();
	}
}
