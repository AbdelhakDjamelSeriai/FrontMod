package main.java.lirmm.angularGenerator.gwt;

import org.eclipse.emf.common.util.EList;

import kdm.code.gwt.Page;
import kdm.code.gwt.Widget;

public class WidgetsExtractor {
	/**
	 * Constructor of the class MethodUnitsExtractor. 
	 * Its visibility is private in order not to allow the other classes to create many instances of MethodUnitsExtractor
	 */
	private WidgetsExtractor(){
		
	}
	
	/**
	 * unique instance of MethodUnitsExtractor.
	 */
	private static WidgetsExtractor uniqueInstance;
	
	/**
	 *Method insuring that a unique instance of MethodUnitsExtractor is created.
	 * @return uniqueInstance
	 */
	public static WidgetsExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new WidgetsExtractor();
		}
		return uniqueInstance;
	}
	
	public EList<Widget> getWidgetsFromPage(Page page) {
		return page.getWidgets();
	}
	
}
