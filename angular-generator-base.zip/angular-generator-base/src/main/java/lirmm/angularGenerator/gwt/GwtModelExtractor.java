package main.java.lirmm.angularGenerator.gwt;

import kdm.code.gwt.GwtModel;
import kdm.kdm.Segment;

public class GwtModelExtractor {
	
	/**
	 * Constructor of the class MethodUnitsExtractor. 
	 * Its visibility is private in order not to allow the other classes to create many instances of MethodUnitsExtractor
	 */
	private GwtModelExtractor(){
		
	}
	
	/**
	 * unique instance of MethodUnitsExtractor.
	 */
	private static GwtModelExtractor uniqueInstance;
	
	/**
	 *Method insuring that a unique instance of MethodUnitsExtractor is created.
	 * @return uniqueInstance
	 */
	public static GwtModelExtractor getInstance(){
		if(uniqueInstance == null){
			uniqueInstance = new GwtModelExtractor();
		}
		return uniqueInstance;
	}
	
	public GwtModel getGwtModelFromSegment(Segment segment) {
		//System.out.println(" ----> " + segment.getName());
		return (GwtModel)segment.getModel().get(0);
	}
	
	
}
