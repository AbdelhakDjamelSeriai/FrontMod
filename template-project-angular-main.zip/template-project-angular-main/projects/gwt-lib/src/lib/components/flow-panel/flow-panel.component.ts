import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-flow-panel',
  templateUrl: './flow-panel.component.html',
  styleUrls: ['./flow-panel.component.css']
})
export class FlowPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
