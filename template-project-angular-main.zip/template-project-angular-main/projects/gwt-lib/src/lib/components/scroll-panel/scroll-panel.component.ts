import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-scroll-panel',
  templateUrl: './scroll-panel.component.html',
  styleUrls: ['./scroll-panel.component.css']
})
export class ScrollPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
