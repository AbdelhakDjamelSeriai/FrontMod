import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HorizantalSplitPanelComponent } from './horizantal-split-panel.component';

describe('HorizantalSplitPanelComponent', () => {
  let component: HorizantalSplitPanelComponent;
  let fixture: ComponentFixture<HorizantalSplitPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HorizantalSplitPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HorizantalSplitPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
