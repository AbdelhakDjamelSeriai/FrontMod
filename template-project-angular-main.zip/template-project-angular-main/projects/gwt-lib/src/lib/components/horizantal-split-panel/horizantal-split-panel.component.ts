import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-horizantal-split-panel',
  templateUrl: './horizantal-split-panel.component.html',
  styleUrls: ['./horizantal-split-panel.component.css']
})
export class HorizantalSplitPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
