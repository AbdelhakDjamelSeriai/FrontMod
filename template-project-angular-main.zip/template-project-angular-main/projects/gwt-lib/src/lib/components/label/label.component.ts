import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-label',
  templateUrl: './label.component.html',
  styleUrls: ['./label.component.css']
})
export class LabelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
