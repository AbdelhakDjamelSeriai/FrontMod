import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeckLayoutPanelComponent } from './deck-layout-panel.component';

describe('DeckLayoutPanelComponent', () => {
  let component: DeckLayoutPanelComponent;
  let fixture: ComponentFixture<DeckLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeckLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeckLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
