import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-deck-layout-panel',
  templateUrl: './deck-layout-panel.component.html',
  styleUrls: ['./deck-layout-panel.component.css']
})
export class DeckLayoutPanelComponent implements OnInit {

  constructor() { }

  isShow1 = false;
  isShow2 = false;
  isShow3 = false;

  ngOnInit(): void {
  }

  // tslint:disable-next-line:typedef
  addClickHandlerButton1(id: string) {
    if ('Button1' === id) {
      this.isShow1 = true;
      this.isShow3 = false;
      this.isShow2 = false;
    }
  }

  // tslint:disable-next-line:typedef
  addClickHandlerButton2(id: string) {
    if ('Button2' === id) {
      this.isShow1 = false;
      this.isShow2 = true;
      this.isShow3 = false;
    }
  }

  // tslint:disable-next-line:typedef
  addClickHandlerButton3(id: string) {
    if ('Button3' === id) {
      this.isShow1 = false;
      this.isShow2 = false;
      this.isShow3 = true;
    }
  }
}
