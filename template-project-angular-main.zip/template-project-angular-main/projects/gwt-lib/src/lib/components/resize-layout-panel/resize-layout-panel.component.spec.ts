import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResizeLayoutPanelComponent } from './resize-layout-panel.component';

describe('ResizeLayoutPanelComponent', () => {
  let component: ResizeLayoutPanelComponent;
  let fixture: ComponentFixture<ResizeLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResizeLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResizeLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
