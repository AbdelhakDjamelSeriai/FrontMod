import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-resize-layout-panel',
  templateUrl: './resize-layout-panel.component.html',
  styleUrls: ['./resize-layout-panel.component.css']
})
export class ResizeLayoutPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
