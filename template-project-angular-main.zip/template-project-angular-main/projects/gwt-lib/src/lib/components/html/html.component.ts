import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-html',
  templateUrl: './html.component.html',
  styleUrls: ['./html.component.css']
})
export class HTMLComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
