import {Component, Input, OnInit} from '@angular/core';
import {ThemePalette} from '@angular/material/core';

@Component({
  selector: 'lirmm-radio-button',
  templateUrl: './radio-button.component.html',
  styleUrls: ['./radio-button.component.css']
})
export class RadioButtonComponent implements OnInit {

  dataSelected: string = '';
  items: string[] = ['a', 'b', 'c', 'd'];

  /**
   *    !! Radio Group !!
   *
   */

  // Theme color for all of the radio buttons in the group.
  @Input() radioGroupColor: ThemePalette;

  // Whether the radio group is disabled
  @Input() radioGroupDisabled: boolean = false;

  // Whether the labels should appear after or before the radio-buttons. Defaults to 'after'
  @Input() radioGroupLabelPosition: 'before' | 'after' = 'after';

  // Name of the radio button group. All radio buttons inside this group will use this name.
  @Input() radioGroupName: string = '';

  // Whether the radio group is required
  @Input() radioGroupRequired: boolean = false;

  // The currently selected radio button. If set to a new radio button, the radio group value will be updated to match the new selected button.
  @Input() radioGroupSelected: any;

  // Value for the radio-group. Should equal the value of the selected radio button if there is a corresponding radio button with a matching value. If there is not such a corresponding radio button, this value persists to be applied in case a new radio button is added with a matching value.
  @Input() radioGroupValue: any;


  /**
   *  !! Radio Button !!
   *
   */


  // The 'aria-describedby' attribute is read after the element's label and field type.
  @Input() radioButtonAriaDescribedby: string = '';

  // Used to set the 'aria-label' attribute on the underlying input element.
  @Input() radioButtonAriaLabel: string = '';

  // The 'aria-labelledby' attribute takes precedence as the element's text alternative.
  @Input() radioButtonAriaLabelledby: string = '';

  // Whether this radio button is checked.
  @Input() radioButtonChecked: boolean = false;

  // Theme color of the radio button.
  @Input() radioButtonColor: ThemePalette;

  // Whether ripples are disabled.
  @Input() radioButtonDisableRipple: boolean = false;

  // Whether the radio button is disabled.
  @Input() radioButtonDisabled: boolean = false;

  // The unique ID for the radio button.
  @Input() radioButtonId: string = '';

  // Whether the label should appear after or before the radio button. Defaults to 'after'
  @Input() radioButtonLabelPosition: 'before' | 'after' = 'after';

  // Analog to HTML 'name' attribute used to group radios for unique selection.
  @Input() radioButtonName: string = '';

  // Whether the radio button is required.
  @Input() radioButtonRequired: boolean = false;

  // The value of this radio button.
  @Input() radioButtonValue: any;

















  constructor() { }

  ngOnInit(): void {
  }

}
