import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FocusPanelComponent } from './focus-panel.component';

describe('FocusPanelComponent', () => {
  let component: FocusPanelComponent;
  let fixture: ComponentFixture<FocusPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FocusPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FocusPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
