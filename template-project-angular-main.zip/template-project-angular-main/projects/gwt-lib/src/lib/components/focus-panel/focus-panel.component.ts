import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-focus-panel',
  templateUrl: './focus-panel.component.html',
  styleUrls: ['./focus-panel.component.css']
})
export class FocusPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
