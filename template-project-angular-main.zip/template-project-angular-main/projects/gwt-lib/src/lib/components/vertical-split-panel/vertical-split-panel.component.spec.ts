import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerticalSplitPanelComponent } from './vertical-split-panel.component';

describe('VerticalSplitPanelComponent', () => {
  let component: VerticalSplitPanelComponent;
  let fixture: ComponentFixture<VerticalSplitPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerticalSplitPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VerticalSplitPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
