import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-vertical-split-panel',
  templateUrl: './vertical-split-panel.component.html',
  styleUrls: ['./vertical-split-panel.component.css']
})
export class VerticalSplitPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
