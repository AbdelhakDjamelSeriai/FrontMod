import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-root-panel',
  templateUrl: './root-panel.component.html',
  styleUrls: ['./root-panel.component.css']
})
export class RootPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
