import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-date-label',
  templateUrl: './date-label.component.html',
  styleUrls: ['./date-label.component.css']
})
export class DateLabelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
