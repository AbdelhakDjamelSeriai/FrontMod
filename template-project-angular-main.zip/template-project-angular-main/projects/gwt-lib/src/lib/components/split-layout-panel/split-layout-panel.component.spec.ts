import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SplitLayoutPanelComponent } from './split-layout-panel.component';

describe('SplitLayoutPanelComponent', () => {
  let component: SplitLayoutPanelComponent;
  let fixture: ComponentFixture<SplitLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SplitLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SplitLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
