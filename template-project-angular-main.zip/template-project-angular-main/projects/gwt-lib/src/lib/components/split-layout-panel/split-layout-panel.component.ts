import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-split-layout-panel',
  templateUrl: './split-layout-panel.component.html',
  styleUrls: ['./split-layout-panel.component.css']
})
export class SplitLayoutPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
