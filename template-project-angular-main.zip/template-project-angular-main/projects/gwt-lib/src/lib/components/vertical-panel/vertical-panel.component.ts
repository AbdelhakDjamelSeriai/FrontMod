import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-vertical-panel',
  templateUrl: './vertical-panel.component.html',
  styleUrls: ['./vertical-panel.component.css']
})
export class VerticalPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
