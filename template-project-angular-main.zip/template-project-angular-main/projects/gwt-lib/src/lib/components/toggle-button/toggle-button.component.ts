import {Component, Input, OnInit} from '@angular/core';
import {MatButtonToggleAppearance} from '@angular/material/button-toggle';

@Component({
  selector: 'lirmm-toggle-button',
  templateUrl: './toggle-button.component.html',
  styleUrls: ['./toggle-button.component.css']
})
export class ToggleButtonComponent implements OnInit {

  // Users can specify the aria-labelledby attribute which will be forwarded to the input element . string | null
  @Input() toggleAriaLabelledby: any;

  // Attached to the aria-label attribute of the host element. In most cases, aria-labelledby will take precedence so this may be omitted. string
  @Input() toggleAriaLabel: any;

  // Whether the button is checked. boolean
  @Input() toggleChecked: any;

  // Whether ripples are disabled. boolean
  @Input() toggleDisableRipple: any;

  // Whether the button is disabled. boolean
  @Input() toggleDisabled: any;

  // The unique ID for this button toggle. string
  @Input() toggleId: any;

  // HTML's 'name' attribute used to group radios for unique selection. string
  @Input() toggleName: any;

  // MatButtonToggleGroup reads this to assign its own value.
  @Input() toggleValue: any;




  constructor() {

  }

  ngOnInit(): void {
  }

}
