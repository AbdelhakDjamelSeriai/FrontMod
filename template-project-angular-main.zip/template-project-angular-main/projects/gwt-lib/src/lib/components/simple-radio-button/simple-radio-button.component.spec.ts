import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleRadioButtonComponent } from './simple-radio-button.component';

describe('SimpleRadioButtonComponent', () => {
  let component: SimpleRadioButtonComponent;
  let fixture: ComponentFixture<SimpleRadioButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SimpleRadioButtonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleRadioButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
