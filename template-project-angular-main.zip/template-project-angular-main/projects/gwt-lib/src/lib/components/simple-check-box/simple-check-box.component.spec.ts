import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleCheckBoxComponent } from './simple-check-box.component';

describe('SimpleCheckBoxComponent', () => {
  let component: SimpleCheckBoxComponent;
  let fixture: ComponentFixture<SimpleCheckBoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SimpleCheckBoxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleCheckBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
