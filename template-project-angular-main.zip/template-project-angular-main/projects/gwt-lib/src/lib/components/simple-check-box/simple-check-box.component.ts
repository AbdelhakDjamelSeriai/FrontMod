import {Component, Input, OnInit} from '@angular/core';
import {ThemePalette} from '@angular/material/core';

@Component({
  selector: 'lirmm-simple-check-box',
  templateUrl: './simple-check-box.component.html',
  styleUrls: ['./simple-check-box.component.css']
})
export class SimpleCheckBoxComponent implements OnInit {

  // The 'aria-describedby' attribute is read after the element's label and field type.
  @Input() checkBoxAriaDescribedby: string = '';

  // Attached to the aria-label attribute of the host element. In most cases, aria-labelledby will take precedence so this may be omitted.
  @Input() checkBoxAriaLabel: string = '';

  // Users can specify the aria-labelledby attribute which will be forwarded to the input element
  @Input() checkBoxAriaLabelledby: string | null = '';

  // Whether the checkbox is checked.
  @Input() checkBoxChecked: boolean = false;

  // Theme color palette for the component.
  @Input() checkBoxColor: ThemePalette;

  // Whether ripples are disabled.
  @Input() checkBoxDisableRipple: boolean = false;

  // Whether the checkbox is disabled. This fully overrides the implementation provided by mixinDisabled, but the mixin is still required because mixinTabIndex requires it.
  @Input() checkBoxDisabled: any;

  // A unique id for the checkbox input. If none is supplied, it will be auto-generated.
  @Input() checkBoxId: string = '';

  // Whether the checkbox is indeterminate. This is also known as "mixed" mode and can be used to represent a checkbox with three states, e.g. a checkbox that represents a nested list of checkable items. Note that whenever checkbox is manually clicked, indeterminate is immediately set to false.
  @Input() checkBoxIndeterminate: boolean = false;

  // Whether the label should appear after or before the checkbox. Defaults to 'after'
  @Input() checkBoxLabelPosition: 'before' | 'after' = 'after';

  // Name value will be applied to the input element if present
  @Input() checkBoxName: string | null = '';

  // Whether the checkbox is required.
  @Input() checkBoxRequired: boolean = false;

  // The value attribute of the native input element
  @Input() checkBoxValue: string = '';

  constructor() { }

  ngOnInit(): void {
  }

}
