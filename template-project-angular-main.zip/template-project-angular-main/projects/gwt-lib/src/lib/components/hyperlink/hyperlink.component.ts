import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'lirmm-hyperlink',
  templateUrl: './hyperlink.component.html',
  styleUrls: ['./hyperlink.component.css']
})
export class HyperlinkComponent implements OnInit {

  //string
  @Input() hrefAnchor: any;

  constructor() { }

  ngOnInit(): void {
  }

}
