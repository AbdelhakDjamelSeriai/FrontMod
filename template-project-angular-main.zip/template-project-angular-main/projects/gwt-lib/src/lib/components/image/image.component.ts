import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'lirmm-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {

   // src for Image : string
   @Input() imageSrc: null;

  constructor() { }

  ngOnInit(): void {
  }

}
