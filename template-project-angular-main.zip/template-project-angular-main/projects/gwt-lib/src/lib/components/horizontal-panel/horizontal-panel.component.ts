import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-horizontal-panel',
  templateUrl: './horizontal-panel.component.html',
  styleUrls: ['./horizontal-panel.component.css']
})
export class HorizontalPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
