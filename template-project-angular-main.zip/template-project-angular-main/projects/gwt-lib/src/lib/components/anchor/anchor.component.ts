import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'lirmm-anchor',
  templateUrl: './anchor.component.html',
  styleUrls: ['./anchor.component.css']
})
export class AnchorComponent implements OnInit {

  // string
  @Input() hrefAnchor: any;

  constructor() { }

  ngOnInit(): void {
  }

}
