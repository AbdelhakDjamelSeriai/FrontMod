import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RootLayoutPanelComponent } from './root-layout-panel.component';

describe('RootLayoutPanelComponent', () => {
  let component: RootLayoutPanelComponent;
  let fixture: ComponentFixture<RootLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RootLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RootLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
