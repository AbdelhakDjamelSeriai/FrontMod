import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-root-layout-panel',
  templateUrl: './root-layout-panel.component.html',
  styleUrls: ['./root-layout-panel.component.css']
})
export class RootLayoutPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
