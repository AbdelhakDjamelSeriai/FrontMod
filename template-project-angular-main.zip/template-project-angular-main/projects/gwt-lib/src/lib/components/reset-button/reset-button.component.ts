import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'lirmm-reset-button',
  templateUrl: './reset-button.component.html',
  styleUrls: ['./reset-button.component.css']
})
export class ResetButtonComponent implements OnInit {
// input to choose the button type
  @Input() btnTypeChecked = '' ;

  // input to choose the color type
  @Input() clrTypeChecked = '' ;

  // Whether the component is disabled.
  @Input() btnDisabled = false ;

  // Whether the button is round.
  @Input() btnIsRoundButton = false ;

  // Whether the button is icon button.
  @Input() btnIsIconButton = false ;

  // Whether ripples are disabled.
  @Input() btnDisableRipple = false;

  // button types
  btnArrayTypes: string[] = ['mat-raised-button', 'mat-icon-button', 'mat-fab', 'mat-mini-fab', 'mat-mini-fab', 'mat-stroked-button', 'mat-flat-button', 'mat-button'];

  // array of colors
  clrArrayTypes: string[] = ['accent', 'warn', 'primary'];

  constructor() { }

  ngOnInit(): void {
  }

  // return button type choiced
  buttonTypes() {

    let check = false;
    let index = 0;
    while (!check && index < this.btnArrayTypes.length) {
      // tslint:disable-next-line:triple-equals
      if (this.btnTypeChecked == this.btnArrayTypes[index]) {
        check = true;
      }
      index++;
    }

    return this.btnArrayTypes[index - 1];

  }

  // return type color
  colorChoices() {

    let check = false;
    let index = 0;
    while (!check && index < this.clrArrayTypes.length) {

      if (this.clrTypeChecked == this.clrArrayTypes[index]) {
        check = true;
      }
      index++;
    }

    return this.clrArrayTypes[index - 1];
  }

}
