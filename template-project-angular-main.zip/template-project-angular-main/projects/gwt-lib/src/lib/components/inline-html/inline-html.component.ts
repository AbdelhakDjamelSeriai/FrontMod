import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-inline-html',
  templateUrl: './inline-html.component.html',
  styleUrls: ['./inline-html.component.css']
})
export class InlineHTMLComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
