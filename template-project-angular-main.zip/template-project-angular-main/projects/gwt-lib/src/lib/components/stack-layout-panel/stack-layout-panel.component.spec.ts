import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StackLayoutPanelComponent } from './stack-layout-panel.component';

describe('StackLayoutPanelComponent', () => {
  let component: StackLayoutPanelComponent;
  let fixture: ComponentFixture<StackLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StackLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StackLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
