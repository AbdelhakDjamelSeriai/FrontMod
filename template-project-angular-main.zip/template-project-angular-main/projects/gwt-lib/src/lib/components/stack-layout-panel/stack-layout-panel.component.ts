import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-stack-layout-panel',
  templateUrl: './stack-layout-panel.component.html',
  styleUrls: ['./stack-layout-panel.component.css']
})
export class StackLayoutPanelComponent implements OnInit {
  panelOpenState = false;

  constructor() { }

  ngOnInit(): void {
  }

}
