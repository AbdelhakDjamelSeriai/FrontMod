import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-dock-panel',
  templateUrl: './dock-panel.component.html',
  styleUrls: ['./dock-panel.component.css']
})
export class DockPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
