import {Component, Input, OnInit} from '@angular/core';




const ELEMENT_DATA = [ {} ];

@Component({
  selector: 'lirmm-flex-table',
  templateUrl: './flex-table.component.html',
  styleUrls: ['./flex-table.component.css']
})
export class FlexTableComponent implements OnInit {

  @Input() displayedColumns: string[] = [];

  dataSource = ELEMENT_DATA;


  constructor() { }

  ngOnInit(): void {
  }

}
