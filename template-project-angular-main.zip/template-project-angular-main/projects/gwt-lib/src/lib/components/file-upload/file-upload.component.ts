import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  fileToUpload : File | null = null;
  fileUploadQueue3: any;


  constructor() { }

  ngOnInit(): void {
  }

  handleFileInput (files: FileList) {
    this.fileToUpload = files.item(0);
  }

}
