import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-custom-scroll-panel',
  templateUrl: './custom-scroll-panel.component.html',
  styleUrls: ['./custom-scroll-panel.component.css']
})
export class CustomScrollPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
