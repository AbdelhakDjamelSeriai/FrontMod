import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomScrollPanelComponent } from './custom-scroll-panel.component';

describe('CustomScrollPanelComponent', () => {
  let component: CustomScrollPanelComponent;
  let fixture: ComponentFixture<CustomScrollPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomScrollPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomScrollPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
