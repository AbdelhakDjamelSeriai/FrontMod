import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-deck-panel',
  templateUrl: './deck-panel.component.html',
  styleUrls: ['./deck-panel.component.css']
})
export class DeckPanelComponent implements OnInit {
  isShow1 = false;
  isShow2 = false;
  isShow3 = false;

  constructor() { }

  ngOnInit(): void {
  }

  // tslint:disable-next-line:typedef
  addClickHandlerButton1(id: string) {
    if ('Button1' === id) {
      this.isShow1 = true;
      this.isShow3 = false;
      this.isShow2 = false;
    }
  }

  // tslint:disable-next-line:typedef
  addClickHandlerButton2(id: string) {
    if ('Button2' === id) {
      this.isShow1 = false;
      this.isShow2 = true;
      this.isShow3 = false;
    }
  }

  // tslint:disable-next-line:typedef
  addClickHandlerButton3(id: string) {
    if ('Button3' === id) {
      this.isShow1 = false;
      this.isShow2 = false;
      this.isShow3 = true;
    }
  }
}
