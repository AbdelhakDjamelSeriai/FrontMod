import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-form-panel',
  templateUrl: './form-panel.component.html',
  styleUrls: ['./form-panel.component.css']
})
export class FormPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
