import {Component, Input, OnInit} from '@angular/core';
import {ErrorStateMatcher} from '@angular/material/core';

@Component({
  selector: 'lirmm-text-box',
  templateUrl: './text-box.component.html',
  styleUrls: ['./text-box.component.css']
})
export class TextBoxComponent implements OnInit {

  // An object used to control when error messages are shown .ErrorStateMatcher
  @Input() textBoxErrorStateMatcher: any;

  // Whether the element is readonly .
  @Input() textBoxReadonly: boolean = false;

  // Input type of the element .
  //@Input() textBoxType: string;

  // max Length
  @Input() maxLength: number = 0;

  // --label
  // @Input() labelText: string;

  constructor() { }

  ngOnInit(): void {
  }

}
