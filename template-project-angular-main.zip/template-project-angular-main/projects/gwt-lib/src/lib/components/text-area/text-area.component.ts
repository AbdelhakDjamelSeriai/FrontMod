import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'lirmm-text-area',
  templateUrl: './text-area.component.html',
  styleUrls: ['./text-area.component.css']
})
export class TextAreaComponent implements OnInit {

  // Whether autosizing is enabled or not 'cdkTextareaAutosize'
  @Input() textAreaEnabled: boolean = false;

  // 'mat-autosize'
  @Input() textAreaMatAutosize: boolean = false;

  //
  @Input() textAreaMatAutosizeMaxRows: number = 0;

  //
  @Input() textAreaMatAutosizeMinRows: number = 0;

  //
  @Input() textAreaMatTextAreaAutosize: boolean = false;

  // Maximum amount of rows in the textarea. 'cdkAutosizeMaxRows'
  @Input() textAreaMaxRows: number = 0;

  // Minimum amount of rows in the textarea. 'cdkAutosizeMinRows'
  @Input() textAreaMinRows: number = 0;

  //
  @Input() textAreaPlaceholder: string = '';

  constructor() { }

  ngOnInit(): void {
  }

}
