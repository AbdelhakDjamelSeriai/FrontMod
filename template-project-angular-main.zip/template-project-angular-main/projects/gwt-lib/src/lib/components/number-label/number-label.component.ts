import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-number-label',
  templateUrl: './number-label.component.html',
  styleUrls: ['./number-label.component.css']
})
export class NumberLabelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
