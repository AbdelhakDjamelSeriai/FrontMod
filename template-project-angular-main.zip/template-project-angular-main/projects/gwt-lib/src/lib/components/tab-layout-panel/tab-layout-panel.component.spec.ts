import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabLayoutPanelComponent } from './tab-layout-panel.component';

describe('TabLayoutPanelComponent', () => {
  let component: TabLayoutPanelComponent;
  let fixture: ComponentFixture<TabLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
