import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-tab-layout-panel',
  templateUrl: './tab-layout-panel.component.html',
  styleUrls: ['./tab-layout-panel.component.css']
})
export class TabLayoutPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
