import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.css']
})
export class TreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
