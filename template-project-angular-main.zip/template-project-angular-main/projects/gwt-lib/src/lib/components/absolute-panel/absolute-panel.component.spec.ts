import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbsolutePanelComponent } from './absolute-panel.component';

describe('AbsolutePanelComponent', () => {
  let component: AbsolutePanelComponent;
  let fixture: ComponentFixture<AbsolutePanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbsolutePanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AbsolutePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
