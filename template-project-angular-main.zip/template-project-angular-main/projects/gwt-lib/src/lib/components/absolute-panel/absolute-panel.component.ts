import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-absolute-panel',
  templateUrl: './absolute-panel.component.html',
  styleUrls: ['./absolute-panel.component.css']
})
export class AbsolutePanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
