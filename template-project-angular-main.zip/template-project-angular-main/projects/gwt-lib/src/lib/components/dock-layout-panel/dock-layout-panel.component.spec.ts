import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DockLayoutPanelComponent } from './dock-layout-panel.component';

describe('DockLayoutPanelComponent', () => {
  let component: DockLayoutPanelComponent;
  let fixture: ComponentFixture<DockLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DockLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DockLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
