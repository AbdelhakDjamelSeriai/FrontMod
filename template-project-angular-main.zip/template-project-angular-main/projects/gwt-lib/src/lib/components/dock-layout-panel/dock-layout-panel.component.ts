import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-dock-layout-panel',
  templateUrl: './dock-layout-panel.component.html',
  styleUrls: ['./dock-layout-panel.component.css']
})
export class DockLayoutPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
