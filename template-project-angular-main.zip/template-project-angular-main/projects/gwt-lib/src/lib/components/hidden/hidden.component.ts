import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-hidden',
  templateUrl: './hidden.component.html',
  styleUrls: ['./hidden.component.css']
})
export class HiddenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
