import {Component, Input, OnInit} from '@angular/core';
import {ThemePalette} from '@angular/material/core';

@Component({
  selector: 'lirmm-check-box',
  templateUrl: './check-box.component.html',
  styleUrls: ['./check-box.component.css']
})
export class CheckBoxComponent implements OnInit {

  // The 'aria-describedby' attribute is read after the element's label and field type. string
  @Input() checkBoxAriaDescribedby: any;

  // Attached to the aria-label attribute of the host element. In most cases, aria-labelledby will take precedence so this may be omitted. string
  @Input() checkBoxAriaLabel: any;

  // Users can specify the aria-labelledby attribute which will be forwarded to the input element string | null
  @Input() checkBoxAriaLabelledby: any;

  // Whether the checkbox is checked. boolean
  @Input() checkBoxChecked: any;

  // Theme color palette for the component. ThemePalette
  @Input() checkBoxColor: ThemePalette;

  // Whether ripples are disabled. boolean
  @Input() checkBoxDisableRipple: any;

  // Whether the checkbox is disabled. This fully overrides the implementation provided by mixinDisabled, but the mixin is still required because mixinTabIndex requires it. any
  @Input() checkBoxDisabled: any;

  // A unique id for the checkbox input. If none is supplied, it will be auto-generated. string
  @Input() checkBoxId: any;

  // Whether the checkbox is indeterminate. This is also known as "mixed" mode and can be used to represent a checkbox with three states,
  // e.g. a checkbox that represents a nested list of checkable items. Note that whenever checkbox is manually clicked,
  // indeterminate is immediately set to false. boolean
  @Input() checkBoxIndeterminate: any;

  // Whether the label should appear after or before the checkbox. Defaults to 'after' ,    'before' | 'after'
  @Input() checkBoxLabelPosition: any;

  // Name value will be applied to the input element if present , string | null
  @Input() checkBoxName: any;

  // Whether the checkbox is required. , boolean
  @Input() checkBoxRequired: any;

  // The value attribute of the native input element , string
  @Input() checkBoxValue: any;


  constructor() { }

  ngOnInit(): void {
  }

}
