import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-inline-label',
  templateUrl: './inline-label.component.html',
  styleUrls: ['./inline-label.component.css']
})
export class InlineLabelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
