import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InlineLabelComponent } from './inline-label.component';

describe('InlineLabelComponent', () => {
  let component: InlineLabelComponent;
  let fixture: ComponentFixture<InlineLabelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InlineLabelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InlineLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
