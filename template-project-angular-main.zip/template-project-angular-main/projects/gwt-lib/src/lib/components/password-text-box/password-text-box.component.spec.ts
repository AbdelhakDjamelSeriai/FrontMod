import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordTextBoxComponent } from './password-text-box.component';

describe('PasswordTextBoxComponent', () => {
  let component: PasswordTextBoxComponent;
  let fixture: ComponentFixture<PasswordTextBoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PasswordTextBoxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordTextBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
