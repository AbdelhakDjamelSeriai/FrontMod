import {Component, Input, OnInit} from '@angular/core';
import {ErrorStateMatcher} from '@angular/material/core';

@Component({
  selector: 'lirmm-password-text-box',
  templateUrl: './password-text-box.component.html',
  styleUrls: ['./password-text-box.component.css']
})
export class PasswordTextBoxComponent implements OnInit {

  // An object used to control when error messages are shown . ErrorStateMatcher
  @Input() textPasswordErrorStateMatcher:  any;

  // Whether the element is readonly . boolean
  @Input() textPasswordReadonly: any;

  // Input type of the element .
  //@Input() textBoxType: string;

  // max Length
  @Input() maxLength: number = 100;


  constructor() { }

  ngOnInit(): void {
  }

}
