import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DecoratedStackPanelComponent } from './decorated-stack-panel.component';

describe('DecoratedStackPanelComponent', () => {
  let component: DecoratedStackPanelComponent;
  let fixture: ComponentFixture<DecoratedStackPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DecoratedStackPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DecoratedStackPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
