import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-decorated-stack-panel',
  templateUrl: './decorated-stack-panel.component.html',
  styleUrls: ['./decorated-stack-panel.component.css']
})
export class DecoratedStackPanelComponent implements OnInit {
  panelOpenState = false;

  constructor() { }

  ngOnInit(): void {
  }

}
