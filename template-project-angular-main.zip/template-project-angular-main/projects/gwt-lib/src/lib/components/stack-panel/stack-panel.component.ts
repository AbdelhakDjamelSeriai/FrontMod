import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-stack-panel',
  templateUrl: './stack-panel.component.html',
  styleUrls: ['./stack-panel.component.css']
})
export class StackPanelComponent implements OnInit {
  panelOpenState = false;

  constructor() { }

  ngOnInit(): void {
  }

}
