import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-canvas',
  templateUrl: './canvas.component.html',
  styleUrls: ['./canvas.component.css']
})
export class CanvasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
