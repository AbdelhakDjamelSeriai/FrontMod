import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-html-panel',
  templateUrl: './html-panel.component.html',
  styleUrls: ['./html-panel.component.css']
})
export class HtmlPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
