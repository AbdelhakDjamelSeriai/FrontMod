import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtmlPanelComponent } from './html-panel.component';

describe('HtmlPanelComponent', () => {
  let component: HtmlPanelComponent;
  let fixture: ComponentFixture<HtmlPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HtmlPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HtmlPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
