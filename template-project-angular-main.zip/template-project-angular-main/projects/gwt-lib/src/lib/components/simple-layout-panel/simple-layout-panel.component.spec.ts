import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleLayoutPanelComponent } from './simple-layout-panel.component';

describe('SimpleLayoutPanelComponent', () => {
  let component: SimpleLayoutPanelComponent;
  let fixture: ComponentFixture<SimpleLayoutPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SimpleLayoutPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleLayoutPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
