import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-simple-layout-panel',
  templateUrl: './simple-layout-panel.component.html',
  styleUrls: ['./simple-layout-panel.component.css']
})
export class SimpleLayoutPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
