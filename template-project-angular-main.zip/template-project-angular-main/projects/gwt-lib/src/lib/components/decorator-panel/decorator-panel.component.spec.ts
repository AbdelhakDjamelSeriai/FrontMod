import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DecoratorPanelComponent } from './decorator-panel.component';

describe('DecoratorPanelComponent', () => {
  let component: DecoratorPanelComponent;
  let fixture: ComponentFixture<DecoratorPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DecoratorPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DecoratorPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
