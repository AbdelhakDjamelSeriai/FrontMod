import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-decorator-panel',
  templateUrl: './decorator-panel.component.html',
  styleUrls: ['./decorator-panel.component.css']
})
export class DecoratorPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
