import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lirmm-rich-text-area',
  templateUrl: './rich-text-area.component.html',
  styleUrls: ['./rich-text-area.component.css']
})
export class RichTextAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
