import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { DialogboxComponent} from "./components/dialog-box/dialog-box.component";
import {LabelComponent} from "./components/label/label.component";
import {HorizontalPanelComponent} from "./components/horizontal-panel/horizontal-panel.component";
import {VerticalPanelComponent} from "./components/vertical-panel/vertical-panel.component";
import {FlowPanelComponent} from "./components/flow-panel/flow-panel.component";
import {DeckPanelComponent} from "./components/deck-panel/deck-panel.component";
import {DockLayoutPanelComponent} from "./components/dock-layout-panel/dock-layout-panel.component";
import {SplitLayoutPanelComponent} from "./components/split-layout-panel/split-layout-panel.component";
import {HorizantalSplitPanelComponent} from "./components/horizantal-split-panel/horizantal-split-panel.component";
import {VerticalSplitPanelComponent} from "./components/vertical-split-panel/vertical-split-panel.component";
import {RootLayoutPanelComponent} from "./components/root-layout-panel/root-layout-panel.component";
import {DockPanelComponent} from "./components/dock-panel/dock-panel.component";
import {StackPanelComponent} from "./components/stack-panel/stack-panel.component";
import {DecoratedStackPanelComponent} from "./components/decorated-stack-panel/decorated-stack-panel.component";
import {StackLayoutPanelComponent} from "./components/stack-layout-panel/stack-layout-panel.component";
import {DeckLayoutPanelComponent} from "./components/deck-layout-panel/deck-layout-panel.component";
import {AbsolutePanelComponent} from "./components/absolute-panel/absolute-panel.component";
import {RootPanelComponent} from "./components/root-panel/root-panel.component";
import {HtmlPanelComponent} from "./components/html-panel/html-panel.component";
import {FlexTableComponent} from "./components/flex-table/flex-table.component";
import {GridComponent} from "./components/grid/grid.component";
import {ResizeLayoutPanelComponent} from "./components/resize-layout-panel/resize-layout-panel.component";
import {SimpleLayoutPanelComponent} from "./components/simple-layout-panel/simple-layout-panel.component";
import {FocusPanelComponent} from "./components/focus-panel/focus-panel.component";
import {ScrollPanelComponent} from "./components/scroll-panel/scroll-panel.component";
import {CustomScrollPanelComponent} from "./components/custom-scroll-panel/custom-scroll-panel.component";
import {DecoratorPanelComponent} from "./components/decorator-panel/decorator-panel.component";
import {TabLayoutPanelComponent} from "./components/tab-layout-panel/tab-layout-panel.component";
import {MenuBarComponent} from "./components/menu-bar/menu-bar.component";
import {FrameComponent} from "./components/frame/frame.component";
import {HiddenComponent} from "./components/hidden/hidden.component";
import {HyperlinkComponent} from "./components/hyperlink/hyperlink.component";
import {ImageComponent} from "./components/image/image.component";
import {TreeComponent} from "./components/tree/tree.component";
import {FileUploadComponent} from "./components/file-upload/file-upload.component";
import {CanvasComponent} from "./components/canvas/canvas.component";
import {ListBoxComponent} from "./components/list-box/list-box.component";
import {AnchorComponent} from "./components/anchor/anchor.component";
import {SimpleRadioButtonComponent} from "./components/simple-radio-button/simple-radio-button.component";
import {SimpleCheckBoxComponent} from "./components/simple-check-box/simple-check-box.component";
import {RichTextAreaComponent} from "./components/rich-text-area/rich-text-area.component";
import {PasswordTextBoxComponent} from "./components/password-text-box/password-text-box.component";
import {TextBoxComponent} from "./components/text-box/text-box.component";
import {TextAreaComponent} from "./components/text-area/text-area.component";
import {RadioButtonComponent} from "./components/radio-button/radio-button.component";
import {CheckBoxComponent} from "./components/check-box/check-box.component";
import {PushButtonComponent} from "./components/push-button/push-button.component";
import {ToggleButtonComponent} from "./components/toggle-button/toggle-button.component";
import {CustomButtonComponent} from "./components/custom-button/custom-button.component";
import {SubmitButtonComponent} from "./components/submit-button/submit-button.component";
import {ResetButtonComponent} from "./components/reset-button/reset-button.component";
import {ButtonComponent} from "./components/button/button.component";
import {NumberLabelComponent} from "./components/number-label/number-label.component";
import {DateLabelComponent} from "./components/date-label/date-label.component";
import {InlineLabelComponent} from "./components/inline-label/inline-label.component";
import {InlineHTMLComponent} from "./components/inline-html/inline-html.component";
import {HTMLComponent} from "./components/html/html.component";
import {FormPanelComponent} from "./components/form-panel/form-panel.component";
//import {BrowserModule} from "@angular/platform-browser";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {MatTabsModule} from "@angular/material/tabs";
import {MatExpansionModule} from "@angular/material/expansion";
import {MatGridListModule} from "@angular/material/grid-list";
import {MatInputModule} from "@angular/material/input";
import {MatButtonModule} from "@angular/material/button";
import {MatRippleModule} from "@angular/material/core";
import {MatButtonToggleModule} from "@angular/material/button-toggle";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {MatRadioModule} from "@angular/material/radio";
import {FormsModule} from "@angular/forms";
import {MatCardModule} from "@angular/material/card";
import {MatSelectModule} from "@angular/material/select";
import {MatMenuModule} from "@angular/material/menu";
import {MatTableModule} from "@angular/material/table";



@NgModule({
  declarations: [
    LabelComponent,
    HorizontalPanelComponent,
    VerticalPanelComponent,
    FlowPanelComponent,
    DeckPanelComponent,
    DockLayoutPanelComponent,
    SplitLayoutPanelComponent,
    HorizantalSplitPanelComponent,
    VerticalSplitPanelComponent,
    RootLayoutPanelComponent,
    DockPanelComponent,
    StackPanelComponent,
    DecoratedStackPanelComponent,
    StackLayoutPanelComponent,
    DeckLayoutPanelComponent,
    AbsolutePanelComponent,
    RootPanelComponent,
    HtmlPanelComponent,
    FlexTableComponent,
    GridComponent,
    ResizeLayoutPanelComponent,
    SimpleLayoutPanelComponent,
    FocusPanelComponent,
    ScrollPanelComponent,
    CustomScrollPanelComponent,
    DecoratorPanelComponent,
    TabLayoutPanelComponent,
    MenuBarComponent,
    FrameComponent,
    HiddenComponent,
    HyperlinkComponent,
    ImageComponent,
    TreeComponent,
    FileUploadComponent,
    CanvasComponent,
    ListBoxComponent,
    AnchorComponent,
    SimpleRadioButtonComponent,
    SimpleCheckBoxComponent,
    RichTextAreaComponent,
    PasswordTextBoxComponent,
    TextBoxComponent,
    TextAreaComponent,
    RadioButtonComponent,
    CheckBoxComponent,
    PushButtonComponent,
    ToggleButtonComponent,
    CustomButtonComponent,
    SubmitButtonComponent,
    ResetButtonComponent,
    ButtonComponent,
    NumberLabelComponent,
    DateLabelComponent,
    InlineLabelComponent,
    InlineHTMLComponent,
    HTMLComponent,
    FormPanelComponent,
    DialogboxComponent
  ],
  imports: [
    CommonModule,
    //BrowserModule,
    //BrowserAnimationsModule,
    MatTabsModule,
    MatExpansionModule,
    MatGridListModule,
    MatInputModule,
    MatButtonModule,
    MatRippleModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatRadioModule,
    FormsModule,
    MatCardModule,
    MatSelectModule,
    MatMenuModule,
    MatTableModule,
  ],
  exports: [
    LabelComponent,
    HorizontalPanelComponent,
    VerticalPanelComponent,
    FlowPanelComponent,
    DeckPanelComponent,
    DockLayoutPanelComponent,
    SplitLayoutPanelComponent,
    HorizantalSplitPanelComponent,
    VerticalSplitPanelComponent,
    RootLayoutPanelComponent,
    DockPanelComponent,
    StackPanelComponent,
    DecoratedStackPanelComponent,
    StackLayoutPanelComponent,
    DeckLayoutPanelComponent,
    AbsolutePanelComponent,
    RootPanelComponent,
    HtmlPanelComponent,
    FlexTableComponent,
    GridComponent,
    ResizeLayoutPanelComponent,
    SimpleLayoutPanelComponent,
    FocusPanelComponent,
    ScrollPanelComponent,
    CustomScrollPanelComponent,
    DecoratorPanelComponent,
    TabLayoutPanelComponent,
    MenuBarComponent,
    FrameComponent,
    HiddenComponent,
    HyperlinkComponent,
    ImageComponent,
    TreeComponent,
    FileUploadComponent,
    CanvasComponent,
    ListBoxComponent,
    AnchorComponent,
    SimpleRadioButtonComponent,
    SimpleCheckBoxComponent,
    RichTextAreaComponent,
    PasswordTextBoxComponent,
    TextBoxComponent,
    TextAreaComponent,
    RadioButtonComponent,
    CheckBoxComponent,
    PushButtonComponent,
    ToggleButtonComponent,
    CustomButtonComponent,
    SubmitButtonComponent,
    ResetButtonComponent,
    ButtonComponent,
    NumberLabelComponent,
    DateLabelComponent,
    InlineLabelComponent,
    InlineHTMLComponent,
    HTMLComponent,
    FormPanelComponent,
    DialogboxComponent
  ]
})
export class GwtLibModule { }
