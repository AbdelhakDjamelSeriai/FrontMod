import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GwtLibComponent } from './gwt-lib.component';

describe('GwtLibComponent', () => {
  let component: GwtLibComponent;
  let fixture: ComponentFixture<GwtLibComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GwtLibComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GwtLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
