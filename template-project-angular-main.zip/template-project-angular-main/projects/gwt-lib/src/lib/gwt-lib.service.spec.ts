import { TestBed } from '@angular/core/testing';

import { GwtLibService } from './gwt-lib.service';

describe('GwtLibService', () => {
  let service: GwtLibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GwtLibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
