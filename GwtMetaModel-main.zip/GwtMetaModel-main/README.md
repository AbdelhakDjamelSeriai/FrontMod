# GWTMetaModel 

this repo contains the metamodel of GWT that extends from KDM metamodel .


## Prerequisites

- Java Execution Env 1.8  


## Usage

- make pull to this repo.


- Change JRE System Library to JavaSE-1.8 , for more detail :
	
	See `Window->preferences->java->Installed` JREs and make sure that the checked JRE is `1.8`.

	 
