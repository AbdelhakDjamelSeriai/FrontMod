/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Block Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getBlockUnit()
 * @model
 * @generated
 */
public interface BlockUnit extends ActionElement {
} // BlockUnit
