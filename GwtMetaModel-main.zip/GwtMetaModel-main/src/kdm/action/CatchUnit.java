/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Catch Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getCatchUnit()
 * @model
 * @generated
 */
public interface CatchUnit extends ExceptionUnit {
} // CatchUnit
