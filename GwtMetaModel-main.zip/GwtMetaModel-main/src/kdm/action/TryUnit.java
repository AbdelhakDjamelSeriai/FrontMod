/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Try Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getTryUnit()
 * @model
 * @generated
 */
public interface TryUnit extends ExceptionUnit {
} // TryUnit
