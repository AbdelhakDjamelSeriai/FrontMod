/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.BlockUnit;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Block Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BlockUnitImpl extends ActionElementImpl implements BlockUnit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BlockUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.BLOCK_UNIT;
	}

} //BlockUnitImpl
