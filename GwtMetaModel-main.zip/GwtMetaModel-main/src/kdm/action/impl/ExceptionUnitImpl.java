/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.ExceptionUnit;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Exception Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ExceptionUnitImpl extends BlockUnitImpl implements ExceptionUnit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExceptionUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.EXCEPTION_UNIT;
	}

} //ExceptionUnitImpl
