/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.TrueFlow;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>True Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TrueFlowImpl extends ControlFlowImpl implements TrueFlow {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TrueFlowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.TRUE_FLOW;
	}

} //TrueFlowImpl
