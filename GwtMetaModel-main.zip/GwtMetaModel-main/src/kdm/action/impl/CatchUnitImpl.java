/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.CatchUnit;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Catch Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CatchUnitImpl extends ExceptionUnitImpl implements CatchUnit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CatchUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.CATCH_UNIT;
	}

} //CatchUnitImpl
