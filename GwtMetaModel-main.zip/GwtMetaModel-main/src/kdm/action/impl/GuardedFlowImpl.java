/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.GuardedFlow;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Guarded Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GuardedFlowImpl extends ControlFlowImpl implements GuardedFlow {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GuardedFlowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.GUARDED_FLOW;
	}

} //GuardedFlowImpl
