/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.FinallyUnit;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Finally Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FinallyUnitImpl extends ExceptionUnitImpl implements FinallyUnit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FinallyUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.FINALLY_UNIT;
	}

} //FinallyUnitImpl
