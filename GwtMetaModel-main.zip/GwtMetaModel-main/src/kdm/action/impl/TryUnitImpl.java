/**
 */
package kdm.action.impl;

import kdm.action.ActionPackage;
import kdm.action.TryUnit;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Try Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TryUnitImpl extends ExceptionUnitImpl implements TryUnit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TryUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActionPackage.Literals.TRY_UNIT;
	}

} //TryUnitImpl
