/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Guarded Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getGuardedFlow()
 * @model
 * @generated
 */
public interface GuardedFlow extends ControlFlow {
} // GuardedFlow
