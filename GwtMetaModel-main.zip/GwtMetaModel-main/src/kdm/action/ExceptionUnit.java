/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Exception Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getExceptionUnit()
 * @model
 * @generated
 */
public interface ExceptionUnit extends BlockUnit {
} // ExceptionUnit
