/**
 */
package kdm.action;

import kdm.core.KDMRelationship;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Action Relationship</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getAbstractActionRelationship()
 * @model abstract="true"
 * @generated
 */
public interface AbstractActionRelationship extends KDMRelationship {
} // AbstractActionRelationship
