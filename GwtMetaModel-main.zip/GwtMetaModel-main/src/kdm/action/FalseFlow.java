/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>False Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getFalseFlow()
 * @model
 * @generated
 */
public interface FalseFlow extends ControlFlow {
} // FalseFlow
