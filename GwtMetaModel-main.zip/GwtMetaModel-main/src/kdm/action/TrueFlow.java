/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>True Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getTrueFlow()
 * @model
 * @generated
 */
public interface TrueFlow extends ControlFlow {
} // TrueFlow
