/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Finally Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getFinallyUnit()
 * @model
 * @generated
 */
public interface FinallyUnit extends ExceptionUnit {
} // FinallyUnit
