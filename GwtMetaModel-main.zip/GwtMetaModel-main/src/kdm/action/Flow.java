/**
 */
package kdm.action;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.action.ActionPackage#getFlow()
 * @model
 * @generated
 */
public interface Flow extends ControlFlow {
} // Flow
