/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ordinal Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getOrdinalType()
 * @model
 * @generated
 */
public interface OrdinalType extends PrimitiveType {
} // OrdinalType
