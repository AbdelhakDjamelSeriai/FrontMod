/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Octet Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getOctetType()
 * @model
 * @generated
 */
public interface OctetType extends PrimitiveType {
} // OctetType
