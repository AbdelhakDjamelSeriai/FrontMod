/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Macro Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.MacroUnit#getKind <em>Kind</em>}</li>
 * </ul>
 *
 * @see kdm.code.CodePackage#getMacroUnit()
 * @model
 * @generated
 */
public interface MacroUnit extends PreprocessorDirective {
	/**
	 * Returns the value of the '<em><b>Kind</b></em>' attribute.
	 * The literals are from the enumeration {@link kdm.code.MacroKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kind</em>' attribute.
	 * @see kdm.code.MacroKind
	 * @see #setKind(MacroKind)
	 * @see kdm.code.CodePackage#getMacroUnit_Kind()
	 * @model
	 * @generated
	 */
	MacroKind getKind();

	/**
	 * Sets the value of the '{@link kdm.code.MacroUnit#getKind <em>Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kind</em>' attribute.
	 * @see kdm.code.MacroKind
	 * @see #getKind()
	 * @generated
	 */
	void setKind(MacroKind value);

} // MacroUnit
