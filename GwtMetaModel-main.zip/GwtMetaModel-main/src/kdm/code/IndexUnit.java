/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Index Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getIndexUnit()
 * @model
 * @generated
 */
public interface IndexUnit extends DataElement {
} // IndexUnit
