/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Language Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getLanguageUnit()
 * @model
 * @generated
 */
public interface LanguageUnit extends kdm.code.Module {
} // LanguageUnit
