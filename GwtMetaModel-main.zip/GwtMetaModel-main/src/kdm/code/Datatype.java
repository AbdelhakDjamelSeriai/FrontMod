/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Datatype</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getDatatype()
 * @model
 * @generated
 */
public interface Datatype extends CodeItem {
} // Datatype
