/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Synonym Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getSynonymUnit()
 * @model
 * @generated
 */
public interface SynonymUnit extends DefinedType {
} // SynonymUnit
