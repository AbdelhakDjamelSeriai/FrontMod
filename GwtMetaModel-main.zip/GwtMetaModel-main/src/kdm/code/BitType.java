/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bit Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getBitType()
 * @model
 * @generated
 */
public interface BitType extends PrimitiveType {
} // BitType
