/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Record Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getRecordType()
 * @model
 * @generated
 */
public interface RecordType extends CompositeType {
} // RecordType
