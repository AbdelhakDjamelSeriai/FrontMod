/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bitstring Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getBitstringType()
 * @model
 * @generated
 */
public interface BitstringType extends PrimitiveType {
} // BitstringType
