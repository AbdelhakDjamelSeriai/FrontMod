/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Include Directive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getIncludeDirective()
 * @model
 * @generated
 */
public interface IncludeDirective extends PreprocessorDirective {
} // IncludeDirective
