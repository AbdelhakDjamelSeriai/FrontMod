/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scaled Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getScaledType()
 * @model
 * @generated
 */
public interface ScaledType extends PrimitiveType {
} // ScaledType
