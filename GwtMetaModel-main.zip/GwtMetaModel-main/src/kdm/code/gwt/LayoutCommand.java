/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layout Command</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getLayoutCommand()
 * @model
 * @generated
 */
public interface LayoutCommand extends FocusWidget {
} // LayoutCommand
