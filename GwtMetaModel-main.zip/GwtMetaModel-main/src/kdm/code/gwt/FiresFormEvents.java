/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fires Form Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFiresFormEvents()
 * @model
 * @generated
 */
public interface FiresFormEvents extends InterfaceUnit {
} // FiresFormEvents
