/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Split Layout Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSplitLayoutPanel()
 * @model
 * @generated
 */
public interface SplitLayoutPanel extends DockLayoutPanel {
} // SplitLayoutPanel
