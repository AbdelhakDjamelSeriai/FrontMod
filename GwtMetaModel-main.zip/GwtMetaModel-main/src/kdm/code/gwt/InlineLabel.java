/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Inline Label</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getInlineLabel()
 * @model
 * @generated
 */
public interface InlineLabel extends Label {
} // InlineLabel
