/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scroll Impl</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getScrollImpl()
 * @model
 * @generated
 */
public interface ScrollImpl extends HTML {
} // ScrollImpl
