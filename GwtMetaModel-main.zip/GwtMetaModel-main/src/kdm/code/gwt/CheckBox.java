/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Check Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getCheckBox()
 * @model
 * @generated
 */
public interface CheckBox extends ButtonBase {
} // CheckBox
