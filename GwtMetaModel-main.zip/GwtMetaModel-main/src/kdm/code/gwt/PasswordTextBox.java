/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Password Text Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getPasswordTextBox()
 * @model
 * @generated
 */
public interface PasswordTextBox extends TextBox {
} // PasswordTextBox
