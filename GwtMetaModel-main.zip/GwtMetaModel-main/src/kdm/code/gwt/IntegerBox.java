/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Integer Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getIntegerBox()
 * @model
 * @generated
 */
public interface IntegerBox extends ValueBox {
} // IntegerBox
