/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Disclosure Panel Images RTL</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDisclosurePanelImagesRTL()
 * @model
 * @generated
 */
public interface DisclosurePanelImagesRTL extends InterfaceUnit {
} // DisclosurePanelImagesRTL
