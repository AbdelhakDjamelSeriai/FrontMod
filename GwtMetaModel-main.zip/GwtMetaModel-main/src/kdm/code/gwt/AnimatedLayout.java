/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Animated Layout</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getAnimatedLayout()
 * @model
 * @generated
 */
public interface AnimatedLayout extends InterfaceUnit {
} // AnimatedLayout
