/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Suggest Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSuggestBox()
 * @model
 * @generated
 */
public interface SuggestBox extends Composite {
} // SuggestBox
