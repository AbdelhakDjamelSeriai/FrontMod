/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getValueBox()
 * @model
 * @generated
 */
public interface ValueBox extends ValueBoxBase {
} // ValueBox
