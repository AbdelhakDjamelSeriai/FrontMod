/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hyperlink</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHyperlink()
 * @model
 * @generated
 */
public interface Hyperlink extends Widget {
} // Hyperlink
