/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Change Listener</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getChangeListener()
 * @model
 * @generated
 */
public interface ChangeListener extends InterfaceUnit {
} // ChangeListener
