/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sources Mouse Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSourcesMouseEvents()
 * @model
 * @generated
 */
public interface SourcesMouseEvents extends InterfaceUnit {
} // SourcesMouseEvents
