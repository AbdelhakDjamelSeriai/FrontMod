/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Root Layout Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getRootLayoutPanel()
 * @model
 * @generated
 */
public interface RootLayoutPanel extends LayoutPanel {
} // RootLayoutPanel
