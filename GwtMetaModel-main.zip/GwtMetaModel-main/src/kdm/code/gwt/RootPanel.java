/**
 */
package kdm.code.gwt;

import kdm.code.Imports;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Root Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getRootPanel()
 * @model
 * @generated
 */
public interface RootPanel extends AbsolutePanel, Imports {
} // RootPanel
