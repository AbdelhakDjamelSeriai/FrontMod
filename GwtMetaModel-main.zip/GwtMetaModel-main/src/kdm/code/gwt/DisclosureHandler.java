/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Disclosure Handler</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDisclosureHandler()
 * @model
 * @generated
 */
public interface DisclosureHandler extends InterfaceUnit {
} // DisclosureHandler
