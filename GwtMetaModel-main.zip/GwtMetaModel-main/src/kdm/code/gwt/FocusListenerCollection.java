/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Focus Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFocusListenerCollection()
 * @model
 * @generated
 */
public interface FocusListenerCollection extends FocusListener {
} // FocusListenerCollection
