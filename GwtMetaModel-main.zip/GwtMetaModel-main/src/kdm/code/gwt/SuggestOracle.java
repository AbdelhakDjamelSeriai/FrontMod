/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Suggest Oracle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSuggestOracle()
 * @model
 * @generated
 */
public interface SuggestOracle extends DockLayoutPanel {
} // SuggestOracle
