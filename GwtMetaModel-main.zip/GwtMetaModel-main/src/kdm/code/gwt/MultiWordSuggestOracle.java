/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multi Word Suggest Oracle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMultiWordSuggestOracle()
 * @model
 * @generated
 */
public interface MultiWordSuggestOracle extends SuggestOracle {
} // MultiWordSuggestOracle
