/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Popup Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getPopupListenerCollection()
 * @model
 * @generated
 */
public interface PopupListenerCollection extends PopupListener {
} // PopupListenerCollection
