/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mouse Wheel Velocity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMouseWheelVelocity()
 * @model
 * @generated
 */
public interface MouseWheelVelocity extends CellPanel {
} // MouseWheelVelocity
