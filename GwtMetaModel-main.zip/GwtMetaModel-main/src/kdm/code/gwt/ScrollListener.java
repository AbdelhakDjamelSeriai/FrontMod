/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scroll Listener</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getScrollListener()
 * @model
 * @generated
 */
public interface ScrollListener extends InterfaceUnit {
} // ScrollListener
