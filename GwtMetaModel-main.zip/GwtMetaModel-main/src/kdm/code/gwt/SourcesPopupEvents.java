/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sources Popup Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSourcesPopupEvents()
 * @model
 * @generated
 */
public interface SourcesPopupEvents extends InterfaceUnit {
} // SourcesPopupEvents
