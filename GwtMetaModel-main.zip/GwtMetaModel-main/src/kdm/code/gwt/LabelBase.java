/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Label Base</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getLabelBase()
 * @model
 * @generated
 */
public interface LabelBase extends Widget {
} // LabelBase
