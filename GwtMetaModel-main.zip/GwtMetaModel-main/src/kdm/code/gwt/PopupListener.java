/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Popup Listener</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getPopupListener()
 * @model
 * @generated
 */
public interface PopupListener extends InterfaceUnit {
} // PopupListener
