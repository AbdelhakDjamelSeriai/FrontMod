/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Widget Iterators</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getWidgetIterators()
 * @model
 * @generated
 */
public interface WidgetIterators extends Composite {
} // WidgetIterators
