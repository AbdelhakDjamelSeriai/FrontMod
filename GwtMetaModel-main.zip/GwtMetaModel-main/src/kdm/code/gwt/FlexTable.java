/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Flex Table</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFlexTable()
 * @model
 * @generated
 */
public interface FlexTable extends HTMLTable {
} // FlexTable
