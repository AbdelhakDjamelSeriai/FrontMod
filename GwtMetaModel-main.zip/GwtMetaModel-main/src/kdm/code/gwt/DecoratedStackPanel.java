/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decorated Stack Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDecoratedStackPanel()
 * @model
 * @generated
 */
public interface DecoratedStackPanel extends StackPanel {
} // DecoratedStackPanel
