/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Split Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSplitPanel()
 * @model
 * @generated
 */
public interface SplitPanel extends Panel {
} // SplitPanel
