/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.gwt.Activity#getPage <em>Page</em>}</li>
 *   <li>{@link kdm.code.gwt.Activity#getRoutes <em>Routes</em>}</li>
 * </ul>
 *
 * @see kdm.code.gwt.GwtPackage#getActivity()
 * @model
 * @generated
 */
public interface Activity extends ClassUnit {
	/**
	 * Returns the value of the '<em><b>Page</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Page</em>' reference.
	 * @see #setPage(Page)
	 * @see kdm.code.gwt.GwtPackage#getActivity_Page()
	 * @model
	 * @generated
	 */
	Page getPage();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Activity#getPage <em>Page</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Page</em>' reference.
	 * @see #getPage()
	 * @generated
	 */
	void setPage(Page value);

	/**
	 * Returns the value of the '<em><b>Routes</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.RoutePlace}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Routes</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getActivity_Routes()
	 * @model
	 * @generated
	 */
	EList<RoutePlace> getRoutes();

} // Activity
