/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UI Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getUIObject()
 * @model
 * @generated
 */
public interface UIObject extends ClassUnit {
} // UIObject
