/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Load Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getLoadListenerCollection()
 * @model
 * @generated
 */
public interface LoadListenerCollection extends LoadListener {
} // LoadListenerCollection
