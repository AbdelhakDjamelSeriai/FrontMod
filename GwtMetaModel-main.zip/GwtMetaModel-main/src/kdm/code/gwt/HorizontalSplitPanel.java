/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Horizontal Split Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHorizontalSplitPanel()
 * @model
 * @generated
 */
public interface HorizontalSplitPanel extends SplitPanel {
} // HorizontalSplitPanel
