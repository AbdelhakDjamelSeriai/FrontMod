/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Check Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSimpleCheckBox()
 * @model
 * @generated
 */
public interface SimpleCheckBox extends FocusWidget {
} // SimpleCheckBox
