/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Directional Text Helper</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDirectionalTextHelper()
 * @model
 * @generated
 */
public interface DirectionalTextHelper extends PopupListener {
} // DirectionalTextHelper
