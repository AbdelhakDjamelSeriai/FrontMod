/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tab Layout Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getTabLayoutPanel()
 * @model
 * @generated
 */
public interface TabLayoutPanel extends ResizeComposite {
} // TabLayoutPanel
