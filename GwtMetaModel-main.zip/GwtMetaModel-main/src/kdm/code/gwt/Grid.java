/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Grid</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getGrid()
 * @model
 * @generated
 */
public interface Grid extends HTMLTable {
} // Grid
