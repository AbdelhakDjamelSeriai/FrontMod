package kdm.code.gwt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DatePicker</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDatePicker()
 * @model
 * @generated
 */
public interface DatePicker extends Button {
} // DatePicker
