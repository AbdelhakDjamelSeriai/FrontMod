/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sources Click Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSourcesClickEvents()
 * @model
 * @generated
 */
public interface SourcesClickEvents extends InterfaceUnit {
} // SourcesClickEvents
