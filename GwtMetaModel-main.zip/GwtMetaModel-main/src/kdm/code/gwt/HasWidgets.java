/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Widgets</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasWidgets()
 * @model
 * @generated
 */
public interface HasWidgets extends InterfaceUnit {
} // HasWidgets
