/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Vertical Scrolling</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasVerticalScrolling()
 * @model
 * @generated
 */
public interface HasVerticalScrolling extends InterfaceUnit {
} // HasVerticalScrolling
