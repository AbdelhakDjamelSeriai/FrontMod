/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Horizontal Split Panel Images</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHorizontalSplitPanelImages()
 * @model
 * @generated
 */
public interface HorizontalSplitPanelImages extends InterfaceUnit {
} // HorizontalSplitPanelImages
