/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Layout Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSimpleLayoutPanel()
 * @model
 * @generated
 */
public interface SimpleLayoutPanel extends SimplePanel {
} // SimpleLayoutPanel
