/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Accepts One Widget</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getAcceptsOneWidget()
 * @model
 * @generated
 */
public interface AcceptsOneWidget extends InterfaceUnit {
} // AcceptsOneWidget
