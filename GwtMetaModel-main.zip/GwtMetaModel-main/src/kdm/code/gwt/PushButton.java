/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Push Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getPushButton()
 * @model
 * @generated
 */
public interface PushButton extends CustomButton {
} // PushButton
