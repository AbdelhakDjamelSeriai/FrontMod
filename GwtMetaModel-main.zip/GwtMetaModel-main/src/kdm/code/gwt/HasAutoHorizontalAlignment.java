/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Auto Horizontal Alignment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasAutoHorizontalAlignment()
 * @model
 * @generated
 */
public interface HasAutoHorizontalAlignment extends InterfaceUnit {
} // HasAutoHorizontalAlignment
