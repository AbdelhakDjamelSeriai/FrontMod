/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getPlace()
 * @model
 * @generated
 */
public interface Place extends ClassUnit {
} // Place
