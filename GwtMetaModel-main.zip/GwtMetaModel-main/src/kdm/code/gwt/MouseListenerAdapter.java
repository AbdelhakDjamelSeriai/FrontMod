/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mouse Listener Adapter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMouseListenerAdapter()
 * @model
 * @generated
 */
public interface MouseListenerAdapter extends TextBoxBase {
} // MouseListenerAdapter
