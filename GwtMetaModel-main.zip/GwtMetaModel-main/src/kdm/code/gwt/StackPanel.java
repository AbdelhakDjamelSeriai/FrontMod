/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stack Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getStackPanel()
 * @model
 * @generated
 */
public interface StackPanel extends ComplexPanel {
} // StackPanel
