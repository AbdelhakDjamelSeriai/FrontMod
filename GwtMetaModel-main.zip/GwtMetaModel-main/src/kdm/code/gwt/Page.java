/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Page</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.gwt.Page#getWidgets <em>Widgets</em>}</li>
 *   <li>{@link kdm.code.gwt.Page#getRoutes <em>Routes</em>}</li>
 *   <li>{@link kdm.code.gwt.Page#getIsKindOfComposite <em>Is Kind Of Composite</em>}</li>
 *   <li>{@link kdm.code.gwt.Page#getIsKindOfWidget <em>Is Kind Of Widget</em>}</li>
 *   <li>{@link kdm.code.gwt.Page#getTypeOfWidget <em>Type Of Widget</em>}</li>
 * </ul>
 *
 * @see kdm.code.gwt.GwtPackage#getPage()
 * @model
 * @generated
 */
public interface Page extends ClassUnit {
	/**
	 * Returns the value of the '<em><b>Widgets</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.Widget}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Widgets</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getPage_Widgets()
	 * @model
	 * @generated
	 */
	EList<Widget> getWidgets();

	/**
	 * Returns the value of the '<em><b>Routes</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.Route}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Routes</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getPage_Routes()
	 * @model
	 * @generated
	 */
	EList<Route> getRoutes();

	/**
	 * Returns the value of the '<em><b>Is Kind Of Composite</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Kind Of Composite</em>' attribute.
	 * @see #setIsKindOfComposite(Boolean)
	 * @see kdm.code.gwt.GwtPackage#getPage_IsKindOfComposite()
	 * @model dataType="kdm.core.Boolean"
	 * @generated
	 */
	Boolean getIsKindOfComposite();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Page#getIsKindOfComposite <em>Is Kind Of Composite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Kind Of Composite</em>' attribute.
	 * @see #getIsKindOfComposite()
	 * @generated
	 */
	void setIsKindOfComposite(Boolean value);

	/**
	 * Returns the value of the '<em><b>Is Kind Of Widget</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Kind Of Widget</em>' attribute.
	 * @see #setIsKindOfWidget(Boolean)
	 * @see kdm.code.gwt.GwtPackage#getPage_IsKindOfWidget()
	 * @model dataType="kdm.core.Boolean"
	 * @generated
	 */
	Boolean getIsKindOfWidget();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Page#getIsKindOfWidget <em>Is Kind Of Widget</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Kind Of Widget</em>' attribute.
	 * @see #getIsKindOfWidget()
	 * @generated
	 */
	void setIsKindOfWidget(Boolean value);

	/**
	 * Returns the value of the '<em><b>Type Of Widget</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type Of Widget</em>' attribute.
	 * @see #setTypeOfWidget(String)
	 * @see kdm.code.gwt.GwtPackage#getPage_TypeOfWidget()
	 * @model dataType="kdm.core.String"
	 * @generated
	 */
	String getTypeOfWidget();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Page#getTypeOfWidget <em>Type Of Widget</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type Of Widget</em>' attribute.
	 * @see #getTypeOfWidget()
	 * @generated
	 */
	void setTypeOfWidget(String value);

} // Page
