/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mouse Wheel Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMouseWheelListenerCollection()
 * @model
 * @generated
 */
public interface MouseWheelListenerCollection extends MouseWheelListener {
} // MouseWheelListenerCollection
