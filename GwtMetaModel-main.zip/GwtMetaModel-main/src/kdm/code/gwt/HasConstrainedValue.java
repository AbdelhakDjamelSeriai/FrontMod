/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Constrained Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasConstrainedValue()
 * @model
 * @generated
 */
public interface HasConstrainedValue extends InterfaceUnit {
} // HasConstrainedValue
