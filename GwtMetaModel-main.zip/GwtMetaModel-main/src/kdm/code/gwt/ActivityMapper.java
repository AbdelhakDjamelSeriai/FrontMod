/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity Mapper</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getActivityMapper()
 * @model
 * @generated
 */
public interface ActivityMapper extends ClassUnit {
} // ActivityMapper
