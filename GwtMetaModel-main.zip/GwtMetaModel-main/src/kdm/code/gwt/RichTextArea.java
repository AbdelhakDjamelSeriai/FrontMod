/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rich Text Area</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getRichTextArea()
 * @model
 * @generated
 */
public interface RichTextArea extends FocusWidget {
} // RichTextArea
