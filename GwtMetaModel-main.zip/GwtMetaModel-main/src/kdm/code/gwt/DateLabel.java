/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Date Label</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDateLabel()
 * @model
 * @generated
 */
public interface DateLabel extends ValueLabel {
} // DateLabel
