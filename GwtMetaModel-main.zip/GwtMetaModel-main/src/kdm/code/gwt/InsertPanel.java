/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Insert Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getInsertPanel()
 * @model
 * @generated
 */
public interface InsertPanel extends InterfaceUnit {
} // InsertPanel
