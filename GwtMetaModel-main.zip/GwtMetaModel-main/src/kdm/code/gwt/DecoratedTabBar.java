/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decorated Tab Bar</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDecoratedTabBar()
 * @model
 * @generated
 */
public interface DecoratedTabBar extends TabBar {
} // DecoratedTabBar
