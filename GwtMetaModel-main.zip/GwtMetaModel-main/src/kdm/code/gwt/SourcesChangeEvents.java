/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sources Change Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSourcesChangeEvents()
 * @model
 * @generated
 */
public interface SourcesChangeEvents extends InterfaceUnit {
} // SourcesChangeEvents
