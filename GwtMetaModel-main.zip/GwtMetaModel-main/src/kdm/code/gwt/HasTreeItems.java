/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Tree Items</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasTreeItems()
 * @model
 * @generated
 */
public interface HasTreeItems extends InterfaceUnit {
} // HasTreeItems
