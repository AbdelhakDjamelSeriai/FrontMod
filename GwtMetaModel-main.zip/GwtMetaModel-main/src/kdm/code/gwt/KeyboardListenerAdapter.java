/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Keyboard Listener Adapter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getKeyboardListenerAdapter()
 * @model
 * @generated
 */
public interface KeyboardListenerAdapter extends UIObject {
} // KeyboardListenerAdapter
