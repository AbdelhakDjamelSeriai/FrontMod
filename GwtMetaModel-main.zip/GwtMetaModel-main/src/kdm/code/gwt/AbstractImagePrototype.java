/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Image Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getAbstractImagePrototype()
 * @model
 * @generated
 */
public interface AbstractImagePrototype extends ComplexPanel {
} // AbstractImagePrototype
