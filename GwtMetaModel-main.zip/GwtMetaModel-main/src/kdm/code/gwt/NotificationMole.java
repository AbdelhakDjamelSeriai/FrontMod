/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Notification Mole</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getNotificationMole()
 * @model
 * @generated
 */
public interface NotificationMole extends Composite {
} // NotificationMole
