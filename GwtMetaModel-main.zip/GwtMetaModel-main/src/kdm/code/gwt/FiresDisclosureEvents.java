/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fires Disclosure Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFiresDisclosureEvents()
 * @model
 * @generated
 */
public interface FiresDisclosureEvents extends InterfaceUnit {
} // FiresDisclosureEvents
