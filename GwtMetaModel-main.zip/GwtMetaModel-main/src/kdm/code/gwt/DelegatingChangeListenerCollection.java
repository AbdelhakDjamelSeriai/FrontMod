/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delegating Change Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDelegatingChangeListenerCollection()
 * @model
 * @generated
 */
public interface DelegatingChangeListenerCollection extends ChangeListenerCollection {
} // DelegatingChangeListenerCollection
