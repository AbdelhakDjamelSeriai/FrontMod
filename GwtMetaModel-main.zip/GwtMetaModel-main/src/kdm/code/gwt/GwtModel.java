/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;
import kdm.code.CodeModel;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.gwt.GwtModel#getPages <em>Pages</em>}</li>
 *   <li>{@link kdm.code.gwt.GwtModel#getActivities <em>Activities</em>}</li>
 *   <li>{@link kdm.code.gwt.GwtModel#getPlaces <em>Places</em>}</li>
 *   <li>{@link kdm.code.gwt.GwtModel#getMapper <em>Mapper</em>}</li>
 * </ul>
 *
 * @see kdm.code.gwt.GwtPackage#getGwtModel()
 * @model
 * @generated
 */
public interface GwtModel extends CodeModel {
	/**
	 * Returns the value of the '<em><b>Pages</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.Page}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pages</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getGwtModel_Pages()
	 * @model
	 * @generated
	 */
	EList<Page> getPages();

	/**
	 * Returns the value of the '<em><b>Activities</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.Activity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activities</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getGwtModel_Activities()
	 * @model
	 * @generated
	 */
	EList<Activity> getActivities();

	/**
	 * Returns the value of the '<em><b>Places</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.Place}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Places</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getGwtModel_Places()
	 * @model
	 * @generated
	 */
	EList<Place> getPlaces();

	/**
	 * Returns the value of the '<em><b>Mapper</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.ClassUnit}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mapper</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getGwtModel_Mapper()
	 * @model
	 * @generated
	 */
	EList<ClassUnit> getMapper();

} // GwtModel
