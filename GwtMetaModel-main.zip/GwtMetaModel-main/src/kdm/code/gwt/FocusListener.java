/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Focus Listener</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFocusListener()
 * @model
 * @generated
 */
public interface FocusListener extends InterfaceUnit {
} // FocusListener
