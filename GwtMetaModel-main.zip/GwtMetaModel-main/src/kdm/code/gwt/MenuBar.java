/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Menu Bar</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMenuBar()
 * @model
 * @generated
 */
public interface MenuBar extends Widget {
} // MenuBar
