/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delegating Focus Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDelegatingFocusListenerCollection()
 * @model
 * @generated
 */
public interface DelegatingFocusListenerCollection extends FocusListenerCollection {
} // DelegatingFocusListenerCollection
