/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Toggle Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getToggleButton()
 * @model
 * @generated
 */
public interface ToggleButton extends CustomButton {
} // ToggleButton
