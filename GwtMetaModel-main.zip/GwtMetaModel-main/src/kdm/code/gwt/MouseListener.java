/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mouse Listener</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMouseListener()
 * @model
 * @generated
 */
public interface MouseListener extends InterfaceUnit {
} // MouseListener
