/**
 */
package kdm.code.gwt;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see kdm.code.gwt.GwtPackage
 * @generated
 */
public interface GwtFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	GwtFactory eINSTANCE = kdm.code.gwt.impl.GwtFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Model</em>'.
	 * @generated
	 */
	GwtModel createGwtModel();

	/**
	 * Returns a new object of class '<em>Page</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Page</em>'.
	 * @generated
	 */
	Page createPage();

	/**
	 * Returns a new object of class '<em>UI Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>UI Object</em>'.
	 * @generated
	 */
	UIObject createUIObject();

	/**
	 * Returns a new object of class '<em>Widget</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Widget</em>'.
	 * @generated
	 */
	Widget createWidget();

	/**
	 * Returns a new object of class '<em>Abstract Image Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Image Prototype</em>'.
	 * @generated
	 */
	AbstractImagePrototype createAbstractImagePrototype();

	/**
	 * Returns a new object of class '<em>Abstract Native Scrollbar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Native Scrollbar</em>'.
	 * @generated
	 */
	AbstractNativeScrollbar createAbstractNativeScrollbar();

	/**
	 * Returns a new object of class '<em>Accepts One Widget</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Accepts One Widget</em>'.
	 * @generated
	 */
	AcceptsOneWidget createAcceptsOneWidget();

	/**
	 * Returns a new object of class '<em>Accessibility</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Accessibility</em>'.
	 * @generated
	 */
	Accessibility createAccessibility();

	/**
	 * Returns a new object of class '<em>Anchor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Anchor</em>'.
	 * @generated
	 */
	Anchor createAnchor();

	/**
	 * Returns a new object of class '<em>Animated Layout</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Animated Layout</em>'.
	 * @generated
	 */
	AnimatedLayout createAnimatedLayout();

	/**
	 * Returns a new object of class '<em>Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Button</em>'.
	 * @generated
	 */
	Button createButton();

	/**
	 * Returns a new object of class '<em>Button Base</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Button Base</em>'.
	 * @generated
	 */
	ButtonBase createButtonBase();

	/**
	 * Returns a new object of class '<em>Caption Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Caption Panel</em>'.
	 * @generated
	 */
	CaptionPanel createCaptionPanel();

	/**
	 * Returns a new object of class '<em>Cell Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cell Panel</em>'.
	 * @generated
	 */
	CellPanel createCellPanel();

	/**
	 * Returns a new object of class '<em>Change Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Change Listener</em>'.
	 * @generated
	 */
	ChangeListener createChangeListener();

	/**
	 * Returns a new object of class '<em>Change Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Change Listener Collection</em>'.
	 * @generated
	 */
	ChangeListenerCollection createChangeListenerCollection();

	/**
	 * Returns a new object of class '<em>Check Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Check Box</em>'.
	 * @generated
	 */
	CheckBox createCheckBox();

	/**
	 * Returns a new object of class '<em>Click Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Click Listener</em>'.
	 * @generated
	 */
	ClickListener createClickListener();

	/**
	 * Returns a new object of class '<em>Click Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Click Listener Collection</em>'.
	 * @generated
	 */
	ClickListenerCollection createClickListenerCollection();

	/**
	 * Returns a new object of class '<em>Complex Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Complex Panel</em>'.
	 * @generated
	 */
	ComplexPanel createComplexPanel();

	/**
	 * Returns a new object of class '<em>Composite</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Composite</em>'.
	 * @generated
	 */
	Composite createComposite();

	/**
	 * Returns a new object of class '<em>Custom Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Custom Button</em>'.
	 * @generated
	 */
	CustomButton createCustomButton();

	/**
	 * Returns a new object of class '<em>Custom Scroll Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Custom Scroll Panel</em>'.
	 * @generated
	 */
	CustomScrollPanel createCustomScrollPanel();

	/**
	 * Returns a new object of class '<em>Date Label</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Date Label</em>'.
	 * @generated
	 */
	DateLabel createDateLabel();

	/**
	 * Returns a new object of class '<em>Deck Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Deck Layout Panel</em>'.
	 * @generated
	 */
	DeckLayoutPanel createDeckLayoutPanel();

	/**
	 * Returns a new object of class '<em>Deck Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Deck Panel</em>'.
	 * @generated
	 */
	DeckPanel createDeckPanel();

	/**
	 * Returns a new object of class '<em>Decorated Popup Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decorated Popup Panel</em>'.
	 * @generated
	 */
	DecoratedPopupPanel createDecoratedPopupPanel();

	/**
	 * Returns a new object of class '<em>Decorated Stack Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decorated Stack Panel</em>'.
	 * @generated
	 */
	DecoratedStackPanel createDecoratedStackPanel();

	/**
	 * Returns a new object of class '<em>Decorated Tab Bar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decorated Tab Bar</em>'.
	 * @generated
	 */
	DecoratedTabBar createDecoratedTabBar();

	/**
	 * Returns a new object of class '<em>Decorated Tab Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decorated Tab Panel</em>'.
	 * @generated
	 */
	DecoratedTabPanel createDecoratedTabPanel();

	/**
	 * Returns a new object of class '<em>Decorator Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decorator Panel</em>'.
	 * @generated
	 */
	DecoratorPanel createDecoratorPanel();

	/**
	 * Returns a new object of class '<em>Delegating Change Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Delegating Change Listener Collection</em>'.
	 * @generated
	 */
	DelegatingChangeListenerCollection createDelegatingChangeListenerCollection();

	/**
	 * Returns a new object of class '<em>Delegating Click Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Delegating Click Listener Collection</em>'.
	 * @generated
	 */
	DelegatingClickListenerCollection createDelegatingClickListenerCollection();

	/**
	 * Returns a new object of class '<em>Delegating Focus Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Delegating Focus Listener Collection</em>'.
	 * @generated
	 */
	DelegatingFocusListenerCollection createDelegatingFocusListenerCollection();

	/**
	 * Returns a new object of class '<em>Delegating Keyboard Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Delegating Keyboard Listener Collection</em>'.
	 * @generated
	 */
	DelegatingKeyboardListenerCollection createDelegatingKeyboardListenerCollection();

	/**
	 * Returns a new object of class '<em>Dialog Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dialog Box</em>'.
	 * @generated
	 */
	DialogBox createDialogBox();

	/**
	 * Returns a new object of class '<em>Directional Text Helper</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Directional Text Helper</em>'.
	 * @generated
	 */
	DirectionalTextHelper createDirectionalTextHelper();

	/**
	 * Returns a new object of class '<em>Disclosure Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Disclosure Event</em>'.
	 * @generated
	 */
	DisclosureEvent createDisclosureEvent();

	/**
	 * Returns a new object of class '<em>Disclosure Handler</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Disclosure Handler</em>'.
	 * @generated
	 */
	DisclosureHandler createDisclosureHandler();

	/**
	 * Returns a new object of class '<em>Disclosure Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Disclosure Panel</em>'.
	 * @generated
	 */
	DisclosurePanel createDisclosurePanel();

	/**
	 * Returns a new object of class '<em>Disclosure Panel Images</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Disclosure Panel Images</em>'.
	 * @generated
	 */
	DisclosurePanelImages createDisclosurePanelImages();

	/**
	 * Returns a new object of class '<em>Disclosure Panel Images RTL</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Disclosure Panel Images RTL</em>'.
	 * @generated
	 */
	DisclosurePanelImagesRTL createDisclosurePanelImagesRTL();

	/**
	 * Returns a new object of class '<em>Dock Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dock Layout Panel</em>'.
	 * @generated
	 */
	DockLayoutPanel createDockLayoutPanel();

	/**
	 * Returns a new object of class '<em>Dock Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dock Panel</em>'.
	 * @generated
	 */
	DockPanel createDockPanel();

	/**
	 * Returns a new object of class '<em>Double Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Double Box</em>'.
	 * @generated
	 */
	DoubleBox createDoubleBox();

	/**
	 * Returns a new object of class '<em>Event Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Object</em>'.
	 * @generated
	 */
	EventObject createEventObject();

	/**
	 * Returns a new object of class '<em>File Upload</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>File Upload</em>'.
	 * @generated
	 */
	FileUpload createFileUpload();

	/**
	 * Returns a new object of class '<em>Finite Widget Iterator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Finite Widget Iterator</em>'.
	 * @generated
	 */
	FiniteWidgetIterator createFiniteWidgetIterator();

	/**
	 * Returns a new object of class '<em>Fires Disclosure Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fires Disclosure Events</em>'.
	 * @generated
	 */
	FiresDisclosureEvents createFiresDisclosureEvents();

	/**
	 * Returns a new object of class '<em>Fires Form Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fires Form Events</em>'.
	 * @generated
	 */
	FiresFormEvents createFiresFormEvents();

	/**
	 * Returns a new object of class '<em>Fires Suggestion Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fires Suggestion Events</em>'.
	 * @generated
	 */
	FiresSuggestionEvents createFiresSuggestionEvents();

	/**
	 * Returns a new object of class '<em>Flex Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Flex Table</em>'.
	 * @generated
	 */
	FlexTable createFlexTable();

	/**
	 * Returns a new object of class '<em>Flow Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Flow Panel</em>'.
	 * @generated
	 */
	FlowPanel createFlowPanel();

	/**
	 * Returns a new object of class '<em>Focus Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Focus Listener</em>'.
	 * @generated
	 */
	FocusListener createFocusListener();

	/**
	 * Returns a new object of class '<em>Focus Listener Adapter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Focus Listener Adapter</em>'.
	 * @generated
	 */
	FocusListenerAdapter createFocusListenerAdapter();

	/**
	 * Returns a new object of class '<em>Focus Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Focus Listener Collection</em>'.
	 * @generated
	 */
	FocusListenerCollection createFocusListenerCollection();

	/**
	 * Returns a new object of class '<em>Focus Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Focus Panel</em>'.
	 * @generated
	 */
	FocusPanel createFocusPanel();

	/**
	 * Returns a new object of class '<em>Focus Widget</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Focus Widget</em>'.
	 * @generated
	 */
	FocusWidget createFocusWidget();

	/**
	 * Returns a new object of class '<em>Focusable</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Focusable</em>'.
	 * @generated
	 */
	Focusable createFocusable();

	/**
	 * Returns a new object of class '<em>Form Handler</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Form Handler</em>'.
	 * @generated
	 */
	FormHandler createFormHandler();

	/**
	 * Returns a new object of class '<em>Form Handler Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Form Handler Collection</em>'.
	 * @generated
	 */
	FormHandlerCollection createFormHandlerCollection();

	/**
	 * Returns a new object of class '<em>Form Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Form Panel</em>'.
	 * @generated
	 */
	FormPanel createFormPanel();

	/**
	 * Returns a new object of class '<em>Form Submit Complete Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Form Submit Complete Event</em>'.
	 * @generated
	 */
	FormSubmitCompleteEvent createFormSubmitCompleteEvent();

	/**
	 * Returns a new object of class '<em>Form Submit Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Form Submit Event</em>'.
	 * @generated
	 */
	FormSubmitEvent createFormSubmitEvent();

	/**
	 * Returns a new object of class '<em>Frame</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Frame</em>'.
	 * @generated
	 */
	Frame createFrame();

	/**
	 * Returns a new object of class '<em>Grid</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Grid</em>'.
	 * @generated
	 */
	Grid createGrid();

	/**
	 * Returns a new object of class '<em>HTML</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>HTML</em>'.
	 * @generated
	 */
	HTML createHTML();

	/**
	 * Returns a new object of class '<em>HTML Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>HTML Panel</em>'.
	 * @generated
	 */
	HTMLPanel createHTMLPanel();

	/**
	 * Returns a new object of class '<em>HTML Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>HTML Table</em>'.
	 * @generated
	 */
	HTMLTable createHTMLTable();

	/**
	 * Returns a new object of class '<em>Has Alignment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Alignment</em>'.
	 * @generated
	 */
	HasAlignment createHasAlignment();

	/**
	 * Returns a new object of class '<em>Has Animation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Animation</em>'.
	 * @generated
	 */
	HasAnimation createHasAnimation();

	/**
	 * Returns a new object of class '<em>Has Auto Horizontal Alignment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Auto Horizontal Alignment</em>'.
	 * @generated
	 */
	HasAutoHorizontalAlignment createHasAutoHorizontalAlignment();

	/**
	 * Returns a new object of class '<em>Has Caption</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Caption</em>'.
	 * @generated
	 */
	HasCaption createHasCaption();

	/**
	 * Returns a new object of class '<em>Has Constrained Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Constrained Value</em>'.
	 * @generated
	 */
	HasConstrainedValue createHasConstrainedValue();

	/**
	 * Returns a new object of class '<em>Has Directional Html</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Directional Html</em>'.
	 * @generated
	 */
	HasDirectionalHtml createHasDirectionalHtml();

	/**
	 * Returns a new object of class '<em>Has Directional Safe Html</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Directional Safe Html</em>'.
	 * @generated
	 */
	HasDirectionalSafeHtml createHasDirectionalSafeHtml();

	/**
	 * Returns a new object of class '<em>Has Directional Text</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Directional Text</em>'.
	 * @generated
	 */
	HasDirectionalText createHasDirectionalText();

	/**
	 * Returns a new object of class '<em>Has Enabled</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Enabled</em>'.
	 * @generated
	 */
	HasEnabled createHasEnabled();

	/**
	 * Returns a new object of class '<em>Has Focus</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Focus</em>'.
	 * @generated
	 */
	HasFocus createHasFocus();

	/**
	 * Returns a new object of class '<em>Has HTML</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has HTML</em>'.
	 * @generated
	 */
	HasHTML createHasHTML();

	/**
	 * Returns a new object of class '<em>Has Horizontal Alignment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Horizontal Alignment</em>'.
	 * @generated
	 */
	HasHorizontalAlignment createHasHorizontalAlignment();

	/**
	 * Returns a new object of class '<em>Has Horizontal Scrolling</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Horizontal Scrolling</em>'.
	 * @generated
	 */
	HasHorizontalScrolling createHasHorizontalScrolling();

	/**
	 * Returns a new object of class '<em>Has Key Preview</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Key Preview</em>'.
	 * @generated
	 */
	HasKeyPreview createHasKeyPreview();

	/**
	 * Returns a new object of class '<em>Has Name</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Name</em>'.
	 * @generated
	 */
	HasName createHasName();

	/**
	 * Returns a new object of class '<em>Has One Widget</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has One Widget</em>'.
	 * @generated
	 */
	HasOneWidget createHasOneWidget();

	/**
	 * Returns a new object of class '<em>Has Scrolling</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Scrolling</em>'.
	 * @generated
	 */
	HasScrolling createHasScrolling();

	/**
	 * Returns a new object of class '<em>Has Text</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Text</em>'.
	 * @generated
	 */
	HasText createHasText();

	/**
	 * Returns a new object of class '<em>Has Tree Items</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Tree Items</em>'.
	 * @generated
	 */
	HasTreeItems createHasTreeItems();

	/**
	 * Returns a new object of class '<em>Has Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Value</em>'.
	 * @generated
	 */
	HasValue createHasValue();

	/**
	 * Returns a new object of class '<em>Has Vertical Alignment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Vertical Alignment</em>'.
	 * @generated
	 */
	HasVerticalAlignment createHasVerticalAlignment();

	/**
	 * Returns a new object of class '<em>Has Vertical Scrolling</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Vertical Scrolling</em>'.
	 * @generated
	 */
	HasVerticalScrolling createHasVerticalScrolling();

	/**
	 * Returns a new object of class '<em>Has Visibility</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Visibility</em>'.
	 * @generated
	 */
	HasVisibility createHasVisibility();

	/**
	 * Returns a new object of class '<em>Has Widgets</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Widgets</em>'.
	 * @generated
	 */
	HasWidgets createHasWidgets();

	/**
	 * Returns a new object of class '<em>Has Word Wrap</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Has Word Wrap</em>'.
	 * @generated
	 */
	HasWordWrap createHasWordWrap();

	/**
	 * Returns a new object of class '<em>Header Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Header Panel</em>'.
	 * @generated
	 */
	HeaderPanel createHeaderPanel();

	/**
	 * Returns a new object of class '<em>Hidden</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hidden</em>'.
	 * @generated
	 */
	Hidden createHidden();

	/**
	 * Returns a new object of class '<em>Horizontal Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Horizontal Panel</em>'.
	 * @generated
	 */
	HorizontalPanel createHorizontalPanel();

	/**
	 * Returns a new object of class '<em>Horizontal Scrollbar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Horizontal Scrollbar</em>'.
	 * @generated
	 */
	HorizontalScrollbar createHorizontalScrollbar();

	/**
	 * Returns a new object of class '<em>Horizontal Split Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Horizontal Split Panel</em>'.
	 * @generated
	 */
	HorizontalSplitPanel createHorizontalSplitPanel();

	/**
	 * Returns a new object of class '<em>Horizontal Split Panel Images</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Horizontal Split Panel Images</em>'.
	 * @generated
	 */
	HorizontalSplitPanelImages createHorizontalSplitPanelImages();

	/**
	 * Returns a new object of class '<em>Hyperlink</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hyperlink</em>'.
	 * @generated
	 */
	Hyperlink createHyperlink();

	/**
	 * Returns a new object of class '<em>GWT Image</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>GWT Image</em>'.
	 * @generated
	 */
	GWTImage createGWTImage();

	/**
	 * Returns a new object of class '<em>Image Bundle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Image Bundle</em>'.
	 * @generated
	 */
	ImageBundle createImageBundle();

	/**
	 * Returns a new object of class '<em>Indexed Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Indexed Panel</em>'.
	 * @generated
	 */
	IndexedPanel createIndexedPanel();

	/**
	 * Returns a new object of class '<em>Inline HTML</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Inline HTML</em>'.
	 * @generated
	 */
	InlineHTML createInlineHTML();

	/**
	 * Returns a new object of class '<em>Inline Hyperlink</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Inline Hyperlink</em>'.
	 * @generated
	 */
	InlineHyperlink createInlineHyperlink();

	/**
	 * Returns a new object of class '<em>Inline Label</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Inline Label</em>'.
	 * @generated
	 */
	InlineLabel createInlineLabel();

	/**
	 * Returns a new object of class '<em>Insert Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Insert Panel</em>'.
	 * @generated
	 */
	InsertPanel createInsertPanel();

	/**
	 * Returns a new object of class '<em>Integer Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Integer Box</em>'.
	 * @generated
	 */
	IntegerBox createIntegerBox();

	/**
	 * Returns a new object of class '<em>Is Renderable</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Is Renderable</em>'.
	 * @generated
	 */
	IsRenderable createIsRenderable();

	/**
	 * Returns a new object of class '<em>Is Tree Item</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Is Tree Item</em>'.
	 * @generated
	 */
	IsTreeItem createIsTreeItem();

	/**
	 * Returns a new object of class '<em>Is Widget</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Is Widget</em>'.
	 * @generated
	 */
	IsWidget createIsWidget();

	/**
	 * Returns a new object of class '<em>Keyboard Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Keyboard Listener</em>'.
	 * @generated
	 */
	KeyboardListener createKeyboardListener();

	/**
	 * Returns a new object of class '<em>Keyboard Listener Adapter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Keyboard Listener Adapter</em>'.
	 * @generated
	 */
	KeyboardListenerAdapter createKeyboardListenerAdapter();

	/**
	 * Returns a new object of class '<em>Keyboard Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Keyboard Listener Collection</em>'.
	 * @generated
	 */
	KeyboardListenerCollection createKeyboardListenerCollection();

	/**
	 * Returns a new object of class '<em>Label</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Label</em>'.
	 * @generated
	 */
	Label createLabel();

	/**
	 * Returns a new object of class '<em>Label Base</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Label Base</em>'.
	 * @generated
	 */
	LabelBase createLabelBase();

	/**
	 * Returns a new object of class '<em>Layout Command</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Layout Command</em>'.
	 * @generated
	 */
	LayoutCommand createLayoutCommand();

	/**
	 * Returns a new object of class '<em>Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Layout Panel</em>'.
	 * @generated
	 */
	LayoutPanel createLayoutPanel();

	/**
	 * Returns a new object of class '<em>Lazy Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Lazy Panel</em>'.
	 * @generated
	 */
	LazyPanel createLazyPanel();

	/**
	 * Returns a new object of class '<em>List Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>List Box</em>'.
	 * @generated
	 */
	ListBox createListBox();

	/**
	 * Returns a new object of class '<em>Load Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Load Listener</em>'.
	 * @generated
	 */
	LoadListener createLoadListener();

	/**
	 * Returns a new object of class '<em>Load Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Load Listener Collection</em>'.
	 * @generated
	 */
	LoadListenerCollection createLoadListenerCollection();

	/**
	 * Returns a new object of class '<em>Long Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Long Box</em>'.
	 * @generated
	 */
	LongBox createLongBox();

	/**
	 * Returns a new object of class '<em>Menu Bar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Menu Bar</em>'.
	 * @generated
	 */
	MenuBar createMenuBar();

	/**
	 * Returns a new object of class '<em>Menu Item</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Menu Item</em>'.
	 * @generated
	 */
	MenuItem createMenuItem();

	/**
	 * Returns a new object of class '<em>Menu Item Separator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Menu Item Separator</em>'.
	 * @generated
	 */
	MenuItemSeparator createMenuItemSeparator();

	/**
	 * Returns a new object of class '<em>Mouse Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mouse Listener</em>'.
	 * @generated
	 */
	MouseListener createMouseListener();

	/**
	 * Returns a new object of class '<em>Mouse Listener Adapter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mouse Listener Adapter</em>'.
	 * @generated
	 */
	MouseListenerAdapter createMouseListenerAdapter();

	/**
	 * Returns a new object of class '<em>Mouse Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mouse Listener Collection</em>'.
	 * @generated
	 */
	MouseListenerCollection createMouseListenerCollection();

	/**
	 * Returns a new object of class '<em>Mouse Wheel Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mouse Wheel Listener</em>'.
	 * @generated
	 */
	MouseWheelListener createMouseWheelListener();

	/**
	 * Returns a new object of class '<em>Mouse Wheel Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mouse Wheel Listener Collection</em>'.
	 * @generated
	 */
	MouseWheelListenerCollection createMouseWheelListenerCollection();

	/**
	 * Returns a new object of class '<em>Mouse Wheel Velocity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mouse Wheel Velocity</em>'.
	 * @generated
	 */
	MouseWheelVelocity createMouseWheelVelocity();

	/**
	 * Returns a new object of class '<em>Multi Word Suggest Oracle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Multi Word Suggest Oracle</em>'.
	 * @generated
	 */
	MultiWordSuggestOracle createMultiWordSuggestOracle();

	/**
	 * Returns a new object of class '<em>Named Frame</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Named Frame</em>'.
	 * @generated
	 */
	NamedFrame createNamedFrame();

	/**
	 * Returns a new object of class '<em>Native Horizontal Scrollbar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Native Horizontal Scrollbar</em>'.
	 * @generated
	 */
	NativeHorizontalScrollbar createNativeHorizontalScrollbar();

	/**
	 * Returns a new object of class '<em>Native Vertical Scrollbar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Native Vertical Scrollbar</em>'.
	 * @generated
	 */
	NativeVerticalScrollbar createNativeVerticalScrollbar();

	/**
	 * Returns a new object of class '<em>Notification Mole</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Notification Mole</em>'.
	 * @generated
	 */
	NotificationMole createNotificationMole();

	/**
	 * Returns a new object of class '<em>Number Label</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Number Label</em>'.
	 * @generated
	 */
	NumberLabel createNumberLabel();

	/**
	 * Returns a new object of class '<em>Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Panel</em>'.
	 * @generated
	 */
	Panel createPanel();

	/**
	 * Returns a new object of class '<em>Password Text Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Password Text Box</em>'.
	 * @generated
	 */
	PasswordTextBox createPasswordTextBox();

	/**
	 * Returns a new object of class '<em>Popup Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Popup Listener</em>'.
	 * @generated
	 */
	PopupListener createPopupListener();

	/**
	 * Returns a new object of class '<em>Popup Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Popup Listener Collection</em>'.
	 * @generated
	 */
	PopupListenerCollection createPopupListenerCollection();

	/**
	 * Returns a new object of class '<em>Popup Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Popup Panel</em>'.
	 * @generated
	 */
	PopupPanel createPopupPanel();

	/**
	 * Returns a new object of class '<em>Provides Resize</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Provides Resize</em>'.
	 * @generated
	 */
	ProvidesResize createProvidesResize();

	/**
	 * Returns a new object of class '<em>Push Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Push Button</em>'.
	 * @generated
	 */
	PushButton createPushButton();

	/**
	 * Returns a new object of class '<em>Radio Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Radio Button</em>'.
	 * @generated
	 */
	RadioButton createRadioButton();

	/**
	 * Returns a new object of class '<em>Renderable Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Renderable Panel</em>'.
	 * @generated
	 */
	RenderablePanel createRenderablePanel();

	/**
	 * Returns a new object of class '<em>Requires Resize</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Requires Resize</em>'.
	 * @generated
	 */
	RequiresResize createRequiresResize();

	/**
	 * Returns a new object of class '<em>Reset Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reset Button</em>'.
	 * @generated
	 */
	ResetButton createResetButton();

	/**
	 * Returns a new object of class '<em>Resize Composite</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Resize Composite</em>'.
	 * @generated
	 */
	ResizeComposite createResizeComposite();

	/**
	 * Returns a new object of class '<em>Resize Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Resize Layout Panel</em>'.
	 * @generated
	 */
	ResizeLayoutPanel createResizeLayoutPanel();

	/**
	 * Returns a new object of class '<em>Rich Text Area</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rich Text Area</em>'.
	 * @generated
	 */
	RichTextArea createRichTextArea();

	/**
	 * Returns a new object of class '<em>Root Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Root Layout Panel</em>'.
	 * @generated
	 */
	RootLayoutPanel createRootLayoutPanel();

	/**
	 * Returns a new object of class '<em>Root Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Root Panel</em>'.
	 * @generated
	 */
	RootPanel createRootPanel();

	/**
	 * Returns a new object of class '<em>Scroll Impl</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scroll Impl</em>'.
	 * @generated
	 */
	ScrollImpl createScrollImpl();

	/**
	 * Returns a new object of class '<em>Scroll Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scroll Listener</em>'.
	 * @generated
	 */
	ScrollListener createScrollListener();

	/**
	 * Returns a new object of class '<em>Scroll Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scroll Listener Collection</em>'.
	 * @generated
	 */
	ScrollListenerCollection createScrollListenerCollection();

	/**
	 * Returns a new object of class '<em>Scroll Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scroll Panel</em>'.
	 * @generated
	 */
	ScrollPanel createScrollPanel();

	/**
	 * Returns a new object of class '<em>Simple Check Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Simple Check Box</em>'.
	 * @generated
	 */
	SimpleCheckBox createSimpleCheckBox();

	/**
	 * Returns a new object of class '<em>Simple Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Simple Layout Panel</em>'.
	 * @generated
	 */
	SimpleLayoutPanel createSimpleLayoutPanel();

	/**
	 * Returns a new object of class '<em>Simple Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Simple Panel</em>'.
	 * @generated
	 */
	SimplePanel createSimplePanel();

	/**
	 * Returns a new object of class '<em>Simple Radio Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Simple Radio Button</em>'.
	 * @generated
	 */
	SimpleRadioButton createSimpleRadioButton();

	/**
	 * Returns a new object of class '<em>Sources Change Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Change Events</em>'.
	 * @generated
	 */
	SourcesChangeEvents createSourcesChangeEvents();

	/**
	 * Returns a new object of class '<em>Sources Click Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Click Events</em>'.
	 * @generated
	 */
	SourcesClickEvents createSourcesClickEvents();

	/**
	 * Returns a new object of class '<em>Sources Focus Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Focus Events</em>'.
	 * @generated
	 */
	SourcesFocusEvents createSourcesFocusEvents();

	/**
	 * Returns a new object of class '<em>Sources Keyboard Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Keyboard Events</em>'.
	 * @generated
	 */
	SourcesKeyboardEvents createSourcesKeyboardEvents();

	/**
	 * Returns a new object of class '<em>Sources Load Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Load Events</em>'.
	 * @generated
	 */
	SourcesLoadEvents createSourcesLoadEvents();

	/**
	 * Returns a new object of class '<em>Sources Mouse Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Mouse Events</em>'.
	 * @generated
	 */
	SourcesMouseEvents createSourcesMouseEvents();

	/**
	 * Returns a new object of class '<em>Sources Mouse Wheel Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Mouse Wheel Events</em>'.
	 * @generated
	 */
	SourcesMouseWheelEvents createSourcesMouseWheelEvents();

	/**
	 * Returns a new object of class '<em>Sources Popup Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Popup Events</em>'.
	 * @generated
	 */
	SourcesPopupEvents createSourcesPopupEvents();

	/**
	 * Returns a new object of class '<em>Sources Scroll Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Scroll Events</em>'.
	 * @generated
	 */
	SourcesScrollEvents createSourcesScrollEvents();

	/**
	 * Returns a new object of class '<em>Sources Tab Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Tab Events</em>'.
	 * @generated
	 */
	SourcesTabEvents createSourcesTabEvents();

	/**
	 * Returns a new object of class '<em>Sources Table Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Table Events</em>'.
	 * @generated
	 */
	SourcesTableEvents createSourcesTableEvents();

	/**
	 * Returns a new object of class '<em>Sources Tree Events</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sources Tree Events</em>'.
	 * @generated
	 */
	SourcesTreeEvents createSourcesTreeEvents();

	/**
	 * Returns a new object of class '<em>Split Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Split Layout Panel</em>'.
	 * @generated
	 */
	SplitLayoutPanel createSplitLayoutPanel();

	/**
	 * Returns a new object of class '<em>Split Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Split Panel</em>'.
	 * @generated
	 */
	SplitPanel createSplitPanel();

	/**
	 * Returns a new object of class '<em>Stack Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stack Layout Panel</em>'.
	 * @generated
	 */
	StackLayoutPanel createStackLayoutPanel();

	/**
	 * Returns a new object of class '<em>Stack Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stack Panel</em>'.
	 * @generated
	 */
	StackPanel createStackPanel();

	/**
	 * Returns a new object of class '<em>Submit Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Submit Button</em>'.
	 * @generated
	 */
	SubmitButton createSubmitButton();

	/**
	 * Returns a new object of class '<em>Suggest Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Suggest Box</em>'.
	 * @generated
	 */
	SuggestBox createSuggestBox();

	/**
	 * Returns a new object of class '<em>Suggest Oracle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Suggest Oracle</em>'.
	 * @generated
	 */
	SuggestOracle createSuggestOracle();

	/**
	 * Returns a new object of class '<em>Suggestion Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Suggestion Event</em>'.
	 * @generated
	 */
	SuggestionEvent createSuggestionEvent();

	/**
	 * Returns a new object of class '<em>Suggestion Handler</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Suggestion Handler</em>'.
	 * @generated
	 */
	SuggestionHandler createSuggestionHandler();

	/**
	 * Returns a new object of class '<em>Tab Bar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tab Bar</em>'.
	 * @generated
	 */
	TabBar createTabBar();

	/**
	 * Returns a new object of class '<em>Tab Layout Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tab Layout Panel</em>'.
	 * @generated
	 */
	TabLayoutPanel createTabLayoutPanel();

	/**
	 * Returns a new object of class '<em>Tab Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tab Listener</em>'.
	 * @generated
	 */
	TabListener createTabListener();

	/**
	 * Returns a new object of class '<em>Tab Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tab Listener Collection</em>'.
	 * @generated
	 */
	TabListenerCollection createTabListenerCollection();

	/**
	 * Returns a new object of class '<em>Tab Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tab Panel</em>'.
	 * @generated
	 */
	TabPanel createTabPanel();

	/**
	 * Returns a new object of class '<em>Table Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Table Listener</em>'.
	 * @generated
	 */
	TableListener createTableListener();

	/**
	 * Returns a new object of class '<em>Table Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Table Listener Collection</em>'.
	 * @generated
	 */
	TableListenerCollection createTableListenerCollection();

	/**
	 * Returns a new object of class '<em>Text Area</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text Area</em>'.
	 * @generated
	 */
	TextArea createTextArea();

	/**
	 * Returns a new object of class '<em>Text Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text Box</em>'.
	 * @generated
	 */
	TextBox createTextBox();

	/**
	 * Returns a new object of class '<em>Text Box Base</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text Box Base</em>'.
	 * @generated
	 */
	TextBoxBase createTextBoxBase();

	/**
	 * Returns a new object of class '<em>Toggle Button</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Toggle Button</em>'.
	 * @generated
	 */
	ToggleButton createToggleButton();

	/**
	 * Returns a new object of class '<em>Tree</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tree</em>'.
	 * @generated
	 */
	Tree createTree();

	/**
	 * Returns a new object of class '<em>Tree Images</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tree Images</em>'.
	 * @generated
	 */
	TreeImages createTreeImages();

	/**
	 * Returns a new object of class '<em>Tree Item</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tree Item</em>'.
	 * @generated
	 */
	TreeItem createTreeItem();

	/**
	 * Returns a new object of class '<em>Tree Listener</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tree Listener</em>'.
	 * @generated
	 */
	TreeListener createTreeListener();

	/**
	 * Returns a new object of class '<em>Tree Listener Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tree Listener Collection</em>'.
	 * @generated
	 */
	TreeListenerCollection createTreeListenerCollection();

	/**
	 * Returns a new object of class '<em>Value Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Value Box</em>'.
	 * @generated
	 */
	ValueBox createValueBox();

	/**
	 * Returns a new object of class '<em>Value Box Base</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Value Box Base</em>'.
	 * @generated
	 */
	ValueBoxBase createValueBoxBase();

	/**
	 * Returns a new object of class '<em>Value Label</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Value Label</em>'.
	 * @generated
	 */
	ValueLabel createValueLabel();

	/**
	 * Returns a new object of class '<em>Value List Box</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Value List Box</em>'.
	 * @generated
	 */
	ValueListBox createValueListBox();

	/**
	 * Returns a new object of class '<em>Value Picker</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Value Picker</em>'.
	 * @generated
	 */
	ValuePicker createValuePicker();

	/**
	 * Returns a new object of class '<em>Vertical Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vertical Panel</em>'.
	 * @generated
	 */
	VerticalPanel createVerticalPanel();

	/**
	 * Returns a new object of class '<em>Vertical Scrollbar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vertical Scrollbar</em>'.
	 * @generated
	 */
	VerticalScrollbar createVerticalScrollbar();

	/**
	 * Returns a new object of class '<em>Vertical Split Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vertical Split Panel</em>'.
	 * @generated
	 */
	VerticalSplitPanel createVerticalSplitPanel();

	/**
	 * Returns a new object of class '<em>Vertical Split Panel Images</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vertical Split Panel Images</em>'.
	 * @generated
	 */
	VerticalSplitPanelImages createVerticalSplitPanelImages();

	/**
	 * Returns a new object of class '<em>Widget Collection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Widget Collection</em>'.
	 * @generated
	 */
	WidgetCollection createWidgetCollection();

	/**
	 * Returns a new object of class '<em>Widget Iterators</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Widget Iterators</em>'.
	 * @generated
	 */
	WidgetIterators createWidgetIterators();

	/**
	 * Returns a new object of class '<em>Absolute Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Absolute Panel</em>'.
	 * @generated
	 */
	AbsolutePanel createAbsolutePanel();

	/**
	 * Returns a new object of class '<em>Date Picker</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Date Picker</em>'.
	 * @generated
	 */
	DatePicker createDatePicker();

	/**
	 * Returns a new object of class '<em>Route</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Route</em>'.
	 * @generated
	 */
	Route createRoute();

	/**
	 * Returns a new object of class '<em>Controller History</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Controller History</em>'.
	 * @generated
	 */
	ControllerHistory createControllerHistory();

	/**
	 * Returns a new object of class '<em>Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Activity</em>'.
	 * @generated
	 */
	Activity createActivity();

	/**
	 * Returns a new object of class '<em>Place</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Place</em>'.
	 * @generated
	 */
	Place createPlace();

	/**
	 * Returns a new object of class '<em>Route Place</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Route Place</em>'.
	 * @generated
	 */
	RoutePlace createRoutePlace();

	/**
	 * Returns a new object of class '<em>Activity Mapper</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Activity Mapper</em>'.
	 * @generated
	 */
	ActivityMapper createActivityMapper();

	/**
	 * Returns a new object of class '<em>Cell Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cell Table</em>'.
	 * @generated
	 */
	CellTable createCellTable();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	GwtPackage getGwtPackage();

} //GwtFactory
