/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value List Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getValueListBox()
 * @model
 * @generated
 */
public interface ValueListBox extends Composite {
} // ValueListBox
