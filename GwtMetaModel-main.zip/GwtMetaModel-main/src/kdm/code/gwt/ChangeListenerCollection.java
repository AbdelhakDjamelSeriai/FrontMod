/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Change Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getChangeListenerCollection()
 * @model
 * @generated
 */
public interface ChangeListenerCollection extends ChangeListener {
} // ChangeListenerCollection
