/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Absolute Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getAbsolutePanel()
 * @model
 * @generated
 */
public interface AbsolutePanel extends ComplexPanel {
} // AbsolutePanel
