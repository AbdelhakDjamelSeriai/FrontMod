/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Box Base</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getValueBoxBase()
 * @model
 * @generated
 */
public interface ValueBoxBase extends FocusWidget {
} // ValueBoxBase
