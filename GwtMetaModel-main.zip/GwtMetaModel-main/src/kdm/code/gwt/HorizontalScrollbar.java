/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Horizontal Scrollbar</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHorizontalScrollbar()
 * @model
 * @generated
 */
public interface HorizontalScrollbar extends InterfaceUnit {
} // HorizontalScrollbar
