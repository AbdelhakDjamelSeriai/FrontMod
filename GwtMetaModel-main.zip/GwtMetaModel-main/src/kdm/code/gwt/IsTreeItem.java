/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Is Tree Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getIsTreeItem()
 * @model
 * @generated
 */
public interface IsTreeItem extends InterfaceUnit {
} // IsTreeItem
