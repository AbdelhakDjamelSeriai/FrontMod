/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dialog Box</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getDialogBox()
 * @model
 * @generated
 */
public interface DialogBox extends DecoratedPopupPanel {
} // DialogBox
