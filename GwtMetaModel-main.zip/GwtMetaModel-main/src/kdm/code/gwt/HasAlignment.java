/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Alignment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasAlignment()
 * @model
 * @generated
 */
public interface HasAlignment extends InterfaceUnit {
} // HasAlignment
