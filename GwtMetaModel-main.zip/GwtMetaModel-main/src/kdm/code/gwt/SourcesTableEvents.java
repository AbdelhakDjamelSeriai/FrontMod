/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sources Table Events</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSourcesTableEvents()
 * @model
 * @generated
 */
public interface SourcesTableEvents extends InterfaceUnit {
} // SourcesTableEvents
