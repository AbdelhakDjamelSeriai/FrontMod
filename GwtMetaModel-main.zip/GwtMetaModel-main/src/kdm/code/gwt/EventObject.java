/**
 */
package kdm.code.gwt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getEventObject()
 * @model
 * @generated
 */
public interface EventObject extends EObject {
} // EventObject
