/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Menu Item Separator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getMenuItemSeparator()
 * @model
 * @generated
 */
public interface MenuItemSeparator extends UIObject {
} // MenuItemSeparator
