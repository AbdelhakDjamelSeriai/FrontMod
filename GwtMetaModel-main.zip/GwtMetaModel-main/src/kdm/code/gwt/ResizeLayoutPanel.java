/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Resize Layout Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getResizeLayoutPanel()
 * @model
 * @generated
 */
public interface ResizeLayoutPanel extends SimplePanel {
} // ResizeLayoutPanel
