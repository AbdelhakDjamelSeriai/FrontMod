/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cell Table</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getCellTable()
 * @model
 * @generated
 */
public interface CellTable extends Composite {
} // CellTable
