/**
 */
package kdm.code.gwt;

import kdm.code.AbstractCodeElement;

import kdm.code.ClassUnit;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Widget</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.gwt.Widget#getActions <em>Actions</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getIsContainer <em>Is Container</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getNestedWidgets <em>Nested Widgets</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getTypeWidget <em>Type Widget</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getStyle <em>Style</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getContainerOuterHtml <em>Container Outer Html</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getLeafOuterHtml <em>Leaf Outer Html</em>}</li>
 *   <li>{@link kdm.code.gwt.Widget#getIsNewDecoratedWidget <em>Is New Decorated Widget</em>}</li>
 * </ul>
 *
 * @see kdm.code.gwt.GwtPackage#getWidget()
 * @model
 * @generated
 */
public interface Widget extends UIObject {
	/**
	 * Returns the value of the '<em><b>Actions</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.AbstractCodeElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actions</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getWidget_Actions()
	 * @model
	 * @generated
	 */
	EList<AbstractCodeElement> getActions();

	/**
	 * Returns the value of the '<em><b>Is Container</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Container</em>' attribute.
	 * @see #setIsContainer(Boolean)
	 * @see kdm.code.gwt.GwtPackage#getWidget_IsContainer()
	 * @model dataType="kdm.core.Boolean"
	 * @generated
	 */
	Boolean getIsContainer();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Widget#getIsContainer <em>Is Container</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Container</em>' attribute.
	 * @see #getIsContainer()
	 * @generated
	 */
	void setIsContainer(Boolean value);

	/**
	 * Returns the value of the '<em><b>Nested Widgets</b></em>' reference list.
	 * The list contents are of type {@link kdm.code.gwt.Widget}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nested Widgets</em>' reference list.
	 * @see kdm.code.gwt.GwtPackage#getWidget_NestedWidgets()
	 * @model
	 * @generated
	 */
	EList<Widget> getNestedWidgets();

	/**
	 * Returns the value of the '<em><b>Type Widget</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type Widget</em>' reference.
	 * @see #setTypeWidget(ClassUnit)
	 * @see kdm.code.gwt.GwtPackage#getWidget_TypeWidget()
	 * @model
	 * @generated
	 */
	ClassUnit getTypeWidget();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Widget#getTypeWidget <em>Type Widget</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type Widget</em>' reference.
	 * @see #getTypeWidget()
	 * @generated
	 */
	void setTypeWidget(ClassUnit value);

	/**
	 * Returns the value of the '<em><b>Style</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Style</em>' attribute.
	 * @see #setStyle(String)
	 * @see kdm.code.gwt.GwtPackage#getWidget_Style()
	 * @model dataType="kdm.core.String"
	 * @generated
	 */
	String getStyle();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Widget#getStyle <em>Style</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Style</em>' attribute.
	 * @see #getStyle()
	 * @generated
	 */
	void setStyle(String value);

	/**
	 * Returns the value of the '<em><b>Container Outer Html</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container Outer Html</em>' attribute.
	 * @see #setContainerOuterHtml(String)
	 * @see kdm.code.gwt.GwtPackage#getWidget_ContainerOuterHtml()
	 * @model dataType="kdm.core.String"
	 * @generated
	 */
	String getContainerOuterHtml();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Widget#getContainerOuterHtml <em>Container Outer Html</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Container Outer Html</em>' attribute.
	 * @see #getContainerOuterHtml()
	 * @generated
	 */
	void setContainerOuterHtml(String value);

	/**
	 * Returns the value of the '<em><b>Leaf Outer Html</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Leaf Outer Html</em>' attribute.
	 * @see #setLeafOuterHtml(String)
	 * @see kdm.code.gwt.GwtPackage#getWidget_LeafOuterHtml()
	 * @model dataType="kdm.core.String"
	 * @generated
	 */
	String getLeafOuterHtml();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Widget#getLeafOuterHtml <em>Leaf Outer Html</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Leaf Outer Html</em>' attribute.
	 * @see #getLeafOuterHtml()
	 * @generated
	 */
	void setLeafOuterHtml(String value);

	/**
	 * Returns the value of the '<em><b>Is New Decorated Widget</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is New Decorated Widget</em>' attribute.
	 * @see #setIsNewDecoratedWidget(Boolean)
	 * @see kdm.code.gwt.GwtPackage#getWidget_IsNewDecoratedWidget()
	 * @model dataType="kdm.core.Boolean"
	 * @generated
	 */
	Boolean getIsNewDecoratedWidget();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Widget#getIsNewDecoratedWidget <em>Is New Decorated Widget</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is New Decorated Widget</em>' attribute.
	 * @see #getIsNewDecoratedWidget()
	 * @generated
	 */
	void setIsNewDecoratedWidget(Boolean value);

} // Widget
