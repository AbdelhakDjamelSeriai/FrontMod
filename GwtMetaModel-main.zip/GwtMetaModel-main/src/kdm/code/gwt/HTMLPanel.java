/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>HTML Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHTMLPanel()
 * @model
 * @generated
 */
public interface HTMLPanel extends ComplexPanel {
} // HTMLPanel
