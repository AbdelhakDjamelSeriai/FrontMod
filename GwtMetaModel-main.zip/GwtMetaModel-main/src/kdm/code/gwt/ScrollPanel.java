/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scroll Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getScrollPanel()
 * @model
 * @generated
 */
public interface ScrollPanel extends SimplePanel {
} // ScrollPanel
