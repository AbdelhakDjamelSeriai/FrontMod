/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Key Preview</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasKeyPreview()
 * @model
 * @generated
 */
public interface HasKeyPreview extends InterfaceUnit {
} // HasKeyPreview
