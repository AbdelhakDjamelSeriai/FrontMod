/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Focus Listener Adapter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFocusListenerAdapter()
 * @model
 * @generated
 */
public interface FocusListenerAdapter extends UIObject {
} // FocusListenerAdapter
