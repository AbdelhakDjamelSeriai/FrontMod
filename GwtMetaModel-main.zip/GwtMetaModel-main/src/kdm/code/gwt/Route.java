/**
 */
package kdm.code.gwt;

import kdm.code.ClassUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Route</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.gwt.Route#getToken <em>Token</em>}</li>
 *   <li>{@link kdm.code.gwt.Route#getTo <em>To</em>}</li>
 *   <li>{@link kdm.code.gwt.Route#getFrom <em>From</em>}</li>
 *   <li>{@link kdm.code.gwt.Route#getBy <em>By</em>}</li>
 * </ul>
 *
 * @see kdm.code.gwt.GwtPackage#getRoute()
 * @model
 * @generated
 */
public interface Route extends ClassUnit {
	/**
	 * Returns the value of the '<em><b>Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Token</em>' attribute.
	 * @see #setToken(String)
	 * @see kdm.code.gwt.GwtPackage#getRoute_Token()
	 * @model dataType="kdm.core.String"
	 * @generated
	 */
	String getToken();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Route#getToken <em>Token</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Token</em>' attribute.
	 * @see #getToken()
	 * @generated
	 */
	void setToken(String value);

	/**
	 * Returns the value of the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To</em>' reference.
	 * @see #setTo(Page)
	 * @see kdm.code.gwt.GwtPackage#getRoute_To()
	 * @model
	 * @generated
	 */
	Page getTo();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Route#getTo <em>To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To</em>' reference.
	 * @see #getTo()
	 * @generated
	 */
	void setTo(Page value);

	/**
	 * Returns the value of the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From</em>' reference.
	 * @see #setFrom(Page)
	 * @see kdm.code.gwt.GwtPackage#getRoute_From()
	 * @model
	 * @generated
	 */
	Page getFrom();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Route#getFrom <em>From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>From</em>' reference.
	 * @see #getFrom()
	 * @generated
	 */
	void setFrom(Page value);

	/**
	 * Returns the value of the '<em><b>By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>By</em>' reference.
	 * @see #setBy(Widget)
	 * @see kdm.code.gwt.GwtPackage#getRoute_By()
	 * @model
	 * @generated
	 */
	Widget getBy();

	/**
	 * Sets the value of the '{@link kdm.code.gwt.Route#getBy <em>By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>By</em>' reference.
	 * @see #getBy()
	 * @generated
	 */
	void setBy(Widget value);

} // Route
