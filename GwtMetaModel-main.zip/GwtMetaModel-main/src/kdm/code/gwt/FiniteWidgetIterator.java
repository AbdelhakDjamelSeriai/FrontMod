/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Finite Widget Iterator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getFiniteWidgetIterator()
 * @model
 * @generated
 */
public interface FiniteWidgetIterator extends Panel {
} // FiniteWidgetIterator
