/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Submit Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSubmitButton()
 * @model
 * @generated
 */
public interface SubmitButton extends Button {
} // SubmitButton
