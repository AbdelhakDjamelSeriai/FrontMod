/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DockPanel;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dock Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DockPanelImpl extends CellPanelImpl implements DockPanel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DockPanelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DOCK_PANEL;
	}

} //DockPanelImpl
