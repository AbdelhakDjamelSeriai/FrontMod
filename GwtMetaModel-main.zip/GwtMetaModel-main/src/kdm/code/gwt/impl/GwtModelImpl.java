/**
 */
package kdm.code.gwt.impl;

import java.util.Collection;

import kdm.code.ClassUnit;
import kdm.code.gwt.Activity;
import kdm.code.gwt.GwtModel;
import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.Page;

import kdm.code.gwt.Place;
import kdm.code.impl.CodeModelImpl;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link kdm.code.gwt.impl.GwtModelImpl#getPages <em>Pages</em>}</li>
 *   <li>{@link kdm.code.gwt.impl.GwtModelImpl#getActivities <em>Activities</em>}</li>
 *   <li>{@link kdm.code.gwt.impl.GwtModelImpl#getPlaces <em>Places</em>}</li>
 *   <li>{@link kdm.code.gwt.impl.GwtModelImpl#getMapper <em>Mapper</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GwtModelImpl extends CodeModelImpl implements GwtModel {
	/**
	 * The cached value of the '{@link #getPages() <em>Pages</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPages()
	 * @generated
	 * @ordered
	 */
	protected EList<Page> pages;

	/**
	 * The cached value of the '{@link #getActivities() <em>Activities</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivities()
	 * @generated
	 * @ordered
	 */
	protected EList<Activity> activities;
	/**
	 * The cached value of the '{@link #getPlaces() <em>Places</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlaces()
	 * @generated
	 * @ordered
	 */
	protected EList<Place> places;

	/**
	 * The cached value of the '{@link #getMapper() <em>Mapper</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMapper()
	 * @generated
	 * @ordered
	 */
	protected EList<ClassUnit> mapper;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GwtModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.GWT_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Page> getPages() {
		if (pages == null) {
			pages = new EObjectResolvingEList<Page>(Page.class, this, GwtPackage.GWT_MODEL__PAGES);
		}
		return pages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Activity> getActivities() {
		if (activities == null) {
			activities = new EObjectResolvingEList<Activity>(Activity.class, this, GwtPackage.GWT_MODEL__ACTIVITIES);
		}
		return activities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Place> getPlaces() {
		if (places == null) {
			places = new EObjectResolvingEList<Place>(Place.class, this, GwtPackage.GWT_MODEL__PLACES);
		}
		return places;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ClassUnit> getMapper() {
		if (mapper == null) {
			mapper = new EObjectResolvingEList<ClassUnit>(ClassUnit.class, this, GwtPackage.GWT_MODEL__MAPPER);
		}
		return mapper;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case GwtPackage.GWT_MODEL__PAGES:
				return getPages();
			case GwtPackage.GWT_MODEL__ACTIVITIES:
				return getActivities();
			case GwtPackage.GWT_MODEL__PLACES:
				return getPlaces();
			case GwtPackage.GWT_MODEL__MAPPER:
				return getMapper();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case GwtPackage.GWT_MODEL__PAGES:
				getPages().clear();
				getPages().addAll((Collection<? extends Page>)newValue);
				return;
			case GwtPackage.GWT_MODEL__ACTIVITIES:
				getActivities().clear();
				getActivities().addAll((Collection<? extends Activity>)newValue);
				return;
			case GwtPackage.GWT_MODEL__PLACES:
				getPlaces().clear();
				getPlaces().addAll((Collection<? extends Place>)newValue);
				return;
			case GwtPackage.GWT_MODEL__MAPPER:
				getMapper().clear();
				getMapper().addAll((Collection<? extends ClassUnit>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case GwtPackage.GWT_MODEL__PAGES:
				getPages().clear();
				return;
			case GwtPackage.GWT_MODEL__ACTIVITIES:
				getActivities().clear();
				return;
			case GwtPackage.GWT_MODEL__PLACES:
				getPlaces().clear();
				return;
			case GwtPackage.GWT_MODEL__MAPPER:
				getMapper().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case GwtPackage.GWT_MODEL__PAGES:
				return pages != null && !pages.isEmpty();
			case GwtPackage.GWT_MODEL__ACTIVITIES:
				return activities != null && !activities.isEmpty();
			case GwtPackage.GWT_MODEL__PLACES:
				return places != null && !places.isEmpty();
			case GwtPackage.GWT_MODEL__MAPPER:
				return mapper != null && !mapper.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //GwtModelImpl
