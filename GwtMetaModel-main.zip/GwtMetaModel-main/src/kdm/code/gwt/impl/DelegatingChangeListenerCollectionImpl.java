/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DelegatingChangeListenerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Delegating Change Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DelegatingChangeListenerCollectionImpl extends ChangeListenerCollectionImpl implements DelegatingChangeListenerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DelegatingChangeListenerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DELEGATING_CHANGE_LISTENER_COLLECTION;
	}

} //DelegatingChangeListenerCollectionImpl
