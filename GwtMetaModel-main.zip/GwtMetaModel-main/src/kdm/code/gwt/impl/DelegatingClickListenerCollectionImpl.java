/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DelegatingClickListenerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Delegating Click Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DelegatingClickListenerCollectionImpl extends ClickListenerCollectionImpl implements DelegatingClickListenerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DelegatingClickListenerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DELEGATING_CLICK_LISTENER_COLLECTION;
	}

} //DelegatingClickListenerCollectionImpl
