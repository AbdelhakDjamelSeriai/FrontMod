/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FocusListener;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Focus Listener</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FocusListenerImpl extends InterfaceUnitImpl implements FocusListener {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FocusListenerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FOCUS_LISTENER;
	}

} //FocusListenerImpl
