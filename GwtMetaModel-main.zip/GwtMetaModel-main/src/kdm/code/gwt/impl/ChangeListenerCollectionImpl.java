/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.ChangeListenerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Change Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ChangeListenerCollectionImpl extends ChangeListenerImpl implements ChangeListenerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ChangeListenerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.CHANGE_LISTENER_COLLECTION;
	}

} //ChangeListenerCollectionImpl
