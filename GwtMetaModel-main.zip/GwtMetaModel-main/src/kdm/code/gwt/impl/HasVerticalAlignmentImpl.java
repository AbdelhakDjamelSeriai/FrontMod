/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HasVerticalAlignment;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Has Vertical Alignment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HasVerticalAlignmentImpl extends InterfaceUnitImpl implements HasVerticalAlignment {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HasVerticalAlignmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HAS_VERTICAL_ALIGNMENT;
	}

} //HasVerticalAlignmentImpl
