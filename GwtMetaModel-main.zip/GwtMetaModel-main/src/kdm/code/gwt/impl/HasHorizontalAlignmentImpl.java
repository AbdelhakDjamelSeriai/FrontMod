/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HasHorizontalAlignment;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Has Horizontal Alignment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HasHorizontalAlignmentImpl extends InterfaceUnitImpl implements HasHorizontalAlignment {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HasHorizontalAlignmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HAS_HORIZONTAL_ALIGNMENT;
	}

} //HasHorizontalAlignmentImpl
