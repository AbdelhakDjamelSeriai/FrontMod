/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HasHTML;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Has HTML</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HasHTMLImpl extends InterfaceUnitImpl implements HasHTML {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HasHTMLImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HAS_HTML;
	}

} //HasHTMLImpl
