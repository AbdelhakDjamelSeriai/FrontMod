/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HasKeyPreview;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Has Key Preview</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HasKeyPreviewImpl extends InterfaceUnitImpl implements HasKeyPreview {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HasKeyPreviewImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HAS_KEY_PREVIEW;
	}

} //HasKeyPreviewImpl
