/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HasDirectionalHtml;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Has Directional Html</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HasDirectionalHtmlImpl extends InterfaceUnitImpl implements HasDirectionalHtml {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HasDirectionalHtmlImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HAS_DIRECTIONAL_HTML;
	}

} //HasDirectionalHtmlImpl
