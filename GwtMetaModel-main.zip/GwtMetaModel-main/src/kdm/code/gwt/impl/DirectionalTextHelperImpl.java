/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DirectionalTextHelper;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Directional Text Helper</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DirectionalTextHelperImpl extends PopupListenerImpl implements DirectionalTextHelper {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DirectionalTextHelperImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DIRECTIONAL_TEXT_HELPER;
	}

} //DirectionalTextHelperImpl
