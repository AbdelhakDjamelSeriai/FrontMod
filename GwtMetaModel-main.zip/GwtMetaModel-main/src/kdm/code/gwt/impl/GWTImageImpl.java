/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GWTImage;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>GWT Image</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GWTImageImpl extends WidgetImpl implements GWTImage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GWTImageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.GWT_IMAGE;
	}

} //GWTImageImpl
