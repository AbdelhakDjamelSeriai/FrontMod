/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DateLabel;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Date Label</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DateLabelImpl extends ValueLabelImpl implements DateLabel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DateLabelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DATE_LABEL;
	}

} //DateLabelImpl
