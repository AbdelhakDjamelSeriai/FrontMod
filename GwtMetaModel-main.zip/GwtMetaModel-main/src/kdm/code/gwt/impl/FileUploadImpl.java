/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FileUpload;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>File Upload</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FileUploadImpl extends FocusWidgetImpl implements FileUpload {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FileUploadImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FILE_UPLOAD;
	}

} //FileUploadImpl
