/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DelegatingFocusListenerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Delegating Focus Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DelegatingFocusListenerCollectionImpl extends FocusListenerCollectionImpl implements DelegatingFocusListenerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DelegatingFocusListenerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DELEGATING_FOCUS_LISTENER_COLLECTION;
	}

} //DelegatingFocusListenerCollectionImpl
