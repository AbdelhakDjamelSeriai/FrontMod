/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.Focusable;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Focusable</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FocusableImpl extends InterfaceUnitImpl implements Focusable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FocusableImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FOCUSABLE;
	}

} //FocusableImpl
