/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class GwtFactoryImpl extends EFactoryImpl implements GwtFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static GwtFactory init() {
		try {
			GwtFactory theGwtFactory = (GwtFactory)EPackage.Registry.INSTANCE.getEFactory(GwtPackage.eNS_URI);
			if (theGwtFactory != null) {
				return theGwtFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new GwtFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GwtFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case GwtPackage.GWT_MODEL: return createGwtModel();
			case GwtPackage.PAGE: return createPage();
			case GwtPackage.UI_OBJECT: return createUIObject();
			case GwtPackage.WIDGET: return createWidget();
			case GwtPackage.ABSTRACT_IMAGE_PROTOTYPE: return createAbstractImagePrototype();
			case GwtPackage.ABSTRACT_NATIVE_SCROLLBAR: return createAbstractNativeScrollbar();
			case GwtPackage.ACCEPTS_ONE_WIDGET: return createAcceptsOneWidget();
			case GwtPackage.ACCESSIBILITY: return createAccessibility();
			case GwtPackage.ANCHOR: return createAnchor();
			case GwtPackage.ANIMATED_LAYOUT: return createAnimatedLayout();
			case GwtPackage.BUTTON: return createButton();
			case GwtPackage.BUTTON_BASE: return createButtonBase();
			case GwtPackage.CAPTION_PANEL: return createCaptionPanel();
			case GwtPackage.CELL_PANEL: return createCellPanel();
			case GwtPackage.CHANGE_LISTENER: return createChangeListener();
			case GwtPackage.CHANGE_LISTENER_COLLECTION: return createChangeListenerCollection();
			case GwtPackage.CHECK_BOX: return createCheckBox();
			case GwtPackage.CLICK_LISTENER: return createClickListener();
			case GwtPackage.CLICK_LISTENER_COLLECTION: return createClickListenerCollection();
			case GwtPackage.COMPLEX_PANEL: return createComplexPanel();
			case GwtPackage.COMPOSITE: return createComposite();
			case GwtPackage.CUSTOM_BUTTON: return createCustomButton();
			case GwtPackage.CUSTOM_SCROLL_PANEL: return createCustomScrollPanel();
			case GwtPackage.DATE_LABEL: return createDateLabel();
			case GwtPackage.DECK_LAYOUT_PANEL: return createDeckLayoutPanel();
			case GwtPackage.DECK_PANEL: return createDeckPanel();
			case GwtPackage.DECORATED_POPUP_PANEL: return createDecoratedPopupPanel();
			case GwtPackage.DECORATED_STACK_PANEL: return createDecoratedStackPanel();
			case GwtPackage.DECORATED_TAB_BAR: return createDecoratedTabBar();
			case GwtPackage.DECORATED_TAB_PANEL: return createDecoratedTabPanel();
			case GwtPackage.DECORATOR_PANEL: return createDecoratorPanel();
			case GwtPackage.DELEGATING_CHANGE_LISTENER_COLLECTION: return createDelegatingChangeListenerCollection();
			case GwtPackage.DELEGATING_CLICK_LISTENER_COLLECTION: return createDelegatingClickListenerCollection();
			case GwtPackage.DELEGATING_FOCUS_LISTENER_COLLECTION: return createDelegatingFocusListenerCollection();
			case GwtPackage.DELEGATING_KEYBOARD_LISTENER_COLLECTION: return createDelegatingKeyboardListenerCollection();
			case GwtPackage.DIALOG_BOX: return createDialogBox();
			case GwtPackage.DIRECTIONAL_TEXT_HELPER: return createDirectionalTextHelper();
			case GwtPackage.DISCLOSURE_EVENT: return createDisclosureEvent();
			case GwtPackage.DISCLOSURE_HANDLER: return createDisclosureHandler();
			case GwtPackage.DISCLOSURE_PANEL: return createDisclosurePanel();
			case GwtPackage.DISCLOSURE_PANEL_IMAGES: return createDisclosurePanelImages();
			case GwtPackage.DISCLOSURE_PANEL_IMAGES_RTL: return createDisclosurePanelImagesRTL();
			case GwtPackage.DOCK_LAYOUT_PANEL: return createDockLayoutPanel();
			case GwtPackage.DOCK_PANEL: return createDockPanel();
			case GwtPackage.DOUBLE_BOX: return createDoubleBox();
			case GwtPackage.EVENT_OBJECT: return createEventObject();
			case GwtPackage.FILE_UPLOAD: return createFileUpload();
			case GwtPackage.FINITE_WIDGET_ITERATOR: return createFiniteWidgetIterator();
			case GwtPackage.FIRES_DISCLOSURE_EVENTS: return createFiresDisclosureEvents();
			case GwtPackage.FIRES_FORM_EVENTS: return createFiresFormEvents();
			case GwtPackage.FIRES_SUGGESTION_EVENTS: return createFiresSuggestionEvents();
			case GwtPackage.FLEX_TABLE: return createFlexTable();
			case GwtPackage.FLOW_PANEL: return createFlowPanel();
			case GwtPackage.FOCUS_LISTENER: return createFocusListener();
			case GwtPackage.FOCUS_LISTENER_ADAPTER: return createFocusListenerAdapter();
			case GwtPackage.FOCUS_LISTENER_COLLECTION: return createFocusListenerCollection();
			case GwtPackage.FOCUS_PANEL: return createFocusPanel();
			case GwtPackage.FOCUS_WIDGET: return createFocusWidget();
			case GwtPackage.FOCUSABLE: return createFocusable();
			case GwtPackage.FORM_HANDLER: return createFormHandler();
			case GwtPackage.FORM_HANDLER_COLLECTION: return createFormHandlerCollection();
			case GwtPackage.FORM_PANEL: return createFormPanel();
			case GwtPackage.FORM_SUBMIT_COMPLETE_EVENT: return createFormSubmitCompleteEvent();
			case GwtPackage.FORM_SUBMIT_EVENT: return createFormSubmitEvent();
			case GwtPackage.FRAME: return createFrame();
			case GwtPackage.GRID: return createGrid();
			case GwtPackage.HTML: return createHTML();
			case GwtPackage.HTML_PANEL: return createHTMLPanel();
			case GwtPackage.HTML_TABLE: return createHTMLTable();
			case GwtPackage.HAS_ALIGNMENT: return createHasAlignment();
			case GwtPackage.HAS_ANIMATION: return createHasAnimation();
			case GwtPackage.HAS_AUTO_HORIZONTAL_ALIGNMENT: return createHasAutoHorizontalAlignment();
			case GwtPackage.HAS_CAPTION: return createHasCaption();
			case GwtPackage.HAS_CONSTRAINED_VALUE: return createHasConstrainedValue();
			case GwtPackage.HAS_DIRECTIONAL_HTML: return createHasDirectionalHtml();
			case GwtPackage.HAS_DIRECTIONAL_SAFE_HTML: return createHasDirectionalSafeHtml();
			case GwtPackage.HAS_DIRECTIONAL_TEXT: return createHasDirectionalText();
			case GwtPackage.HAS_ENABLED: return createHasEnabled();
			case GwtPackage.HAS_FOCUS: return createHasFocus();
			case GwtPackage.HAS_HTML: return createHasHTML();
			case GwtPackage.HAS_HORIZONTAL_ALIGNMENT: return createHasHorizontalAlignment();
			case GwtPackage.HAS_HORIZONTAL_SCROLLING: return createHasHorizontalScrolling();
			case GwtPackage.HAS_KEY_PREVIEW: return createHasKeyPreview();
			case GwtPackage.HAS_NAME: return createHasName();
			case GwtPackage.HAS_ONE_WIDGET: return createHasOneWidget();
			case GwtPackage.HAS_SCROLLING: return createHasScrolling();
			case GwtPackage.HAS_TEXT: return createHasText();
			case GwtPackage.HAS_TREE_ITEMS: return createHasTreeItems();
			case GwtPackage.HAS_VALUE: return createHasValue();
			case GwtPackage.HAS_VERTICAL_ALIGNMENT: return createHasVerticalAlignment();
			case GwtPackage.HAS_VERTICAL_SCROLLING: return createHasVerticalScrolling();
			case GwtPackage.HAS_VISIBILITY: return createHasVisibility();
			case GwtPackage.HAS_WIDGETS: return createHasWidgets();
			case GwtPackage.HAS_WORD_WRAP: return createHasWordWrap();
			case GwtPackage.HEADER_PANEL: return createHeaderPanel();
			case GwtPackage.HIDDEN: return createHidden();
			case GwtPackage.HORIZONTAL_PANEL: return createHorizontalPanel();
			case GwtPackage.HORIZONTAL_SCROLLBAR: return createHorizontalScrollbar();
			case GwtPackage.HORIZONTAL_SPLIT_PANEL: return createHorizontalSplitPanel();
			case GwtPackage.HORIZONTAL_SPLIT_PANEL_IMAGES: return createHorizontalSplitPanelImages();
			case GwtPackage.HYPERLINK: return createHyperlink();
			case GwtPackage.GWT_IMAGE: return createGWTImage();
			case GwtPackage.IMAGE_BUNDLE: return createImageBundle();
			case GwtPackage.INDEXED_PANEL: return createIndexedPanel();
			case GwtPackage.INLINE_HTML: return createInlineHTML();
			case GwtPackage.INLINE_HYPERLINK: return createInlineHyperlink();
			case GwtPackage.INLINE_LABEL: return createInlineLabel();
			case GwtPackage.INSERT_PANEL: return createInsertPanel();
			case GwtPackage.INTEGER_BOX: return createIntegerBox();
			case GwtPackage.IS_RENDERABLE: return createIsRenderable();
			case GwtPackage.IS_TREE_ITEM: return createIsTreeItem();
			case GwtPackage.IS_WIDGET: return createIsWidget();
			case GwtPackage.KEYBOARD_LISTENER: return createKeyboardListener();
			case GwtPackage.KEYBOARD_LISTENER_ADAPTER: return createKeyboardListenerAdapter();
			case GwtPackage.KEYBOARD_LISTENER_COLLECTION: return createKeyboardListenerCollection();
			case GwtPackage.LABEL: return createLabel();
			case GwtPackage.LABEL_BASE: return createLabelBase();
			case GwtPackage.LAYOUT_COMMAND: return createLayoutCommand();
			case GwtPackage.LAYOUT_PANEL: return createLayoutPanel();
			case GwtPackage.LAZY_PANEL: return createLazyPanel();
			case GwtPackage.LIST_BOX: return createListBox();
			case GwtPackage.LOAD_LISTENER: return createLoadListener();
			case GwtPackage.LOAD_LISTENER_COLLECTION: return createLoadListenerCollection();
			case GwtPackage.LONG_BOX: return createLongBox();
			case GwtPackage.MENU_BAR: return createMenuBar();
			case GwtPackage.MENU_ITEM: return createMenuItem();
			case GwtPackage.MENU_ITEM_SEPARATOR: return createMenuItemSeparator();
			case GwtPackage.MOUSE_LISTENER: return createMouseListener();
			case GwtPackage.MOUSE_LISTENER_ADAPTER: return createMouseListenerAdapter();
			case GwtPackage.MOUSE_LISTENER_COLLECTION: return createMouseListenerCollection();
			case GwtPackage.MOUSE_WHEEL_LISTENER: return createMouseWheelListener();
			case GwtPackage.MOUSE_WHEEL_LISTENER_COLLECTION: return createMouseWheelListenerCollection();
			case GwtPackage.MOUSE_WHEEL_VELOCITY: return createMouseWheelVelocity();
			case GwtPackage.MULTI_WORD_SUGGEST_ORACLE: return createMultiWordSuggestOracle();
			case GwtPackage.NAMED_FRAME: return createNamedFrame();
			case GwtPackage.NATIVE_HORIZONTAL_SCROLLBAR: return createNativeHorizontalScrollbar();
			case GwtPackage.NATIVE_VERTICAL_SCROLLBAR: return createNativeVerticalScrollbar();
			case GwtPackage.NOTIFICATION_MOLE: return createNotificationMole();
			case GwtPackage.NUMBER_LABEL: return createNumberLabel();
			case GwtPackage.PANEL: return createPanel();
			case GwtPackage.PASSWORD_TEXT_BOX: return createPasswordTextBox();
			case GwtPackage.POPUP_LISTENER: return createPopupListener();
			case GwtPackage.POPUP_LISTENER_COLLECTION: return createPopupListenerCollection();
			case GwtPackage.POPUP_PANEL: return createPopupPanel();
			case GwtPackage.PROVIDES_RESIZE: return createProvidesResize();
			case GwtPackage.PUSH_BUTTON: return createPushButton();
			case GwtPackage.RADIO_BUTTON: return createRadioButton();
			case GwtPackage.RENDERABLE_PANEL: return createRenderablePanel();
			case GwtPackage.REQUIRES_RESIZE: return createRequiresResize();
			case GwtPackage.RESET_BUTTON: return createResetButton();
			case GwtPackage.RESIZE_COMPOSITE: return createResizeComposite();
			case GwtPackage.RESIZE_LAYOUT_PANEL: return createResizeLayoutPanel();
			case GwtPackage.RICH_TEXT_AREA: return createRichTextArea();
			case GwtPackage.ROOT_LAYOUT_PANEL: return createRootLayoutPanel();
			case GwtPackage.ROOT_PANEL: return createRootPanel();
			case GwtPackage.SCROLL_IMPL: return createScrollImpl();
			case GwtPackage.SCROLL_LISTENER: return createScrollListener();
			case GwtPackage.SCROLL_LISTENER_COLLECTION: return createScrollListenerCollection();
			case GwtPackage.SCROLL_PANEL: return createScrollPanel();
			case GwtPackage.SIMPLE_CHECK_BOX: return createSimpleCheckBox();
			case GwtPackage.SIMPLE_LAYOUT_PANEL: return createSimpleLayoutPanel();
			case GwtPackage.SIMPLE_PANEL: return createSimplePanel();
			case GwtPackage.SIMPLE_RADIO_BUTTON: return createSimpleRadioButton();
			case GwtPackage.SOURCES_CHANGE_EVENTS: return createSourcesChangeEvents();
			case GwtPackage.SOURCES_CLICK_EVENTS: return createSourcesClickEvents();
			case GwtPackage.SOURCES_FOCUS_EVENTS: return createSourcesFocusEvents();
			case GwtPackage.SOURCES_KEYBOARD_EVENTS: return createSourcesKeyboardEvents();
			case GwtPackage.SOURCES_LOAD_EVENTS: return createSourcesLoadEvents();
			case GwtPackage.SOURCES_MOUSE_EVENTS: return createSourcesMouseEvents();
			case GwtPackage.SOURCES_MOUSE_WHEEL_EVENTS: return createSourcesMouseWheelEvents();
			case GwtPackage.SOURCES_POPUP_EVENTS: return createSourcesPopupEvents();
			case GwtPackage.SOURCES_SCROLL_EVENTS: return createSourcesScrollEvents();
			case GwtPackage.SOURCES_TAB_EVENTS: return createSourcesTabEvents();
			case GwtPackage.SOURCES_TABLE_EVENTS: return createSourcesTableEvents();
			case GwtPackage.SOURCES_TREE_EVENTS: return createSourcesTreeEvents();
			case GwtPackage.SPLIT_LAYOUT_PANEL: return createSplitLayoutPanel();
			case GwtPackage.SPLIT_PANEL: return createSplitPanel();
			case GwtPackage.STACK_LAYOUT_PANEL: return createStackLayoutPanel();
			case GwtPackage.STACK_PANEL: return createStackPanel();
			case GwtPackage.SUBMIT_BUTTON: return createSubmitButton();
			case GwtPackage.SUGGEST_BOX: return createSuggestBox();
			case GwtPackage.SUGGEST_ORACLE: return createSuggestOracle();
			case GwtPackage.SUGGESTION_EVENT: return createSuggestionEvent();
			case GwtPackage.SUGGESTION_HANDLER: return createSuggestionHandler();
			case GwtPackage.TAB_BAR: return createTabBar();
			case GwtPackage.TAB_LAYOUT_PANEL: return createTabLayoutPanel();
			case GwtPackage.TAB_LISTENER: return createTabListener();
			case GwtPackage.TAB_LISTENER_COLLECTION: return createTabListenerCollection();
			case GwtPackage.TAB_PANEL: return createTabPanel();
			case GwtPackage.TABLE_LISTENER: return createTableListener();
			case GwtPackage.TABLE_LISTENER_COLLECTION: return createTableListenerCollection();
			case GwtPackage.TEXT_AREA: return createTextArea();
			case GwtPackage.TEXT_BOX: return createTextBox();
			case GwtPackage.TEXT_BOX_BASE: return createTextBoxBase();
			case GwtPackage.TOGGLE_BUTTON: return createToggleButton();
			case GwtPackage.TREE: return createTree();
			case GwtPackage.TREE_IMAGES: return createTreeImages();
			case GwtPackage.TREE_ITEM: return createTreeItem();
			case GwtPackage.TREE_LISTENER: return createTreeListener();
			case GwtPackage.TREE_LISTENER_COLLECTION: return createTreeListenerCollection();
			case GwtPackage.VALUE_BOX: return createValueBox();
			case GwtPackage.VALUE_BOX_BASE: return createValueBoxBase();
			case GwtPackage.VALUE_LABEL: return createValueLabel();
			case GwtPackage.VALUE_LIST_BOX: return createValueListBox();
			case GwtPackage.VALUE_PICKER: return createValuePicker();
			case GwtPackage.VERTICAL_PANEL: return createVerticalPanel();
			case GwtPackage.VERTICAL_SCROLLBAR: return createVerticalScrollbar();
			case GwtPackage.VERTICAL_SPLIT_PANEL: return createVerticalSplitPanel();
			case GwtPackage.VERTICAL_SPLIT_PANEL_IMAGES: return createVerticalSplitPanelImages();
			case GwtPackage.WIDGET_COLLECTION: return createWidgetCollection();
			case GwtPackage.WIDGET_ITERATORS: return createWidgetIterators();
			case GwtPackage.ABSOLUTE_PANEL: return createAbsolutePanel();
			case GwtPackage.DATE_PICKER: return createDatePicker();
			case GwtPackage.ROUTE: return createRoute();
			case GwtPackage.CONTROLLER_HISTORY: return createControllerHistory();
			case GwtPackage.ACTIVITY: return createActivity();
			case GwtPackage.PLACE: return createPlace();
			case GwtPackage.ROUTE_PLACE: return createRoutePlace();
			case GwtPackage.ACTIVITY_MAPPER: return createActivityMapper();
			case GwtPackage.CELL_TABLE: return createCellTable();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GwtModel createGwtModel() {
		GwtModelImpl gwtModel = new GwtModelImpl();
		return gwtModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Page createPage() {
		PageImpl page = new PageImpl();
		return page;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UIObject createUIObject() {
		UIObjectImpl uiObject = new UIObjectImpl();
		return uiObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Widget createWidget() {
		WidgetImpl widget = new WidgetImpl();
		return widget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AbstractImagePrototype createAbstractImagePrototype() {
		AbstractImagePrototypeImpl abstractImagePrototype = new AbstractImagePrototypeImpl();
		return abstractImagePrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AbstractNativeScrollbar createAbstractNativeScrollbar() {
		AbstractNativeScrollbarImpl abstractNativeScrollbar = new AbstractNativeScrollbarImpl();
		return abstractNativeScrollbar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AcceptsOneWidget createAcceptsOneWidget() {
		AcceptsOneWidgetImpl acceptsOneWidget = new AcceptsOneWidgetImpl();
		return acceptsOneWidget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Accessibility createAccessibility() {
		AccessibilityImpl accessibility = new AccessibilityImpl();
		return accessibility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Anchor createAnchor() {
		AnchorImpl anchor = new AnchorImpl();
		return anchor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AnimatedLayout createAnimatedLayout() {
		AnimatedLayoutImpl animatedLayout = new AnimatedLayoutImpl();
		return animatedLayout;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Button createButton() {
		ButtonImpl button = new ButtonImpl();
		return button;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ButtonBase createButtonBase() {
		ButtonBaseImpl buttonBase = new ButtonBaseImpl();
		return buttonBase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CaptionPanel createCaptionPanel() {
		CaptionPanelImpl captionPanel = new CaptionPanelImpl();
		return captionPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CellPanel createCellPanel() {
		CellPanelImpl cellPanel = new CellPanelImpl();
		return cellPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ChangeListener createChangeListener() {
		ChangeListenerImpl changeListener = new ChangeListenerImpl();
		return changeListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ChangeListenerCollection createChangeListenerCollection() {
		ChangeListenerCollectionImpl changeListenerCollection = new ChangeListenerCollectionImpl();
		return changeListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CheckBox createCheckBox() {
		CheckBoxImpl checkBox = new CheckBoxImpl();
		return checkBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ClickListener createClickListener() {
		ClickListenerImpl clickListener = new ClickListenerImpl();
		return clickListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ClickListenerCollection createClickListenerCollection() {
		ClickListenerCollectionImpl clickListenerCollection = new ClickListenerCollectionImpl();
		return clickListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ComplexPanel createComplexPanel() {
		ComplexPanelImpl complexPanel = new ComplexPanelImpl();
		return complexPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Composite createComposite() {
		CompositeImpl composite = new CompositeImpl();
		return composite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CustomButton createCustomButton() {
		CustomButtonImpl customButton = new CustomButtonImpl();
		return customButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CustomScrollPanel createCustomScrollPanel() {
		CustomScrollPanelImpl customScrollPanel = new CustomScrollPanelImpl();
		return customScrollPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DateLabel createDateLabel() {
		DateLabelImpl dateLabel = new DateLabelImpl();
		return dateLabel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DeckLayoutPanel createDeckLayoutPanel() {
		DeckLayoutPanelImpl deckLayoutPanel = new DeckLayoutPanelImpl();
		return deckLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DeckPanel createDeckPanel() {
		DeckPanelImpl deckPanel = new DeckPanelImpl();
		return deckPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DecoratedPopupPanel createDecoratedPopupPanel() {
		DecoratedPopupPanelImpl decoratedPopupPanel = new DecoratedPopupPanelImpl();
		return decoratedPopupPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DecoratedStackPanel createDecoratedStackPanel() {
		DecoratedStackPanelImpl decoratedStackPanel = new DecoratedStackPanelImpl();
		return decoratedStackPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DecoratedTabBar createDecoratedTabBar() {
		DecoratedTabBarImpl decoratedTabBar = new DecoratedTabBarImpl();
		return decoratedTabBar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DecoratedTabPanel createDecoratedTabPanel() {
		DecoratedTabPanelImpl decoratedTabPanel = new DecoratedTabPanelImpl();
		return decoratedTabPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DecoratorPanel createDecoratorPanel() {
		DecoratorPanelImpl decoratorPanel = new DecoratorPanelImpl();
		return decoratorPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DelegatingChangeListenerCollection createDelegatingChangeListenerCollection() {
		DelegatingChangeListenerCollectionImpl delegatingChangeListenerCollection = new DelegatingChangeListenerCollectionImpl();
		return delegatingChangeListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DelegatingClickListenerCollection createDelegatingClickListenerCollection() {
		DelegatingClickListenerCollectionImpl delegatingClickListenerCollection = new DelegatingClickListenerCollectionImpl();
		return delegatingClickListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DelegatingFocusListenerCollection createDelegatingFocusListenerCollection() {
		DelegatingFocusListenerCollectionImpl delegatingFocusListenerCollection = new DelegatingFocusListenerCollectionImpl();
		return delegatingFocusListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DelegatingKeyboardListenerCollection createDelegatingKeyboardListenerCollection() {
		DelegatingKeyboardListenerCollectionImpl delegatingKeyboardListenerCollection = new DelegatingKeyboardListenerCollectionImpl();
		return delegatingKeyboardListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DialogBox createDialogBox() {
		DialogBoxImpl dialogBox = new DialogBoxImpl();
		return dialogBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DirectionalTextHelper createDirectionalTextHelper() {
		DirectionalTextHelperImpl directionalTextHelper = new DirectionalTextHelperImpl();
		return directionalTextHelper;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DisclosureEvent createDisclosureEvent() {
		DisclosureEventImpl disclosureEvent = new DisclosureEventImpl();
		return disclosureEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DisclosureHandler createDisclosureHandler() {
		DisclosureHandlerImpl disclosureHandler = new DisclosureHandlerImpl();
		return disclosureHandler;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DisclosurePanel createDisclosurePanel() {
		DisclosurePanelImpl disclosurePanel = new DisclosurePanelImpl();
		return disclosurePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DisclosurePanelImages createDisclosurePanelImages() {
		DisclosurePanelImagesImpl disclosurePanelImages = new DisclosurePanelImagesImpl();
		return disclosurePanelImages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DisclosurePanelImagesRTL createDisclosurePanelImagesRTL() {
		DisclosurePanelImagesRTLImpl disclosurePanelImagesRTL = new DisclosurePanelImagesRTLImpl();
		return disclosurePanelImagesRTL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DockLayoutPanel createDockLayoutPanel() {
		DockLayoutPanelImpl dockLayoutPanel = new DockLayoutPanelImpl();
		return dockLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DockPanel createDockPanel() {
		DockPanelImpl dockPanel = new DockPanelImpl();
		return dockPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DoubleBox createDoubleBox() {
		DoubleBoxImpl doubleBox = new DoubleBoxImpl();
		return doubleBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventObject createEventObject() {
		EventObjectImpl eventObject = new EventObjectImpl();
		return eventObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FileUpload createFileUpload() {
		FileUploadImpl fileUpload = new FileUploadImpl();
		return fileUpload;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FiniteWidgetIterator createFiniteWidgetIterator() {
		FiniteWidgetIteratorImpl finiteWidgetIterator = new FiniteWidgetIteratorImpl();
		return finiteWidgetIterator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FiresDisclosureEvents createFiresDisclosureEvents() {
		FiresDisclosureEventsImpl firesDisclosureEvents = new FiresDisclosureEventsImpl();
		return firesDisclosureEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FiresFormEvents createFiresFormEvents() {
		FiresFormEventsImpl firesFormEvents = new FiresFormEventsImpl();
		return firesFormEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FiresSuggestionEvents createFiresSuggestionEvents() {
		FiresSuggestionEventsImpl firesSuggestionEvents = new FiresSuggestionEventsImpl();
		return firesSuggestionEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FlexTable createFlexTable() {
		FlexTableImpl flexTable = new FlexTableImpl();
		return flexTable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FlowPanel createFlowPanel() {
		FlowPanelImpl flowPanel = new FlowPanelImpl();
		return flowPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FocusListener createFocusListener() {
		FocusListenerImpl focusListener = new FocusListenerImpl();
		return focusListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FocusListenerAdapter createFocusListenerAdapter() {
		FocusListenerAdapterImpl focusListenerAdapter = new FocusListenerAdapterImpl();
		return focusListenerAdapter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FocusListenerCollection createFocusListenerCollection() {
		FocusListenerCollectionImpl focusListenerCollection = new FocusListenerCollectionImpl();
		return focusListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FocusPanel createFocusPanel() {
		FocusPanelImpl focusPanel = new FocusPanelImpl();
		return focusPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FocusWidget createFocusWidget() {
		FocusWidgetImpl focusWidget = new FocusWidgetImpl();
		return focusWidget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Focusable createFocusable() {
		FocusableImpl focusable = new FocusableImpl();
		return focusable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FormHandler createFormHandler() {
		FormHandlerImpl formHandler = new FormHandlerImpl();
		return formHandler;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FormHandlerCollection createFormHandlerCollection() {
		FormHandlerCollectionImpl formHandlerCollection = new FormHandlerCollectionImpl();
		return formHandlerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FormPanel createFormPanel() {
		FormPanelImpl formPanel = new FormPanelImpl();
		return formPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FormSubmitCompleteEvent createFormSubmitCompleteEvent() {
		FormSubmitCompleteEventImpl formSubmitCompleteEvent = new FormSubmitCompleteEventImpl();
		return formSubmitCompleteEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FormSubmitEvent createFormSubmitEvent() {
		FormSubmitEventImpl formSubmitEvent = new FormSubmitEventImpl();
		return formSubmitEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Frame createFrame() {
		FrameImpl frame = new FrameImpl();
		return frame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Grid createGrid() {
		GridImpl grid = new GridImpl();
		return grid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HTML createHTML() {
		HTMLImpl html = new HTMLImpl();
		return html;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HTMLPanel createHTMLPanel() {
		HTMLPanelImpl htmlPanel = new HTMLPanelImpl();
		return htmlPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HTMLTable createHTMLTable() {
		HTMLTableImpl htmlTable = new HTMLTableImpl();
		return htmlTable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasAlignment createHasAlignment() {
		HasAlignmentImpl hasAlignment = new HasAlignmentImpl();
		return hasAlignment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasAnimation createHasAnimation() {
		HasAnimationImpl hasAnimation = new HasAnimationImpl();
		return hasAnimation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasAutoHorizontalAlignment createHasAutoHorizontalAlignment() {
		HasAutoHorizontalAlignmentImpl hasAutoHorizontalAlignment = new HasAutoHorizontalAlignmentImpl();
		return hasAutoHorizontalAlignment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasCaption createHasCaption() {
		HasCaptionImpl hasCaption = new HasCaptionImpl();
		return hasCaption;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasConstrainedValue createHasConstrainedValue() {
		HasConstrainedValueImpl hasConstrainedValue = new HasConstrainedValueImpl();
		return hasConstrainedValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasDirectionalHtml createHasDirectionalHtml() {
		HasDirectionalHtmlImpl hasDirectionalHtml = new HasDirectionalHtmlImpl();
		return hasDirectionalHtml;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasDirectionalSafeHtml createHasDirectionalSafeHtml() {
		HasDirectionalSafeHtmlImpl hasDirectionalSafeHtml = new HasDirectionalSafeHtmlImpl();
		return hasDirectionalSafeHtml;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasDirectionalText createHasDirectionalText() {
		HasDirectionalTextImpl hasDirectionalText = new HasDirectionalTextImpl();
		return hasDirectionalText;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasEnabled createHasEnabled() {
		HasEnabledImpl hasEnabled = new HasEnabledImpl();
		return hasEnabled;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasFocus createHasFocus() {
		HasFocusImpl hasFocus = new HasFocusImpl();
		return hasFocus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasHTML createHasHTML() {
		HasHTMLImpl hasHTML = new HasHTMLImpl();
		return hasHTML;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasHorizontalAlignment createHasHorizontalAlignment() {
		HasHorizontalAlignmentImpl hasHorizontalAlignment = new HasHorizontalAlignmentImpl();
		return hasHorizontalAlignment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasHorizontalScrolling createHasHorizontalScrolling() {
		HasHorizontalScrollingImpl hasHorizontalScrolling = new HasHorizontalScrollingImpl();
		return hasHorizontalScrolling;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasKeyPreview createHasKeyPreview() {
		HasKeyPreviewImpl hasKeyPreview = new HasKeyPreviewImpl();
		return hasKeyPreview;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasName createHasName() {
		HasNameImpl hasName = new HasNameImpl();
		return hasName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasOneWidget createHasOneWidget() {
		HasOneWidgetImpl hasOneWidget = new HasOneWidgetImpl();
		return hasOneWidget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasScrolling createHasScrolling() {
		HasScrollingImpl hasScrolling = new HasScrollingImpl();
		return hasScrolling;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasText createHasText() {
		HasTextImpl hasText = new HasTextImpl();
		return hasText;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasTreeItems createHasTreeItems() {
		HasTreeItemsImpl hasTreeItems = new HasTreeItemsImpl();
		return hasTreeItems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasValue createHasValue() {
		HasValueImpl hasValue = new HasValueImpl();
		return hasValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasVerticalAlignment createHasVerticalAlignment() {
		HasVerticalAlignmentImpl hasVerticalAlignment = new HasVerticalAlignmentImpl();
		return hasVerticalAlignment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasVerticalScrolling createHasVerticalScrolling() {
		HasVerticalScrollingImpl hasVerticalScrolling = new HasVerticalScrollingImpl();
		return hasVerticalScrolling;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasVisibility createHasVisibility() {
		HasVisibilityImpl hasVisibility = new HasVisibilityImpl();
		return hasVisibility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasWidgets createHasWidgets() {
		HasWidgetsImpl hasWidgets = new HasWidgetsImpl();
		return hasWidgets;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HasWordWrap createHasWordWrap() {
		HasWordWrapImpl hasWordWrap = new HasWordWrapImpl();
		return hasWordWrap;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HeaderPanel createHeaderPanel() {
		HeaderPanelImpl headerPanel = new HeaderPanelImpl();
		return headerPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Hidden createHidden() {
		HiddenImpl hidden = new HiddenImpl();
		return hidden;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HorizontalPanel createHorizontalPanel() {
		HorizontalPanelImpl horizontalPanel = new HorizontalPanelImpl();
		return horizontalPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HorizontalScrollbar createHorizontalScrollbar() {
		HorizontalScrollbarImpl horizontalScrollbar = new HorizontalScrollbarImpl();
		return horizontalScrollbar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HorizontalSplitPanel createHorizontalSplitPanel() {
		HorizontalSplitPanelImpl horizontalSplitPanel = new HorizontalSplitPanelImpl();
		return horizontalSplitPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HorizontalSplitPanelImages createHorizontalSplitPanelImages() {
		HorizontalSplitPanelImagesImpl horizontalSplitPanelImages = new HorizontalSplitPanelImagesImpl();
		return horizontalSplitPanelImages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Hyperlink createHyperlink() {
		HyperlinkImpl hyperlink = new HyperlinkImpl();
		return hyperlink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GWTImage createGWTImage() {
		GWTImageImpl gwtImage = new GWTImageImpl();
		return gwtImage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ImageBundle createImageBundle() {
		ImageBundleImpl imageBundle = new ImageBundleImpl();
		return imageBundle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IndexedPanel createIndexedPanel() {
		IndexedPanelImpl indexedPanel = new IndexedPanelImpl();
		return indexedPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InlineHTML createInlineHTML() {
		InlineHTMLImpl inlineHTML = new InlineHTMLImpl();
		return inlineHTML;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InlineHyperlink createInlineHyperlink() {
		InlineHyperlinkImpl inlineHyperlink = new InlineHyperlinkImpl();
		return inlineHyperlink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InlineLabel createInlineLabel() {
		InlineLabelImpl inlineLabel = new InlineLabelImpl();
		return inlineLabel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InsertPanel createInsertPanel() {
		InsertPanelImpl insertPanel = new InsertPanelImpl();
		return insertPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IntegerBox createIntegerBox() {
		IntegerBoxImpl integerBox = new IntegerBoxImpl();
		return integerBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IsRenderable createIsRenderable() {
		IsRenderableImpl isRenderable = new IsRenderableImpl();
		return isRenderable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IsTreeItem createIsTreeItem() {
		IsTreeItemImpl isTreeItem = new IsTreeItemImpl();
		return isTreeItem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IsWidget createIsWidget() {
		IsWidgetImpl isWidget = new IsWidgetImpl();
		return isWidget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public KeyboardListener createKeyboardListener() {
		KeyboardListenerImpl keyboardListener = new KeyboardListenerImpl();
		return keyboardListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public KeyboardListenerAdapter createKeyboardListenerAdapter() {
		KeyboardListenerAdapterImpl keyboardListenerAdapter = new KeyboardListenerAdapterImpl();
		return keyboardListenerAdapter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public KeyboardListenerCollection createKeyboardListenerCollection() {
		KeyboardListenerCollectionImpl keyboardListenerCollection = new KeyboardListenerCollectionImpl();
		return keyboardListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Label createLabel() {
		LabelImpl label = new LabelImpl();
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LabelBase createLabelBase() {
		LabelBaseImpl labelBase = new LabelBaseImpl();
		return labelBase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LayoutCommand createLayoutCommand() {
		LayoutCommandImpl layoutCommand = new LayoutCommandImpl();
		return layoutCommand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LayoutPanel createLayoutPanel() {
		LayoutPanelImpl layoutPanel = new LayoutPanelImpl();
		return layoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LazyPanel createLazyPanel() {
		LazyPanelImpl lazyPanel = new LazyPanelImpl();
		return lazyPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ListBox createListBox() {
		ListBoxImpl listBox = new ListBoxImpl();
		return listBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LoadListener createLoadListener() {
		LoadListenerImpl loadListener = new LoadListenerImpl();
		return loadListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LoadListenerCollection createLoadListenerCollection() {
		LoadListenerCollectionImpl loadListenerCollection = new LoadListenerCollectionImpl();
		return loadListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LongBox createLongBox() {
		LongBoxImpl longBox = new LongBoxImpl();
		return longBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MenuBar createMenuBar() {
		MenuBarImpl menuBar = new MenuBarImpl();
		return menuBar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MenuItem createMenuItem() {
		MenuItemImpl menuItem = new MenuItemImpl();
		return menuItem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MenuItemSeparator createMenuItemSeparator() {
		MenuItemSeparatorImpl menuItemSeparator = new MenuItemSeparatorImpl();
		return menuItemSeparator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MouseListener createMouseListener() {
		MouseListenerImpl mouseListener = new MouseListenerImpl();
		return mouseListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MouseListenerAdapter createMouseListenerAdapter() {
		MouseListenerAdapterImpl mouseListenerAdapter = new MouseListenerAdapterImpl();
		return mouseListenerAdapter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MouseListenerCollection createMouseListenerCollection() {
		MouseListenerCollectionImpl mouseListenerCollection = new MouseListenerCollectionImpl();
		return mouseListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MouseWheelListener createMouseWheelListener() {
		MouseWheelListenerImpl mouseWheelListener = new MouseWheelListenerImpl();
		return mouseWheelListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MouseWheelListenerCollection createMouseWheelListenerCollection() {
		MouseWheelListenerCollectionImpl mouseWheelListenerCollection = new MouseWheelListenerCollectionImpl();
		return mouseWheelListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MouseWheelVelocity createMouseWheelVelocity() {
		MouseWheelVelocityImpl mouseWheelVelocity = new MouseWheelVelocityImpl();
		return mouseWheelVelocity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MultiWordSuggestOracle createMultiWordSuggestOracle() {
		MultiWordSuggestOracleImpl multiWordSuggestOracle = new MultiWordSuggestOracleImpl();
		return multiWordSuggestOracle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NamedFrame createNamedFrame() {
		NamedFrameImpl namedFrame = new NamedFrameImpl();
		return namedFrame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NativeHorizontalScrollbar createNativeHorizontalScrollbar() {
		NativeHorizontalScrollbarImpl nativeHorizontalScrollbar = new NativeHorizontalScrollbarImpl();
		return nativeHorizontalScrollbar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NativeVerticalScrollbar createNativeVerticalScrollbar() {
		NativeVerticalScrollbarImpl nativeVerticalScrollbar = new NativeVerticalScrollbarImpl();
		return nativeVerticalScrollbar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationMole createNotificationMole() {
		NotificationMoleImpl notificationMole = new NotificationMoleImpl();
		return notificationMole;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NumberLabel createNumberLabel() {
		NumberLabelImpl numberLabel = new NumberLabelImpl();
		return numberLabel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Panel createPanel() {
		PanelImpl panel = new PanelImpl();
		return panel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PasswordTextBox createPasswordTextBox() {
		PasswordTextBoxImpl passwordTextBox = new PasswordTextBoxImpl();
		return passwordTextBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PopupListener createPopupListener() {
		PopupListenerImpl popupListener = new PopupListenerImpl();
		return popupListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PopupListenerCollection createPopupListenerCollection() {
		PopupListenerCollectionImpl popupListenerCollection = new PopupListenerCollectionImpl();
		return popupListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PopupPanel createPopupPanel() {
		PopupPanelImpl popupPanel = new PopupPanelImpl();
		return popupPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ProvidesResize createProvidesResize() {
		ProvidesResizeImpl providesResize = new ProvidesResizeImpl();
		return providesResize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PushButton createPushButton() {
		PushButtonImpl pushButton = new PushButtonImpl();
		return pushButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RadioButton createRadioButton() {
		RadioButtonImpl radioButton = new RadioButtonImpl();
		return radioButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RenderablePanel createRenderablePanel() {
		RenderablePanelImpl renderablePanel = new RenderablePanelImpl();
		return renderablePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequiresResize createRequiresResize() {
		RequiresResizeImpl requiresResize = new RequiresResizeImpl();
		return requiresResize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResetButton createResetButton() {
		ResetButtonImpl resetButton = new ResetButtonImpl();
		return resetButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResizeComposite createResizeComposite() {
		ResizeCompositeImpl resizeComposite = new ResizeCompositeImpl();
		return resizeComposite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResizeLayoutPanel createResizeLayoutPanel() {
		ResizeLayoutPanelImpl resizeLayoutPanel = new ResizeLayoutPanelImpl();
		return resizeLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RichTextArea createRichTextArea() {
		RichTextAreaImpl richTextArea = new RichTextAreaImpl();
		return richTextArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RootLayoutPanel createRootLayoutPanel() {
		RootLayoutPanelImpl rootLayoutPanel = new RootLayoutPanelImpl();
		return rootLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RootPanel createRootPanel() {
		RootPanelImpl rootPanel = new RootPanelImpl();
		return rootPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ScrollImpl createScrollImpl() {
		ScrollImplImpl scrollImpl = new ScrollImplImpl();
		return scrollImpl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ScrollListener createScrollListener() {
		ScrollListenerImpl scrollListener = new ScrollListenerImpl();
		return scrollListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ScrollListenerCollection createScrollListenerCollection() {
		ScrollListenerCollectionImpl scrollListenerCollection = new ScrollListenerCollectionImpl();
		return scrollListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ScrollPanel createScrollPanel() {
		ScrollPanelImpl scrollPanel = new ScrollPanelImpl();
		return scrollPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SimpleCheckBox createSimpleCheckBox() {
		SimpleCheckBoxImpl simpleCheckBox = new SimpleCheckBoxImpl();
		return simpleCheckBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SimpleLayoutPanel createSimpleLayoutPanel() {
		SimpleLayoutPanelImpl simpleLayoutPanel = new SimpleLayoutPanelImpl();
		return simpleLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SimplePanel createSimplePanel() {
		SimplePanelImpl simplePanel = new SimplePanelImpl();
		return simplePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SimpleRadioButton createSimpleRadioButton() {
		SimpleRadioButtonImpl simpleRadioButton = new SimpleRadioButtonImpl();
		return simpleRadioButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesChangeEvents createSourcesChangeEvents() {
		SourcesChangeEventsImpl sourcesChangeEvents = new SourcesChangeEventsImpl();
		return sourcesChangeEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesClickEvents createSourcesClickEvents() {
		SourcesClickEventsImpl sourcesClickEvents = new SourcesClickEventsImpl();
		return sourcesClickEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesFocusEvents createSourcesFocusEvents() {
		SourcesFocusEventsImpl sourcesFocusEvents = new SourcesFocusEventsImpl();
		return sourcesFocusEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesKeyboardEvents createSourcesKeyboardEvents() {
		SourcesKeyboardEventsImpl sourcesKeyboardEvents = new SourcesKeyboardEventsImpl();
		return sourcesKeyboardEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesLoadEvents createSourcesLoadEvents() {
		SourcesLoadEventsImpl sourcesLoadEvents = new SourcesLoadEventsImpl();
		return sourcesLoadEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesMouseEvents createSourcesMouseEvents() {
		SourcesMouseEventsImpl sourcesMouseEvents = new SourcesMouseEventsImpl();
		return sourcesMouseEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesMouseWheelEvents createSourcesMouseWheelEvents() {
		SourcesMouseWheelEventsImpl sourcesMouseWheelEvents = new SourcesMouseWheelEventsImpl();
		return sourcesMouseWheelEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesPopupEvents createSourcesPopupEvents() {
		SourcesPopupEventsImpl sourcesPopupEvents = new SourcesPopupEventsImpl();
		return sourcesPopupEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesScrollEvents createSourcesScrollEvents() {
		SourcesScrollEventsImpl sourcesScrollEvents = new SourcesScrollEventsImpl();
		return sourcesScrollEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesTabEvents createSourcesTabEvents() {
		SourcesTabEventsImpl sourcesTabEvents = new SourcesTabEventsImpl();
		return sourcesTabEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesTableEvents createSourcesTableEvents() {
		SourcesTableEventsImpl sourcesTableEvents = new SourcesTableEventsImpl();
		return sourcesTableEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SourcesTreeEvents createSourcesTreeEvents() {
		SourcesTreeEventsImpl sourcesTreeEvents = new SourcesTreeEventsImpl();
		return sourcesTreeEvents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SplitLayoutPanel createSplitLayoutPanel() {
		SplitLayoutPanelImpl splitLayoutPanel = new SplitLayoutPanelImpl();
		return splitLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SplitPanel createSplitPanel() {
		SplitPanelImpl splitPanel = new SplitPanelImpl();
		return splitPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StackLayoutPanel createStackLayoutPanel() {
		StackLayoutPanelImpl stackLayoutPanel = new StackLayoutPanelImpl();
		return stackLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StackPanel createStackPanel() {
		StackPanelImpl stackPanel = new StackPanelImpl();
		return stackPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SubmitButton createSubmitButton() {
		SubmitButtonImpl submitButton = new SubmitButtonImpl();
		return submitButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SuggestBox createSuggestBox() {
		SuggestBoxImpl suggestBox = new SuggestBoxImpl();
		return suggestBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SuggestOracle createSuggestOracle() {
		SuggestOracleImpl suggestOracle = new SuggestOracleImpl();
		return suggestOracle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SuggestionEvent createSuggestionEvent() {
		SuggestionEventImpl suggestionEvent = new SuggestionEventImpl();
		return suggestionEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SuggestionHandler createSuggestionHandler() {
		SuggestionHandlerImpl suggestionHandler = new SuggestionHandlerImpl();
		return suggestionHandler;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TabBar createTabBar() {
		TabBarImpl tabBar = new TabBarImpl();
		return tabBar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TabLayoutPanel createTabLayoutPanel() {
		TabLayoutPanelImpl tabLayoutPanel = new TabLayoutPanelImpl();
		return tabLayoutPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TabListener createTabListener() {
		TabListenerImpl tabListener = new TabListenerImpl();
		return tabListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TabListenerCollection createTabListenerCollection() {
		TabListenerCollectionImpl tabListenerCollection = new TabListenerCollectionImpl();
		return tabListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TabPanel createTabPanel() {
		TabPanelImpl tabPanel = new TabPanelImpl();
		return tabPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TableListener createTableListener() {
		TableListenerImpl tableListener = new TableListenerImpl();
		return tableListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TableListenerCollection createTableListenerCollection() {
		TableListenerCollectionImpl tableListenerCollection = new TableListenerCollectionImpl();
		return tableListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TextArea createTextArea() {
		TextAreaImpl textArea = new TextAreaImpl();
		return textArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TextBox createTextBox() {
		TextBoxImpl textBox = new TextBoxImpl();
		return textBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TextBoxBase createTextBoxBase() {
		TextBoxBaseImpl textBoxBase = new TextBoxBaseImpl();
		return textBoxBase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ToggleButton createToggleButton() {
		ToggleButtonImpl toggleButton = new ToggleButtonImpl();
		return toggleButton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Tree createTree() {
		TreeImpl tree = new TreeImpl();
		return tree;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TreeImages createTreeImages() {
		TreeImagesImpl treeImages = new TreeImagesImpl();
		return treeImages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TreeItem createTreeItem() {
		TreeItemImpl treeItem = new TreeItemImpl();
		return treeItem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TreeListener createTreeListener() {
		TreeListenerImpl treeListener = new TreeListenerImpl();
		return treeListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TreeListenerCollection createTreeListenerCollection() {
		TreeListenerCollectionImpl treeListenerCollection = new TreeListenerCollectionImpl();
		return treeListenerCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ValueBox createValueBox() {
		ValueBoxImpl valueBox = new ValueBoxImpl();
		return valueBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ValueBoxBase createValueBoxBase() {
		ValueBoxBaseImpl valueBoxBase = new ValueBoxBaseImpl();
		return valueBoxBase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ValueLabel createValueLabel() {
		ValueLabelImpl valueLabel = new ValueLabelImpl();
		return valueLabel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ValueListBox createValueListBox() {
		ValueListBoxImpl valueListBox = new ValueListBoxImpl();
		return valueListBox;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ValuePicker createValuePicker() {
		ValuePickerImpl valuePicker = new ValuePickerImpl();
		return valuePicker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VerticalPanel createVerticalPanel() {
		VerticalPanelImpl verticalPanel = new VerticalPanelImpl();
		return verticalPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VerticalScrollbar createVerticalScrollbar() {
		VerticalScrollbarImpl verticalScrollbar = new VerticalScrollbarImpl();
		return verticalScrollbar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VerticalSplitPanel createVerticalSplitPanel() {
		VerticalSplitPanelImpl verticalSplitPanel = new VerticalSplitPanelImpl();
		return verticalSplitPanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VerticalSplitPanelImages createVerticalSplitPanelImages() {
		VerticalSplitPanelImagesImpl verticalSplitPanelImages = new VerticalSplitPanelImagesImpl();
		return verticalSplitPanelImages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public WidgetCollection createWidgetCollection() {
		WidgetCollectionImpl widgetCollection = new WidgetCollectionImpl();
		return widgetCollection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public WidgetIterators createWidgetIterators() {
		WidgetIteratorsImpl widgetIterators = new WidgetIteratorsImpl();
		return widgetIterators;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AbsolutePanel createAbsolutePanel() {
		AbsolutePanelImpl absolutePanel = new AbsolutePanelImpl();
		return absolutePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DatePicker createDatePicker() {
		DatePickerImpl datePicker = new DatePickerImpl();
		return datePicker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Route createRoute() {
		RouteImpl route = new RouteImpl();
		return route;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControllerHistory createControllerHistory() {
		ControllerHistoryImpl controllerHistory = new ControllerHistoryImpl();
		return controllerHistory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Activity createActivity() {
		ActivityImpl activity = new ActivityImpl();
		return activity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Place createPlace() {
		PlaceImpl place = new PlaceImpl();
		return place;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoutePlace createRoutePlace() {
		RoutePlaceImpl routePlace = new RoutePlaceImpl();
		return routePlace;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ActivityMapper createActivityMapper() {
		ActivityMapperImpl activityMapper = new ActivityMapperImpl();
		return activityMapper;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CellTable createCellTable() {
		CellTableImpl cellTable = new CellTableImpl();
		return cellTable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GwtPackage getGwtPackage() {
		return (GwtPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static GwtPackage getPackage() {
		return GwtPackage.eINSTANCE;
	}

} //GwtFactoryImpl
