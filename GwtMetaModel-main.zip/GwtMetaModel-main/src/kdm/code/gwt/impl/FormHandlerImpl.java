/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FormHandler;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Form Handler</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FormHandlerImpl extends InterfaceUnitImpl implements FormHandler {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FormHandlerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FORM_HANDLER;
	}

} //FormHandlerImpl
