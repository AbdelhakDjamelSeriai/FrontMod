/**
 */
package kdm.code.gwt.impl;

import kdm.action.ActionPackage;

import kdm.action.impl.ActionPackageImpl;

import kdm.build.BuildPackage;

import kdm.build.impl.BuildPackageImpl;

import kdm.code.CodePackage;
import kdm.code.gwt.*;
import kdm.code.impl.CodePackageImpl;

import kdm.conceptual.ConceptualPackage;

import kdm.conceptual.impl.ConceptualPackageImpl;

import kdm.core.CorePackage;

import kdm.core.impl.CorePackageImpl;

import kdm.data.DataPackage;

import kdm.data.impl.DataPackageImpl;

import kdm.event.EventPackage;

import kdm.event.impl.EventPackageImpl;

import kdm.kdm.KdmPackage;

import kdm.kdm.impl.KdmPackageImpl;

import kdm.platform.PlatformPackage;

import kdm.platform.impl.PlatformPackageImpl;

import kdm.source.SourcePackage;

import kdm.source.impl.SourcePackageImpl;

import kdm.structure.StructurePackage;

import kdm.structure.impl.StructurePackageImpl;

import kdm.ui.UiPackage;

import kdm.ui.impl.UiPackageImpl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class GwtPackageImpl extends EPackageImpl implements GwtPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gwtModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass uiObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass widgetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractImagePrototypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractNativeScrollbarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass acceptsOneWidgetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass accessibilityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass anchorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass animatedLayoutEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass buttonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass buttonBaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass captionPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cellPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass changeListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass changeListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass checkBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clickListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clickListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass complexPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass compositeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass customButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass customScrollPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dateLabelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deckLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deckPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decoratedPopupPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decoratedStackPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decoratedTabBarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decoratedTabPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decoratorPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass delegatingChangeListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass delegatingClickListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass delegatingFocusListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass delegatingKeyboardListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dialogBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass directionalTextHelperEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disclosureEventEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disclosureHandlerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disclosurePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disclosurePanelImagesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disclosurePanelImagesRTLEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dockLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dockPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doubleBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass eventObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fileUploadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass finiteWidgetIteratorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass firesDisclosureEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass firesFormEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass firesSuggestionEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass flexTableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass flowPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass focusListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass focusListenerAdapterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass focusListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass focusPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass focusWidgetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass focusableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass formHandlerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass formHandlerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass formPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass formSubmitCompleteEventEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass formSubmitEventEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass frameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gridEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass htmlEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass htmlPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass htmlTableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasAlignmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasAnimationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasAutoHorizontalAlignmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasCaptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasConstrainedValueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasDirectionalHtmlEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasDirectionalSafeHtmlEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasDirectionalTextEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasEnabledEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasFocusEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasHTMLEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasHorizontalAlignmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasHorizontalScrollingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasKeyPreviewEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasNameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasOneWidgetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasScrollingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasTextEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasTreeItemsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasValueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasVerticalAlignmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasVerticalScrollingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasVisibilityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasWidgetsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hasWordWrapEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass headerPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hiddenEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass horizontalPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass horizontalScrollbarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass horizontalSplitPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass horizontalSplitPanelImagesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hyperlinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gwtImageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass imageBundleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass indexedPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inlineHTMLEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inlineHyperlinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inlineLabelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass insertPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass integerBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass isRenderableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass isTreeItemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass isWidgetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass keyboardListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass keyboardListenerAdapterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass keyboardListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass labelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass labelBaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass layoutCommandEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass layoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lazyPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass listBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass loadListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass loadListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass longBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass menuBarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass menuItemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass menuItemSeparatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mouseListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mouseListenerAdapterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mouseListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mouseWheelListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mouseWheelListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mouseWheelVelocityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass multiWordSuggestOracleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass namedFrameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nativeHorizontalScrollbarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nativeVerticalScrollbarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass notificationMoleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass numberLabelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass panelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass passwordTextBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass popupListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass popupListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass popupPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass providesResizeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pushButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass radioButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass renderablePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass requiresResizeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resetButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resizeCompositeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resizeLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass richTextAreaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rootLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rootPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scrollImplEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scrollListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scrollListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scrollPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleCheckBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simplePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleRadioButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesChangeEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesClickEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesFocusEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesKeyboardEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesLoadEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesMouseEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesMouseWheelEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesPopupEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesScrollEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesTabEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesTableEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourcesTreeEventsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass splitLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass splitPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stackLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stackPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass submitButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass suggestBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass suggestOracleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass suggestionEventEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass suggestionHandlerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tabBarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tabLayoutPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tabListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tabListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tabPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tableListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tableListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass textAreaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass textBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass textBoxBaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass toggleButtonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treeImagesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treeItemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treeListenerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treeListenerCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueBoxBaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueLabelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueListBoxEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valuePickerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass verticalPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass verticalScrollbarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass verticalSplitPanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass verticalSplitPanelImagesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass widgetCollectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass widgetIteratorsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass absolutePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass datePickerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass routeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass controllerHistoryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass activityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass placeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass routePlaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass activityMapperEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cellTableEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see kdm.code.gwt.GwtPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private GwtPackageImpl() {
		super(eNS_URI, GwtFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link GwtPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static GwtPackage init() {
		if (isInited) return (GwtPackage)EPackage.Registry.INSTANCE.getEPackage(GwtPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredGwtPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		GwtPackageImpl theGwtPackage = registeredGwtPackage instanceof GwtPackageImpl ? (GwtPackageImpl)registeredGwtPackage : new GwtPackageImpl();

		isInited = true;

		// Obtain or create and register interdependencies
		Object registeredPackage = EPackage.Registry.INSTANCE.getEPackage(CorePackage.eNS_URI);
		CorePackageImpl theCorePackage = (CorePackageImpl)(registeredPackage instanceof CorePackageImpl ? registeredPackage : CorePackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(KdmPackage.eNS_URI);
		KdmPackageImpl theKdmPackage = (KdmPackageImpl)(registeredPackage instanceof KdmPackageImpl ? registeredPackage : KdmPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(SourcePackage.eNS_URI);
		SourcePackageImpl theSourcePackage = (SourcePackageImpl)(registeredPackage instanceof SourcePackageImpl ? registeredPackage : SourcePackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(CodePackage.eNS_URI);
		CodePackageImpl theCodePackage = (CodePackageImpl)(registeredPackage instanceof CodePackageImpl ? registeredPackage : CodePackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(ActionPackage.eNS_URI);
		ActionPackageImpl theActionPackage = (ActionPackageImpl)(registeredPackage instanceof ActionPackageImpl ? registeredPackage : ActionPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(PlatformPackage.eNS_URI);
		PlatformPackageImpl thePlatformPackage = (PlatformPackageImpl)(registeredPackage instanceof PlatformPackageImpl ? registeredPackage : PlatformPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(BuildPackage.eNS_URI);
		BuildPackageImpl theBuildPackage = (BuildPackageImpl)(registeredPackage instanceof BuildPackageImpl ? registeredPackage : BuildPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(ConceptualPackage.eNS_URI);
		ConceptualPackageImpl theConceptualPackage = (ConceptualPackageImpl)(registeredPackage instanceof ConceptualPackageImpl ? registeredPackage : ConceptualPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(DataPackage.eNS_URI);
		DataPackageImpl theDataPackage = (DataPackageImpl)(registeredPackage instanceof DataPackageImpl ? registeredPackage : DataPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(EventPackage.eNS_URI);
		EventPackageImpl theEventPackage = (EventPackageImpl)(registeredPackage instanceof EventPackageImpl ? registeredPackage : EventPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(StructurePackage.eNS_URI);
		StructurePackageImpl theStructurePackage = (StructurePackageImpl)(registeredPackage instanceof StructurePackageImpl ? registeredPackage : StructurePackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(UiPackage.eNS_URI);
		UiPackageImpl theUiPackage = (UiPackageImpl)(registeredPackage instanceof UiPackageImpl ? registeredPackage : UiPackage.eINSTANCE);

		// Create package meta-data objects
		theGwtPackage.createPackageContents();
		theCorePackage.createPackageContents();
		theKdmPackage.createPackageContents();
		theSourcePackage.createPackageContents();
		theCodePackage.createPackageContents();
		theActionPackage.createPackageContents();
		thePlatformPackage.createPackageContents();
		theBuildPackage.createPackageContents();
		theConceptualPackage.createPackageContents();
		theDataPackage.createPackageContents();
		theEventPackage.createPackageContents();
		theStructurePackage.createPackageContents();
		theUiPackage.createPackageContents();

		// Initialize created meta-data
		theGwtPackage.initializePackageContents();
		theCorePackage.initializePackageContents();
		theKdmPackage.initializePackageContents();
		theSourcePackage.initializePackageContents();
		theCodePackage.initializePackageContents();
		theActionPackage.initializePackageContents();
		thePlatformPackage.initializePackageContents();
		theBuildPackage.initializePackageContents();
		theConceptualPackage.initializePackageContents();
		theDataPackage.initializePackageContents();
		theEventPackage.initializePackageContents();
		theStructurePackage.initializePackageContents();
		theUiPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theGwtPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(GwtPackage.eNS_URI, theGwtPackage);
		return theGwtPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getGwtModel() {
		return gwtModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getGwtModel_Pages() {
		return (EReference)gwtModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getGwtModel_Activities() {
		return (EReference)gwtModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getGwtModel_Places() {
		return (EReference)gwtModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getGwtModel_Mapper() {
		return (EReference)gwtModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPage() {
		return pageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPage_Widgets() {
		return (EReference)pageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPage_Routes() {
		return (EReference)pageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPage_IsKindOfComposite() {
		return (EAttribute)pageEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPage_IsKindOfWidget() {
		return (EAttribute)pageEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPage_TypeOfWidget() {
		return (EAttribute)pageEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getUIObject() {
		return uiObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getWidget() {
		return widgetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getWidget_Actions() {
		return (EReference)widgetEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getWidget_IsContainer() {
		return (EAttribute)widgetEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getWidget_NestedWidgets() {
		return (EReference)widgetEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getWidget_TypeWidget() {
		return (EReference)widgetEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getWidget_Style() {
		return (EAttribute)widgetEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getWidget_ContainerOuterHtml() {
		return (EAttribute)widgetEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getWidget_LeafOuterHtml() {
		return (EAttribute)widgetEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getWidget_IsNewDecoratedWidget() {
		return (EAttribute)widgetEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAbstractImagePrototype() {
		return abstractImagePrototypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAbstractNativeScrollbar() {
		return abstractNativeScrollbarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAcceptsOneWidget() {
		return acceptsOneWidgetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAccessibility() {
		return accessibilityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAnchor() {
		return anchorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAnimatedLayout() {
		return animatedLayoutEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getButton() {
		return buttonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getButtonBase() {
		return buttonBaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCaptionPanel() {
		return captionPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCellPanel() {
		return cellPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getChangeListener() {
		return changeListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getChangeListenerCollection() {
		return changeListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCheckBox() {
		return checkBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getClickListener() {
		return clickListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getClickListenerCollection() {
		return clickListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getComplexPanel() {
		return complexPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getComposite() {
		return compositeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCustomButton() {
		return customButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCustomScrollPanel() {
		return customScrollPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDateLabel() {
		return dateLabelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDeckLayoutPanel() {
		return deckLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDeckPanel() {
		return deckPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDecoratedPopupPanel() {
		return decoratedPopupPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDecoratedStackPanel() {
		return decoratedStackPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDecoratedTabBar() {
		return decoratedTabBarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDecoratedTabPanel() {
		return decoratedTabPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDecoratorPanel() {
		return decoratorPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDelegatingChangeListenerCollection() {
		return delegatingChangeListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDelegatingClickListenerCollection() {
		return delegatingClickListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDelegatingFocusListenerCollection() {
		return delegatingFocusListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDelegatingKeyboardListenerCollection() {
		return delegatingKeyboardListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDialogBox() {
		return dialogBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDirectionalTextHelper() {
		return directionalTextHelperEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDisclosureEvent() {
		return disclosureEventEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDisclosureHandler() {
		return disclosureHandlerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDisclosurePanel() {
		return disclosurePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDisclosurePanelImages() {
		return disclosurePanelImagesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDisclosurePanelImagesRTL() {
		return disclosurePanelImagesRTLEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDockLayoutPanel() {
		return dockLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDockPanel() {
		return dockPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDoubleBox() {
		return doubleBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getEventObject() {
		return eventObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFileUpload() {
		return fileUploadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFiniteWidgetIterator() {
		return finiteWidgetIteratorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFiresDisclosureEvents() {
		return firesDisclosureEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFiresFormEvents() {
		return firesFormEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFiresSuggestionEvents() {
		return firesSuggestionEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFlexTable() {
		return flexTableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFlowPanel() {
		return flowPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFocusListener() {
		return focusListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFocusListenerAdapter() {
		return focusListenerAdapterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFocusListenerCollection() {
		return focusListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFocusPanel() {
		return focusPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFocusWidget() {
		return focusWidgetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFocusable() {
		return focusableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFormHandler() {
		return formHandlerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFormHandlerCollection() {
		return formHandlerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFormPanel() {
		return formPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFormSubmitCompleteEvent() {
		return formSubmitCompleteEventEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFormSubmitEvent() {
		return formSubmitEventEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFrame() {
		return frameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getGrid() {
		return gridEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHTML() {
		return htmlEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHTMLPanel() {
		return htmlPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHTMLTable() {
		return htmlTableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasAlignment() {
		return hasAlignmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasAnimation() {
		return hasAnimationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasAutoHorizontalAlignment() {
		return hasAutoHorizontalAlignmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasCaption() {
		return hasCaptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasConstrainedValue() {
		return hasConstrainedValueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasDirectionalHtml() {
		return hasDirectionalHtmlEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasDirectionalSafeHtml() {
		return hasDirectionalSafeHtmlEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasDirectionalText() {
		return hasDirectionalTextEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasEnabled() {
		return hasEnabledEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasFocus() {
		return hasFocusEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasHTML() {
		return hasHTMLEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasHorizontalAlignment() {
		return hasHorizontalAlignmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasHorizontalScrolling() {
		return hasHorizontalScrollingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasKeyPreview() {
		return hasKeyPreviewEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasName() {
		return hasNameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasOneWidget() {
		return hasOneWidgetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasScrolling() {
		return hasScrollingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasText() {
		return hasTextEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasTreeItems() {
		return hasTreeItemsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasValue() {
		return hasValueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasVerticalAlignment() {
		return hasVerticalAlignmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasVerticalScrolling() {
		return hasVerticalScrollingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasVisibility() {
		return hasVisibilityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasWidgets() {
		return hasWidgetsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHasWordWrap() {
		return hasWordWrapEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHeaderPanel() {
		return headerPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHidden() {
		return hiddenEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHorizontalPanel() {
		return horizontalPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHorizontalScrollbar() {
		return horizontalScrollbarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHorizontalSplitPanel() {
		return horizontalSplitPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHorizontalSplitPanelImages() {
		return horizontalSplitPanelImagesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHyperlink() {
		return hyperlinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getGWTImage() {
		return gwtImageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getImageBundle() {
		return imageBundleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIndexedPanel() {
		return indexedPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInlineHTML() {
		return inlineHTMLEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInlineHyperlink() {
		return inlineHyperlinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInlineLabel() {
		return inlineLabelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInsertPanel() {
		return insertPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIntegerBox() {
		return integerBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIsRenderable() {
		return isRenderableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIsTreeItem() {
		return isTreeItemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIsWidget() {
		return isWidgetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getKeyboardListener() {
		return keyboardListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getKeyboardListenerAdapter() {
		return keyboardListenerAdapterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getKeyboardListenerCollection() {
		return keyboardListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLabel() {
		return labelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLabelBase() {
		return labelBaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLayoutCommand() {
		return layoutCommandEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLayoutPanel() {
		return layoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLazyPanel() {
		return lazyPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getListBox() {
		return listBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLoadListener() {
		return loadListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLoadListenerCollection() {
		return loadListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLongBox() {
		return longBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMenuBar() {
		return menuBarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMenuItem() {
		return menuItemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMenuItemSeparator() {
		return menuItemSeparatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMouseListener() {
		return mouseListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMouseListenerAdapter() {
		return mouseListenerAdapterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMouseListenerCollection() {
		return mouseListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMouseWheelListener() {
		return mouseWheelListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMouseWheelListenerCollection() {
		return mouseWheelListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMouseWheelVelocity() {
		return mouseWheelVelocityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMultiWordSuggestOracle() {
		return multiWordSuggestOracleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNamedFrame() {
		return namedFrameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNativeHorizontalScrollbar() {
		return nativeHorizontalScrollbarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNativeVerticalScrollbar() {
		return nativeVerticalScrollbarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNotificationMole() {
		return notificationMoleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNumberLabel() {
		return numberLabelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPanel() {
		return panelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPasswordTextBox() {
		return passwordTextBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPopupListener() {
		return popupListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPopupListenerCollection() {
		return popupListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPopupPanel() {
		return popupPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getProvidesResize() {
		return providesResizeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPushButton() {
		return pushButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRadioButton() {
		return radioButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRenderablePanel() {
		return renderablePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRequiresResize() {
		return requiresResizeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getResetButton() {
		return resetButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getResizeComposite() {
		return resizeCompositeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getResizeLayoutPanel() {
		return resizeLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRichTextArea() {
		return richTextAreaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRootLayoutPanel() {
		return rootLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRootPanel() {
		return rootPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getScrollImpl() {
		return scrollImplEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getScrollListener() {
		return scrollListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getScrollListenerCollection() {
		return scrollListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getScrollPanel() {
		return scrollPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSimpleCheckBox() {
		return simpleCheckBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSimpleLayoutPanel() {
		return simpleLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSimplePanel() {
		return simplePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSimpleRadioButton() {
		return simpleRadioButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesChangeEvents() {
		return sourcesChangeEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesClickEvents() {
		return sourcesClickEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesFocusEvents() {
		return sourcesFocusEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesKeyboardEvents() {
		return sourcesKeyboardEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesLoadEvents() {
		return sourcesLoadEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesMouseEvents() {
		return sourcesMouseEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesMouseWheelEvents() {
		return sourcesMouseWheelEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesPopupEvents() {
		return sourcesPopupEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesScrollEvents() {
		return sourcesScrollEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesTabEvents() {
		return sourcesTabEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesTableEvents() {
		return sourcesTableEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSourcesTreeEvents() {
		return sourcesTreeEventsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSplitLayoutPanel() {
		return splitLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSplitPanel() {
		return splitPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getStackLayoutPanel() {
		return stackLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getStackPanel() {
		return stackPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSubmitButton() {
		return submitButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSuggestBox() {
		return suggestBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSuggestOracle() {
		return suggestOracleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSuggestionEvent() {
		return suggestionEventEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSuggestionHandler() {
		return suggestionHandlerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTabBar() {
		return tabBarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTabLayoutPanel() {
		return tabLayoutPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTabListener() {
		return tabListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTabListenerCollection() {
		return tabListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTabPanel() {
		return tabPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTableListener() {
		return tableListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTableListenerCollection() {
		return tableListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTextArea() {
		return textAreaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTextBox() {
		return textBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTextBoxBase() {
		return textBoxBaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getToggleButton() {
		return toggleButtonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTree() {
		return treeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTreeImages() {
		return treeImagesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTreeItem() {
		return treeItemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTreeListener() {
		return treeListenerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTreeListenerCollection() {
		return treeListenerCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getValueBox() {
		return valueBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getValueBoxBase() {
		return valueBoxBaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getValueLabel() {
		return valueLabelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getValueListBox() {
		return valueListBoxEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getValuePicker() {
		return valuePickerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVerticalPanel() {
		return verticalPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVerticalScrollbar() {
		return verticalScrollbarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVerticalSplitPanel() {
		return verticalSplitPanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVerticalSplitPanelImages() {
		return verticalSplitPanelImagesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getWidgetCollection() {
		return widgetCollectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getWidgetIterators() {
		return widgetIteratorsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAbsolutePanel() {
		return absolutePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDatePicker() {
		return datePickerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRoute() {
		return routeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRoute_Token() {
		return (EAttribute)routeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRoute_To() {
		return (EReference)routeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRoute_From() {
		return (EReference)routeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRoute_By() {
		return (EReference)routeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getControllerHistory() {
		return controllerHistoryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getControllerHistory_Routes() {
		return (EReference)controllerHistoryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getActivity() {
		return activityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getActivity_Page() {
		return (EReference)activityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getActivity_Routes() {
		return (EReference)activityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPlace() {
		return placeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRoutePlace() {
		return routePlaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRoutePlace_Place() {
		return (EReference)routePlaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRoutePlace_Widget() {
		return (EReference)routePlaceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getActivityMapper() {
		return activityMapperEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCellTable() {
		return cellTableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GwtFactory getGwtFactory() {
		return (GwtFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		gwtModelEClass = createEClass(GWT_MODEL);
		createEReference(gwtModelEClass, GWT_MODEL__PAGES);
		createEReference(gwtModelEClass, GWT_MODEL__ACTIVITIES);
		createEReference(gwtModelEClass, GWT_MODEL__PLACES);
		createEReference(gwtModelEClass, GWT_MODEL__MAPPER);

		pageEClass = createEClass(PAGE);
		createEReference(pageEClass, PAGE__WIDGETS);
		createEReference(pageEClass, PAGE__ROUTES);
		createEAttribute(pageEClass, PAGE__IS_KIND_OF_COMPOSITE);
		createEAttribute(pageEClass, PAGE__IS_KIND_OF_WIDGET);
		createEAttribute(pageEClass, PAGE__TYPE_OF_WIDGET);

		uiObjectEClass = createEClass(UI_OBJECT);

		widgetEClass = createEClass(WIDGET);
		createEReference(widgetEClass, WIDGET__ACTIONS);
		createEAttribute(widgetEClass, WIDGET__IS_CONTAINER);
		createEReference(widgetEClass, WIDGET__NESTED_WIDGETS);
		createEReference(widgetEClass, WIDGET__TYPE_WIDGET);
		createEAttribute(widgetEClass, WIDGET__STYLE);
		createEAttribute(widgetEClass, WIDGET__CONTAINER_OUTER_HTML);
		createEAttribute(widgetEClass, WIDGET__LEAF_OUTER_HTML);
		createEAttribute(widgetEClass, WIDGET__IS_NEW_DECORATED_WIDGET);

		abstractImagePrototypeEClass = createEClass(ABSTRACT_IMAGE_PROTOTYPE);

		abstractNativeScrollbarEClass = createEClass(ABSTRACT_NATIVE_SCROLLBAR);

		acceptsOneWidgetEClass = createEClass(ACCEPTS_ONE_WIDGET);

		accessibilityEClass = createEClass(ACCESSIBILITY);

		anchorEClass = createEClass(ANCHOR);

		animatedLayoutEClass = createEClass(ANIMATED_LAYOUT);

		buttonEClass = createEClass(BUTTON);

		buttonBaseEClass = createEClass(BUTTON_BASE);

		captionPanelEClass = createEClass(CAPTION_PANEL);

		cellPanelEClass = createEClass(CELL_PANEL);

		changeListenerEClass = createEClass(CHANGE_LISTENER);

		changeListenerCollectionEClass = createEClass(CHANGE_LISTENER_COLLECTION);

		checkBoxEClass = createEClass(CHECK_BOX);

		clickListenerEClass = createEClass(CLICK_LISTENER);

		clickListenerCollectionEClass = createEClass(CLICK_LISTENER_COLLECTION);

		complexPanelEClass = createEClass(COMPLEX_PANEL);

		compositeEClass = createEClass(COMPOSITE);

		customButtonEClass = createEClass(CUSTOM_BUTTON);

		customScrollPanelEClass = createEClass(CUSTOM_SCROLL_PANEL);

		dateLabelEClass = createEClass(DATE_LABEL);

		deckLayoutPanelEClass = createEClass(DECK_LAYOUT_PANEL);

		deckPanelEClass = createEClass(DECK_PANEL);

		decoratedPopupPanelEClass = createEClass(DECORATED_POPUP_PANEL);

		decoratedStackPanelEClass = createEClass(DECORATED_STACK_PANEL);

		decoratedTabBarEClass = createEClass(DECORATED_TAB_BAR);

		decoratedTabPanelEClass = createEClass(DECORATED_TAB_PANEL);

		decoratorPanelEClass = createEClass(DECORATOR_PANEL);

		delegatingChangeListenerCollectionEClass = createEClass(DELEGATING_CHANGE_LISTENER_COLLECTION);

		delegatingClickListenerCollectionEClass = createEClass(DELEGATING_CLICK_LISTENER_COLLECTION);

		delegatingFocusListenerCollectionEClass = createEClass(DELEGATING_FOCUS_LISTENER_COLLECTION);

		delegatingKeyboardListenerCollectionEClass = createEClass(DELEGATING_KEYBOARD_LISTENER_COLLECTION);

		dialogBoxEClass = createEClass(DIALOG_BOX);

		directionalTextHelperEClass = createEClass(DIRECTIONAL_TEXT_HELPER);

		disclosureEventEClass = createEClass(DISCLOSURE_EVENT);

		disclosureHandlerEClass = createEClass(DISCLOSURE_HANDLER);

		disclosurePanelEClass = createEClass(DISCLOSURE_PANEL);

		disclosurePanelImagesEClass = createEClass(DISCLOSURE_PANEL_IMAGES);

		disclosurePanelImagesRTLEClass = createEClass(DISCLOSURE_PANEL_IMAGES_RTL);

		dockLayoutPanelEClass = createEClass(DOCK_LAYOUT_PANEL);

		dockPanelEClass = createEClass(DOCK_PANEL);

		doubleBoxEClass = createEClass(DOUBLE_BOX);

		eventObjectEClass = createEClass(EVENT_OBJECT);

		fileUploadEClass = createEClass(FILE_UPLOAD);

		finiteWidgetIteratorEClass = createEClass(FINITE_WIDGET_ITERATOR);

		firesDisclosureEventsEClass = createEClass(FIRES_DISCLOSURE_EVENTS);

		firesFormEventsEClass = createEClass(FIRES_FORM_EVENTS);

		firesSuggestionEventsEClass = createEClass(FIRES_SUGGESTION_EVENTS);

		flexTableEClass = createEClass(FLEX_TABLE);

		flowPanelEClass = createEClass(FLOW_PANEL);

		focusListenerEClass = createEClass(FOCUS_LISTENER);

		focusListenerAdapterEClass = createEClass(FOCUS_LISTENER_ADAPTER);

		focusListenerCollectionEClass = createEClass(FOCUS_LISTENER_COLLECTION);

		focusPanelEClass = createEClass(FOCUS_PANEL);

		focusWidgetEClass = createEClass(FOCUS_WIDGET);

		focusableEClass = createEClass(FOCUSABLE);

		formHandlerEClass = createEClass(FORM_HANDLER);

		formHandlerCollectionEClass = createEClass(FORM_HANDLER_COLLECTION);

		formPanelEClass = createEClass(FORM_PANEL);

		formSubmitCompleteEventEClass = createEClass(FORM_SUBMIT_COMPLETE_EVENT);

		formSubmitEventEClass = createEClass(FORM_SUBMIT_EVENT);

		frameEClass = createEClass(FRAME);

		gridEClass = createEClass(GRID);

		htmlEClass = createEClass(HTML);

		htmlPanelEClass = createEClass(HTML_PANEL);

		htmlTableEClass = createEClass(HTML_TABLE);

		hasAlignmentEClass = createEClass(HAS_ALIGNMENT);

		hasAnimationEClass = createEClass(HAS_ANIMATION);

		hasAutoHorizontalAlignmentEClass = createEClass(HAS_AUTO_HORIZONTAL_ALIGNMENT);

		hasCaptionEClass = createEClass(HAS_CAPTION);

		hasConstrainedValueEClass = createEClass(HAS_CONSTRAINED_VALUE);

		hasDirectionalHtmlEClass = createEClass(HAS_DIRECTIONAL_HTML);

		hasDirectionalSafeHtmlEClass = createEClass(HAS_DIRECTIONAL_SAFE_HTML);

		hasDirectionalTextEClass = createEClass(HAS_DIRECTIONAL_TEXT);

		hasEnabledEClass = createEClass(HAS_ENABLED);

		hasFocusEClass = createEClass(HAS_FOCUS);

		hasHTMLEClass = createEClass(HAS_HTML);

		hasHorizontalAlignmentEClass = createEClass(HAS_HORIZONTAL_ALIGNMENT);

		hasHorizontalScrollingEClass = createEClass(HAS_HORIZONTAL_SCROLLING);

		hasKeyPreviewEClass = createEClass(HAS_KEY_PREVIEW);

		hasNameEClass = createEClass(HAS_NAME);

		hasOneWidgetEClass = createEClass(HAS_ONE_WIDGET);

		hasScrollingEClass = createEClass(HAS_SCROLLING);

		hasTextEClass = createEClass(HAS_TEXT);

		hasTreeItemsEClass = createEClass(HAS_TREE_ITEMS);

		hasValueEClass = createEClass(HAS_VALUE);

		hasVerticalAlignmentEClass = createEClass(HAS_VERTICAL_ALIGNMENT);

		hasVerticalScrollingEClass = createEClass(HAS_VERTICAL_SCROLLING);

		hasVisibilityEClass = createEClass(HAS_VISIBILITY);

		hasWidgetsEClass = createEClass(HAS_WIDGETS);

		hasWordWrapEClass = createEClass(HAS_WORD_WRAP);

		headerPanelEClass = createEClass(HEADER_PANEL);

		hiddenEClass = createEClass(HIDDEN);

		horizontalPanelEClass = createEClass(HORIZONTAL_PANEL);

		horizontalScrollbarEClass = createEClass(HORIZONTAL_SCROLLBAR);

		horizontalSplitPanelEClass = createEClass(HORIZONTAL_SPLIT_PANEL);

		horizontalSplitPanelImagesEClass = createEClass(HORIZONTAL_SPLIT_PANEL_IMAGES);

		hyperlinkEClass = createEClass(HYPERLINK);

		gwtImageEClass = createEClass(GWT_IMAGE);

		imageBundleEClass = createEClass(IMAGE_BUNDLE);

		indexedPanelEClass = createEClass(INDEXED_PANEL);

		inlineHTMLEClass = createEClass(INLINE_HTML);

		inlineHyperlinkEClass = createEClass(INLINE_HYPERLINK);

		inlineLabelEClass = createEClass(INLINE_LABEL);

		insertPanelEClass = createEClass(INSERT_PANEL);

		integerBoxEClass = createEClass(INTEGER_BOX);

		isRenderableEClass = createEClass(IS_RENDERABLE);

		isTreeItemEClass = createEClass(IS_TREE_ITEM);

		isWidgetEClass = createEClass(IS_WIDGET);

		keyboardListenerEClass = createEClass(KEYBOARD_LISTENER);

		keyboardListenerAdapterEClass = createEClass(KEYBOARD_LISTENER_ADAPTER);

		keyboardListenerCollectionEClass = createEClass(KEYBOARD_LISTENER_COLLECTION);

		labelEClass = createEClass(LABEL);

		labelBaseEClass = createEClass(LABEL_BASE);

		layoutCommandEClass = createEClass(LAYOUT_COMMAND);

		layoutPanelEClass = createEClass(LAYOUT_PANEL);

		lazyPanelEClass = createEClass(LAZY_PANEL);

		listBoxEClass = createEClass(LIST_BOX);

		loadListenerEClass = createEClass(LOAD_LISTENER);

		loadListenerCollectionEClass = createEClass(LOAD_LISTENER_COLLECTION);

		longBoxEClass = createEClass(LONG_BOX);

		menuBarEClass = createEClass(MENU_BAR);

		menuItemEClass = createEClass(MENU_ITEM);

		menuItemSeparatorEClass = createEClass(MENU_ITEM_SEPARATOR);

		mouseListenerEClass = createEClass(MOUSE_LISTENER);

		mouseListenerAdapterEClass = createEClass(MOUSE_LISTENER_ADAPTER);

		mouseListenerCollectionEClass = createEClass(MOUSE_LISTENER_COLLECTION);

		mouseWheelListenerEClass = createEClass(MOUSE_WHEEL_LISTENER);

		mouseWheelListenerCollectionEClass = createEClass(MOUSE_WHEEL_LISTENER_COLLECTION);

		mouseWheelVelocityEClass = createEClass(MOUSE_WHEEL_VELOCITY);

		multiWordSuggestOracleEClass = createEClass(MULTI_WORD_SUGGEST_ORACLE);

		namedFrameEClass = createEClass(NAMED_FRAME);

		nativeHorizontalScrollbarEClass = createEClass(NATIVE_HORIZONTAL_SCROLLBAR);

		nativeVerticalScrollbarEClass = createEClass(NATIVE_VERTICAL_SCROLLBAR);

		notificationMoleEClass = createEClass(NOTIFICATION_MOLE);

		numberLabelEClass = createEClass(NUMBER_LABEL);

		panelEClass = createEClass(PANEL);

		passwordTextBoxEClass = createEClass(PASSWORD_TEXT_BOX);

		popupListenerEClass = createEClass(POPUP_LISTENER);

		popupListenerCollectionEClass = createEClass(POPUP_LISTENER_COLLECTION);

		popupPanelEClass = createEClass(POPUP_PANEL);

		providesResizeEClass = createEClass(PROVIDES_RESIZE);

		pushButtonEClass = createEClass(PUSH_BUTTON);

		radioButtonEClass = createEClass(RADIO_BUTTON);

		renderablePanelEClass = createEClass(RENDERABLE_PANEL);

		requiresResizeEClass = createEClass(REQUIRES_RESIZE);

		resetButtonEClass = createEClass(RESET_BUTTON);

		resizeCompositeEClass = createEClass(RESIZE_COMPOSITE);

		resizeLayoutPanelEClass = createEClass(RESIZE_LAYOUT_PANEL);

		richTextAreaEClass = createEClass(RICH_TEXT_AREA);

		rootLayoutPanelEClass = createEClass(ROOT_LAYOUT_PANEL);

		rootPanelEClass = createEClass(ROOT_PANEL);

		scrollImplEClass = createEClass(SCROLL_IMPL);

		scrollListenerEClass = createEClass(SCROLL_LISTENER);

		scrollListenerCollectionEClass = createEClass(SCROLL_LISTENER_COLLECTION);

		scrollPanelEClass = createEClass(SCROLL_PANEL);

		simpleCheckBoxEClass = createEClass(SIMPLE_CHECK_BOX);

		simpleLayoutPanelEClass = createEClass(SIMPLE_LAYOUT_PANEL);

		simplePanelEClass = createEClass(SIMPLE_PANEL);

		simpleRadioButtonEClass = createEClass(SIMPLE_RADIO_BUTTON);

		sourcesChangeEventsEClass = createEClass(SOURCES_CHANGE_EVENTS);

		sourcesClickEventsEClass = createEClass(SOURCES_CLICK_EVENTS);

		sourcesFocusEventsEClass = createEClass(SOURCES_FOCUS_EVENTS);

		sourcesKeyboardEventsEClass = createEClass(SOURCES_KEYBOARD_EVENTS);

		sourcesLoadEventsEClass = createEClass(SOURCES_LOAD_EVENTS);

		sourcesMouseEventsEClass = createEClass(SOURCES_MOUSE_EVENTS);

		sourcesMouseWheelEventsEClass = createEClass(SOURCES_MOUSE_WHEEL_EVENTS);

		sourcesPopupEventsEClass = createEClass(SOURCES_POPUP_EVENTS);

		sourcesScrollEventsEClass = createEClass(SOURCES_SCROLL_EVENTS);

		sourcesTabEventsEClass = createEClass(SOURCES_TAB_EVENTS);

		sourcesTableEventsEClass = createEClass(SOURCES_TABLE_EVENTS);

		sourcesTreeEventsEClass = createEClass(SOURCES_TREE_EVENTS);

		splitLayoutPanelEClass = createEClass(SPLIT_LAYOUT_PANEL);

		splitPanelEClass = createEClass(SPLIT_PANEL);

		stackLayoutPanelEClass = createEClass(STACK_LAYOUT_PANEL);

		stackPanelEClass = createEClass(STACK_PANEL);

		submitButtonEClass = createEClass(SUBMIT_BUTTON);

		suggestBoxEClass = createEClass(SUGGEST_BOX);

		suggestOracleEClass = createEClass(SUGGEST_ORACLE);

		suggestionEventEClass = createEClass(SUGGESTION_EVENT);

		suggestionHandlerEClass = createEClass(SUGGESTION_HANDLER);

		tabBarEClass = createEClass(TAB_BAR);

		tabLayoutPanelEClass = createEClass(TAB_LAYOUT_PANEL);

		tabListenerEClass = createEClass(TAB_LISTENER);

		tabListenerCollectionEClass = createEClass(TAB_LISTENER_COLLECTION);

		tabPanelEClass = createEClass(TAB_PANEL);

		tableListenerEClass = createEClass(TABLE_LISTENER);

		tableListenerCollectionEClass = createEClass(TABLE_LISTENER_COLLECTION);

		textAreaEClass = createEClass(TEXT_AREA);

		textBoxEClass = createEClass(TEXT_BOX);

		textBoxBaseEClass = createEClass(TEXT_BOX_BASE);

		toggleButtonEClass = createEClass(TOGGLE_BUTTON);

		treeEClass = createEClass(TREE);

		treeImagesEClass = createEClass(TREE_IMAGES);

		treeItemEClass = createEClass(TREE_ITEM);

		treeListenerEClass = createEClass(TREE_LISTENER);

		treeListenerCollectionEClass = createEClass(TREE_LISTENER_COLLECTION);

		valueBoxEClass = createEClass(VALUE_BOX);

		valueBoxBaseEClass = createEClass(VALUE_BOX_BASE);

		valueLabelEClass = createEClass(VALUE_LABEL);

		valueListBoxEClass = createEClass(VALUE_LIST_BOX);

		valuePickerEClass = createEClass(VALUE_PICKER);

		verticalPanelEClass = createEClass(VERTICAL_PANEL);

		verticalScrollbarEClass = createEClass(VERTICAL_SCROLLBAR);

		verticalSplitPanelEClass = createEClass(VERTICAL_SPLIT_PANEL);

		verticalSplitPanelImagesEClass = createEClass(VERTICAL_SPLIT_PANEL_IMAGES);

		widgetCollectionEClass = createEClass(WIDGET_COLLECTION);

		widgetIteratorsEClass = createEClass(WIDGET_ITERATORS);

		absolutePanelEClass = createEClass(ABSOLUTE_PANEL);

		datePickerEClass = createEClass(DATE_PICKER);

		routeEClass = createEClass(ROUTE);
		createEAttribute(routeEClass, ROUTE__TOKEN);
		createEReference(routeEClass, ROUTE__TO);
		createEReference(routeEClass, ROUTE__FROM);
		createEReference(routeEClass, ROUTE__BY);

		controllerHistoryEClass = createEClass(CONTROLLER_HISTORY);
		createEReference(controllerHistoryEClass, CONTROLLER_HISTORY__ROUTES);

		activityEClass = createEClass(ACTIVITY);
		createEReference(activityEClass, ACTIVITY__PAGE);
		createEReference(activityEClass, ACTIVITY__ROUTES);

		placeEClass = createEClass(PLACE);

		routePlaceEClass = createEClass(ROUTE_PLACE);
		createEReference(routePlaceEClass, ROUTE_PLACE__PLACE);
		createEReference(routePlaceEClass, ROUTE_PLACE__WIDGET);

		activityMapperEClass = createEClass(ACTIVITY_MAPPER);

		cellTableEClass = createEClass(CELL_TABLE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CodePackage theCodePackage = (CodePackage)EPackage.Registry.INSTANCE.getEPackage(CodePackage.eNS_URI);
		CorePackage theCorePackage = (CorePackage)EPackage.Registry.INSTANCE.getEPackage(CorePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		gwtModelEClass.getESuperTypes().add(theCodePackage.getCodeModel());
		pageEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		uiObjectEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		widgetEClass.getESuperTypes().add(this.getUIObject());
		abstractImagePrototypeEClass.getESuperTypes().add(this.getComplexPanel());
		abstractNativeScrollbarEClass.getESuperTypes().add(this.getWidget());
		acceptsOneWidgetEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		accessibilityEClass.getESuperTypes().add(this.getHTMLTable());
		anchorEClass.getESuperTypes().add(this.getFocusWidget());
		animatedLayoutEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		buttonEClass.getESuperTypes().add(this.getButtonBase());
		buttonBaseEClass.getESuperTypes().add(this.getFocusWidget());
		captionPanelEClass.getESuperTypes().add(this.getComposite());
		cellPanelEClass.getESuperTypes().add(this.getComplexPanel());
		changeListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		changeListenerCollectionEClass.getESuperTypes().add(this.getChangeListener());
		checkBoxEClass.getESuperTypes().add(this.getButtonBase());
		clickListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		clickListenerCollectionEClass.getESuperTypes().add(this.getClickListener());
		complexPanelEClass.getESuperTypes().add(this.getPanel());
		compositeEClass.getESuperTypes().add(this.getWidget());
		customButtonEClass.getESuperTypes().add(this.getButtonBase());
		customScrollPanelEClass.getESuperTypes().add(this.getScrollPanel());
		dateLabelEClass.getESuperTypes().add(this.getValueLabel());
		deckLayoutPanelEClass.getESuperTypes().add(this.getComplexPanel());
		deckPanelEClass.getESuperTypes().add(this.getComplexPanel());
		decoratedPopupPanelEClass.getESuperTypes().add(this.getPopupPanel());
		decoratedStackPanelEClass.getESuperTypes().add(this.getStackPanel());
		decoratedTabBarEClass.getESuperTypes().add(this.getTabBar());
		decoratedTabPanelEClass.getESuperTypes().add(this.getTabPanel());
		decoratorPanelEClass.getESuperTypes().add(this.getSimplePanel());
		delegatingChangeListenerCollectionEClass.getESuperTypes().add(this.getChangeListenerCollection());
		delegatingClickListenerCollectionEClass.getESuperTypes().add(this.getClickListenerCollection());
		delegatingFocusListenerCollectionEClass.getESuperTypes().add(this.getFocusListenerCollection());
		delegatingKeyboardListenerCollectionEClass.getESuperTypes().add(this.getKeyboardListenerCollection());
		dialogBoxEClass.getESuperTypes().add(this.getDecoratedPopupPanel());
		directionalTextHelperEClass.getESuperTypes().add(this.getPopupListener());
		disclosureEventEClass.getESuperTypes().add(this.getEventObject());
		disclosureHandlerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		disclosurePanelEClass.getESuperTypes().add(this.getComposite());
		disclosurePanelImagesEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		disclosurePanelImagesRTLEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		dockLayoutPanelEClass.getESuperTypes().add(this.getComplexPanel());
		dockPanelEClass.getESuperTypes().add(this.getCellPanel());
		doubleBoxEClass.getESuperTypes().add(this.getValueBox());
		fileUploadEClass.getESuperTypes().add(this.getFocusWidget());
		finiteWidgetIteratorEClass.getESuperTypes().add(this.getPanel());
		firesDisclosureEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		firesFormEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		firesSuggestionEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		flexTableEClass.getESuperTypes().add(this.getHTMLTable());
		flowPanelEClass.getESuperTypes().add(this.getComplexPanel());
		focusListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		focusListenerAdapterEClass.getESuperTypes().add(this.getUIObject());
		focusListenerCollectionEClass.getESuperTypes().add(this.getFocusListener());
		focusPanelEClass.getESuperTypes().add(this.getSimplePanel());
		focusWidgetEClass.getESuperTypes().add(this.getWidget());
		focusableEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		formHandlerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		formHandlerCollectionEClass.getESuperTypes().add(this.getFormHandler());
		formPanelEClass.getESuperTypes().add(this.getSimplePanel());
		formSubmitCompleteEventEClass.getESuperTypes().add(this.getEventObject());
		formSubmitEventEClass.getESuperTypes().add(this.getEventObject());
		frameEClass.getESuperTypes().add(this.getWidget());
		gridEClass.getESuperTypes().add(this.getHTMLTable());
		htmlEClass.getESuperTypes().add(this.getLabel());
		htmlPanelEClass.getESuperTypes().add(this.getComplexPanel());
		htmlTableEClass.getESuperTypes().add(this.getPanel());
		hasAlignmentEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasAnimationEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasAutoHorizontalAlignmentEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasCaptionEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasConstrainedValueEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasDirectionalHtmlEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasDirectionalSafeHtmlEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasDirectionalTextEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasEnabledEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasFocusEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasHTMLEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasHorizontalAlignmentEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasHorizontalScrollingEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasKeyPreviewEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasNameEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasOneWidgetEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasScrollingEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasTextEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasTreeItemsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasValueEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasVerticalAlignmentEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasVerticalScrollingEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasVisibilityEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasWidgetsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hasWordWrapEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		headerPanelEClass.getESuperTypes().add(this.getPanel());
		hiddenEClass.getESuperTypes().add(this.getWidget());
		horizontalPanelEClass.getESuperTypes().add(this.getCellPanel());
		horizontalScrollbarEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		horizontalSplitPanelEClass.getESuperTypes().add(this.getSplitPanel());
		horizontalSplitPanelImagesEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		hyperlinkEClass.getESuperTypes().add(this.getWidget());
		gwtImageEClass.getESuperTypes().add(this.getWidget());
		imageBundleEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		indexedPanelEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		inlineHTMLEClass.getESuperTypes().add(this.getHTML());
		inlineHyperlinkEClass.getESuperTypes().add(this.getHyperlink());
		inlineLabelEClass.getESuperTypes().add(this.getLabel());
		insertPanelEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		integerBoxEClass.getESuperTypes().add(this.getValueBox());
		isRenderableEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		isTreeItemEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		isWidgetEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		keyboardListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		keyboardListenerAdapterEClass.getESuperTypes().add(this.getUIObject());
		keyboardListenerCollectionEClass.getESuperTypes().add(this.getKeyboardListener());
		labelEClass.getESuperTypes().add(this.getLabelBase());
		labelBaseEClass.getESuperTypes().add(this.getWidget());
		layoutCommandEClass.getESuperTypes().add(this.getFocusWidget());
		layoutPanelEClass.getESuperTypes().add(this.getComplexPanel());
		lazyPanelEClass.getESuperTypes().add(this.getSimplePanel());
		listBoxEClass.getESuperTypes().add(this.getFocusWidget());
		loadListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		loadListenerCollectionEClass.getESuperTypes().add(this.getLoadListener());
		longBoxEClass.getESuperTypes().add(this.getValueBox());
		menuBarEClass.getESuperTypes().add(this.getWidget());
		menuItemEClass.getESuperTypes().add(this.getUIObject());
		menuItemSeparatorEClass.getESuperTypes().add(this.getUIObject());
		mouseListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		mouseListenerAdapterEClass.getESuperTypes().add(this.getTextBoxBase());
		mouseListenerCollectionEClass.getESuperTypes().add(this.getMouseListener());
		mouseWheelListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		mouseWheelListenerCollectionEClass.getESuperTypes().add(this.getMouseWheelListener());
		mouseWheelVelocityEClass.getESuperTypes().add(this.getCellPanel());
		multiWordSuggestOracleEClass.getESuperTypes().add(this.getSuggestOracle());
		namedFrameEClass.getESuperTypes().add(this.getFrame());
		nativeHorizontalScrollbarEClass.getESuperTypes().add(this.getAbstractNativeScrollbar());
		nativeVerticalScrollbarEClass.getESuperTypes().add(this.getAbstractNativeScrollbar());
		notificationMoleEClass.getESuperTypes().add(this.getComposite());
		numberLabelEClass.getESuperTypes().add(this.getValueLabel());
		panelEClass.getESuperTypes().add(this.getWidget());
		passwordTextBoxEClass.getESuperTypes().add(this.getTextBox());
		popupListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		popupListenerCollectionEClass.getESuperTypes().add(this.getPopupListener());
		popupPanelEClass.getESuperTypes().add(this.getSimplePanel());
		providesResizeEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		pushButtonEClass.getESuperTypes().add(this.getCustomButton());
		radioButtonEClass.getESuperTypes().add(this.getCheckBox());
		renderablePanelEClass.getESuperTypes().add(this.getComplexPanel());
		requiresResizeEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		resetButtonEClass.getESuperTypes().add(this.getButton());
		resizeCompositeEClass.getESuperTypes().add(this.getComposite());
		resizeLayoutPanelEClass.getESuperTypes().add(this.getSimplePanel());
		richTextAreaEClass.getESuperTypes().add(this.getFocusWidget());
		rootLayoutPanelEClass.getESuperTypes().add(this.getLayoutPanel());
		rootPanelEClass.getESuperTypes().add(this.getAbsolutePanel());
		rootPanelEClass.getESuperTypes().add(theCodePackage.getImports());
		scrollImplEClass.getESuperTypes().add(this.getHTML());
		scrollListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		scrollListenerCollectionEClass.getESuperTypes().add(this.getScrollListener());
		scrollPanelEClass.getESuperTypes().add(this.getSimplePanel());
		simpleCheckBoxEClass.getESuperTypes().add(this.getFocusWidget());
		simpleLayoutPanelEClass.getESuperTypes().add(this.getSimplePanel());
		simplePanelEClass.getESuperTypes().add(this.getPanel());
		simpleRadioButtonEClass.getESuperTypes().add(this.getSimpleCheckBox());
		sourcesChangeEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesClickEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesFocusEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesKeyboardEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesLoadEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesMouseEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesMouseWheelEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesPopupEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesScrollEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesTabEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesTableEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		sourcesTreeEventsEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		splitLayoutPanelEClass.getESuperTypes().add(this.getDockLayoutPanel());
		splitPanelEClass.getESuperTypes().add(this.getPanel());
		stackLayoutPanelEClass.getESuperTypes().add(this.getResizeComposite());
		stackPanelEClass.getESuperTypes().add(this.getComplexPanel());
		submitButtonEClass.getESuperTypes().add(this.getButton());
		suggestBoxEClass.getESuperTypes().add(this.getComposite());
		suggestOracleEClass.getESuperTypes().add(this.getDockLayoutPanel());
		suggestionEventEClass.getESuperTypes().add(this.getEventObject());
		suggestionHandlerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		tabBarEClass.getESuperTypes().add(this.getComposite());
		tabLayoutPanelEClass.getESuperTypes().add(this.getResizeComposite());
		tabListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		tabListenerCollectionEClass.getESuperTypes().add(this.getTabListener());
		tabPanelEClass.getESuperTypes().add(this.getComposite());
		tableListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		tableListenerCollectionEClass.getESuperTypes().add(this.getTableListener());
		textAreaEClass.getESuperTypes().add(this.getTextBoxBase());
		textBoxEClass.getESuperTypes().add(this.getTextBoxBase());
		textBoxBaseEClass.getESuperTypes().add(this.getValueBoxBase());
		toggleButtonEClass.getESuperTypes().add(this.getCustomButton());
		treeEClass.getESuperTypes().add(this.getWidget());
		treeImagesEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		treeItemEClass.getESuperTypes().add(this.getUIObject());
		treeListenerEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		treeListenerCollectionEClass.getESuperTypes().add(this.getTreeListener());
		valueBoxEClass.getESuperTypes().add(this.getValueBoxBase());
		valueBoxBaseEClass.getESuperTypes().add(this.getFocusWidget());
		valueLabelEClass.getESuperTypes().add(this.getLabelBase());
		valueListBoxEClass.getESuperTypes().add(this.getComposite());
		valuePickerEClass.getESuperTypes().add(this.getComposite());
		verticalPanelEClass.getESuperTypes().add(this.getCellPanel());
		verticalScrollbarEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		verticalSplitPanelEClass.getESuperTypes().add(this.getSplitPanel());
		verticalSplitPanelImagesEClass.getESuperTypes().add(theCodePackage.getInterfaceUnit());
		widgetCollectionEClass.getESuperTypes().add(this.getAbstractNativeScrollbar());
		widgetIteratorsEClass.getESuperTypes().add(this.getComposite());
		absolutePanelEClass.getESuperTypes().add(this.getComplexPanel());
		datePickerEClass.getESuperTypes().add(this.getButton());
		routeEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		controllerHistoryEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		activityEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		placeEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		activityMapperEClass.getESuperTypes().add(theCodePackage.getClassUnit());
		cellTableEClass.getESuperTypes().add(this.getComposite());

		// Initialize classes, features, and operations; add parameters
		initEClass(gwtModelEClass, GwtModel.class, "GwtModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGwtModel_Pages(), this.getPage(), null, "pages", null, 0, -1, GwtModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGwtModel_Activities(), this.getActivity(), null, "activities", null, 0, -1, GwtModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGwtModel_Places(), this.getPlace(), null, "places", null, 0, -1, GwtModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGwtModel_Mapper(), theCodePackage.getClassUnit(), null, "mapper", null, 0, -1, GwtModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(pageEClass, Page.class, "Page", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPage_Widgets(), this.getWidget(), null, "widgets", null, 0, -1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPage_Routes(), this.getRoute(), null, "routes", null, 0, -1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPage_IsKindOfComposite(), theCorePackage.getBoolean(), "isKindOfComposite", null, 0, 1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPage_IsKindOfWidget(), theCorePackage.getBoolean(), "isKindOfWidget", null, 0, 1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPage_TypeOfWidget(), theCorePackage.getString(), "typeOfWidget", null, 0, 1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(uiObjectEClass, UIObject.class, "UIObject", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(widgetEClass, Widget.class, "Widget", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getWidget_Actions(), theCodePackage.getAbstractCodeElement(), null, "actions", null, 0, -1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWidget_IsContainer(), theCorePackage.getBoolean(), "isContainer", null, 0, 1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWidget_NestedWidgets(), this.getWidget(), null, "nestedWidgets", null, 0, -1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWidget_TypeWidget(), theCodePackage.getClassUnit(), null, "typeWidget", null, 0, 1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWidget_Style(), theCorePackage.getString(), "style", null, 0, 1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWidget_ContainerOuterHtml(), theCorePackage.getString(), "containerOuterHtml", null, 0, 1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWidget_LeafOuterHtml(), theCorePackage.getString(), "leafOuterHtml", null, 0, 1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWidget_IsNewDecoratedWidget(), theCorePackage.getBoolean(), "isNewDecoratedWidget", null, 0, 1, Widget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractImagePrototypeEClass, AbstractImagePrototype.class, "AbstractImagePrototype", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(abstractNativeScrollbarEClass, AbstractNativeScrollbar.class, "AbstractNativeScrollbar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(acceptsOneWidgetEClass, AcceptsOneWidget.class, "AcceptsOneWidget", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(accessibilityEClass, Accessibility.class, "Accessibility", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(anchorEClass, Anchor.class, "Anchor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(animatedLayoutEClass, AnimatedLayout.class, "AnimatedLayout", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(buttonEClass, Button.class, "Button", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(buttonBaseEClass, ButtonBase.class, "ButtonBase", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(captionPanelEClass, CaptionPanel.class, "CaptionPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(cellPanelEClass, CellPanel.class, "CellPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(changeListenerEClass, ChangeListener.class, "ChangeListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(changeListenerCollectionEClass, ChangeListenerCollection.class, "ChangeListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(checkBoxEClass, CheckBox.class, "CheckBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(clickListenerEClass, ClickListener.class, "ClickListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(clickListenerCollectionEClass, ClickListenerCollection.class, "ClickListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(complexPanelEClass, ComplexPanel.class, "ComplexPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(compositeEClass, Composite.class, "Composite", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(customButtonEClass, CustomButton.class, "CustomButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(customScrollPanelEClass, CustomScrollPanel.class, "CustomScrollPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dateLabelEClass, DateLabel.class, "DateLabel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(deckLayoutPanelEClass, DeckLayoutPanel.class, "DeckLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(deckPanelEClass, DeckPanel.class, "DeckPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(decoratedPopupPanelEClass, DecoratedPopupPanel.class, "DecoratedPopupPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(decoratedStackPanelEClass, DecoratedStackPanel.class, "DecoratedStackPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(decoratedTabBarEClass, DecoratedTabBar.class, "DecoratedTabBar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(decoratedTabPanelEClass, DecoratedTabPanel.class, "DecoratedTabPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(decoratorPanelEClass, DecoratorPanel.class, "DecoratorPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(delegatingChangeListenerCollectionEClass, DelegatingChangeListenerCollection.class, "DelegatingChangeListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(delegatingClickListenerCollectionEClass, DelegatingClickListenerCollection.class, "DelegatingClickListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(delegatingFocusListenerCollectionEClass, DelegatingFocusListenerCollection.class, "DelegatingFocusListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(delegatingKeyboardListenerCollectionEClass, DelegatingKeyboardListenerCollection.class, "DelegatingKeyboardListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dialogBoxEClass, DialogBox.class, "DialogBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(directionalTextHelperEClass, DirectionalTextHelper.class, "DirectionalTextHelper", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disclosureEventEClass, DisclosureEvent.class, "DisclosureEvent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disclosureHandlerEClass, DisclosureHandler.class, "DisclosureHandler", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disclosurePanelEClass, DisclosurePanel.class, "DisclosurePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disclosurePanelImagesEClass, DisclosurePanelImages.class, "DisclosurePanelImages", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disclosurePanelImagesRTLEClass, DisclosurePanelImagesRTL.class, "DisclosurePanelImagesRTL", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dockLayoutPanelEClass, DockLayoutPanel.class, "DockLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dockPanelEClass, DockPanel.class, "DockPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(doubleBoxEClass, DoubleBox.class, "DoubleBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(eventObjectEClass, EventObject.class, "EventObject", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(fileUploadEClass, FileUpload.class, "FileUpload", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(finiteWidgetIteratorEClass, FiniteWidgetIterator.class, "FiniteWidgetIterator", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(firesDisclosureEventsEClass, FiresDisclosureEvents.class, "FiresDisclosureEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(firesFormEventsEClass, FiresFormEvents.class, "FiresFormEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(firesSuggestionEventsEClass, FiresSuggestionEvents.class, "FiresSuggestionEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(flexTableEClass, FlexTable.class, "FlexTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(flowPanelEClass, FlowPanel.class, "FlowPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(focusListenerEClass, FocusListener.class, "FocusListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(focusListenerAdapterEClass, FocusListenerAdapter.class, "FocusListenerAdapter", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(focusListenerCollectionEClass, FocusListenerCollection.class, "FocusListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(focusPanelEClass, FocusPanel.class, "FocusPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(focusWidgetEClass, FocusWidget.class, "FocusWidget", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(focusableEClass, Focusable.class, "Focusable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(formHandlerEClass, FormHandler.class, "FormHandler", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(formHandlerCollectionEClass, FormHandlerCollection.class, "FormHandlerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(formPanelEClass, FormPanel.class, "FormPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(formSubmitCompleteEventEClass, FormSubmitCompleteEvent.class, "FormSubmitCompleteEvent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(formSubmitEventEClass, FormSubmitEvent.class, "FormSubmitEvent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(frameEClass, Frame.class, "Frame", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(gridEClass, Grid.class, "Grid", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(htmlEClass, kdm.code.gwt.HTML.class, "HTML", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(htmlPanelEClass, HTMLPanel.class, "HTMLPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(htmlTableEClass, HTMLTable.class, "HTMLTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasAlignmentEClass, HasAlignment.class, "HasAlignment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasAnimationEClass, HasAnimation.class, "HasAnimation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasAutoHorizontalAlignmentEClass, HasAutoHorizontalAlignment.class, "HasAutoHorizontalAlignment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasCaptionEClass, HasCaption.class, "HasCaption", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasConstrainedValueEClass, HasConstrainedValue.class, "HasConstrainedValue", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasDirectionalHtmlEClass, HasDirectionalHtml.class, "HasDirectionalHtml", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasDirectionalSafeHtmlEClass, HasDirectionalSafeHtml.class, "HasDirectionalSafeHtml", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasDirectionalTextEClass, HasDirectionalText.class, "HasDirectionalText", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasEnabledEClass, HasEnabled.class, "HasEnabled", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasFocusEClass, HasFocus.class, "HasFocus", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasHTMLEClass, HasHTML.class, "HasHTML", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasHorizontalAlignmentEClass, HasHorizontalAlignment.class, "HasHorizontalAlignment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasHorizontalScrollingEClass, HasHorizontalScrolling.class, "HasHorizontalScrolling", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasKeyPreviewEClass, HasKeyPreview.class, "HasKeyPreview", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasNameEClass, HasName.class, "HasName", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasOneWidgetEClass, HasOneWidget.class, "HasOneWidget", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasScrollingEClass, HasScrolling.class, "HasScrolling", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasTextEClass, HasText.class, "HasText", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasTreeItemsEClass, HasTreeItems.class, "HasTreeItems", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasValueEClass, HasValue.class, "HasValue", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasVerticalAlignmentEClass, HasVerticalAlignment.class, "HasVerticalAlignment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasVerticalScrollingEClass, HasVerticalScrolling.class, "HasVerticalScrolling", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasVisibilityEClass, HasVisibility.class, "HasVisibility", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasWidgetsEClass, HasWidgets.class, "HasWidgets", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hasWordWrapEClass, HasWordWrap.class, "HasWordWrap", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(headerPanelEClass, HeaderPanel.class, "HeaderPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hiddenEClass, Hidden.class, "Hidden", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(horizontalPanelEClass, HorizontalPanel.class, "HorizontalPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(horizontalScrollbarEClass, HorizontalScrollbar.class, "HorizontalScrollbar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(horizontalSplitPanelEClass, HorizontalSplitPanel.class, "HorizontalSplitPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(horizontalSplitPanelImagesEClass, HorizontalSplitPanelImages.class, "HorizontalSplitPanelImages", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hyperlinkEClass, Hyperlink.class, "Hyperlink", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(gwtImageEClass, GWTImage.class, "GWTImage", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(imageBundleEClass, ImageBundle.class, "ImageBundle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(indexedPanelEClass, IndexedPanel.class, "IndexedPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(inlineHTMLEClass, InlineHTML.class, "InlineHTML", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(inlineHyperlinkEClass, InlineHyperlink.class, "InlineHyperlink", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(inlineLabelEClass, InlineLabel.class, "InlineLabel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(insertPanelEClass, InsertPanel.class, "InsertPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(integerBoxEClass, IntegerBox.class, "IntegerBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(isRenderableEClass, IsRenderable.class, "IsRenderable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(isTreeItemEClass, IsTreeItem.class, "IsTreeItem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(isWidgetEClass, IsWidget.class, "IsWidget", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(keyboardListenerEClass, KeyboardListener.class, "KeyboardListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(keyboardListenerAdapterEClass, KeyboardListenerAdapter.class, "KeyboardListenerAdapter", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(keyboardListenerCollectionEClass, KeyboardListenerCollection.class, "KeyboardListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(labelEClass, Label.class, "Label", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(labelBaseEClass, LabelBase.class, "LabelBase", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(layoutCommandEClass, LayoutCommand.class, "LayoutCommand", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(layoutPanelEClass, LayoutPanel.class, "LayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(lazyPanelEClass, LazyPanel.class, "LazyPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(listBoxEClass, ListBox.class, "ListBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(loadListenerEClass, LoadListener.class, "LoadListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(loadListenerCollectionEClass, LoadListenerCollection.class, "LoadListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(longBoxEClass, LongBox.class, "LongBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(menuBarEClass, MenuBar.class, "MenuBar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(menuItemEClass, MenuItem.class, "MenuItem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(menuItemSeparatorEClass, MenuItemSeparator.class, "MenuItemSeparator", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(mouseListenerEClass, MouseListener.class, "MouseListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(mouseListenerAdapterEClass, MouseListenerAdapter.class, "MouseListenerAdapter", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(mouseListenerCollectionEClass, MouseListenerCollection.class, "MouseListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(mouseWheelListenerEClass, MouseWheelListener.class, "MouseWheelListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(mouseWheelListenerCollectionEClass, MouseWheelListenerCollection.class, "MouseWheelListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(mouseWheelVelocityEClass, MouseWheelVelocity.class, "MouseWheelVelocity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(multiWordSuggestOracleEClass, MultiWordSuggestOracle.class, "MultiWordSuggestOracle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(namedFrameEClass, NamedFrame.class, "NamedFrame", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(nativeHorizontalScrollbarEClass, NativeHorizontalScrollbar.class, "NativeHorizontalScrollbar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(nativeVerticalScrollbarEClass, NativeVerticalScrollbar.class, "NativeVerticalScrollbar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(notificationMoleEClass, NotificationMole.class, "NotificationMole", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(numberLabelEClass, NumberLabel.class, "NumberLabel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(panelEClass, Panel.class, "Panel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(passwordTextBoxEClass, PasswordTextBox.class, "PasswordTextBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(popupListenerEClass, PopupListener.class, "PopupListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(popupListenerCollectionEClass, PopupListenerCollection.class, "PopupListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(popupPanelEClass, PopupPanel.class, "PopupPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(providesResizeEClass, ProvidesResize.class, "ProvidesResize", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(pushButtonEClass, PushButton.class, "PushButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(radioButtonEClass, RadioButton.class, "RadioButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(renderablePanelEClass, RenderablePanel.class, "RenderablePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(requiresResizeEClass, RequiresResize.class, "RequiresResize", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(resetButtonEClass, ResetButton.class, "ResetButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(resizeCompositeEClass, ResizeComposite.class, "ResizeComposite", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(resizeLayoutPanelEClass, ResizeLayoutPanel.class, "ResizeLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(richTextAreaEClass, RichTextArea.class, "RichTextArea", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(rootLayoutPanelEClass, RootLayoutPanel.class, "RootLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(rootPanelEClass, RootPanel.class, "RootPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(scrollImplEClass, ScrollImpl.class, "ScrollImpl", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(scrollListenerEClass, ScrollListener.class, "ScrollListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(scrollListenerCollectionEClass, ScrollListenerCollection.class, "ScrollListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(scrollPanelEClass, ScrollPanel.class, "ScrollPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simpleCheckBoxEClass, SimpleCheckBox.class, "SimpleCheckBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simpleLayoutPanelEClass, SimpleLayoutPanel.class, "SimpleLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simplePanelEClass, SimplePanel.class, "SimplePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simpleRadioButtonEClass, SimpleRadioButton.class, "SimpleRadioButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesChangeEventsEClass, SourcesChangeEvents.class, "SourcesChangeEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesClickEventsEClass, SourcesClickEvents.class, "SourcesClickEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesFocusEventsEClass, SourcesFocusEvents.class, "SourcesFocusEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesKeyboardEventsEClass, SourcesKeyboardEvents.class, "SourcesKeyboardEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesLoadEventsEClass, SourcesLoadEvents.class, "SourcesLoadEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesMouseEventsEClass, SourcesMouseEvents.class, "SourcesMouseEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesMouseWheelEventsEClass, SourcesMouseWheelEvents.class, "SourcesMouseWheelEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesPopupEventsEClass, SourcesPopupEvents.class, "SourcesPopupEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesScrollEventsEClass, SourcesScrollEvents.class, "SourcesScrollEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesTabEventsEClass, SourcesTabEvents.class, "SourcesTabEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesTableEventsEClass, SourcesTableEvents.class, "SourcesTableEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sourcesTreeEventsEClass, SourcesTreeEvents.class, "SourcesTreeEvents", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(splitLayoutPanelEClass, SplitLayoutPanel.class, "SplitLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(splitPanelEClass, SplitPanel.class, "SplitPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(stackLayoutPanelEClass, StackLayoutPanel.class, "StackLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(stackPanelEClass, StackPanel.class, "StackPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(submitButtonEClass, SubmitButton.class, "SubmitButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(suggestBoxEClass, SuggestBox.class, "SuggestBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(suggestOracleEClass, SuggestOracle.class, "SuggestOracle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(suggestionEventEClass, SuggestionEvent.class, "SuggestionEvent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(suggestionHandlerEClass, SuggestionHandler.class, "SuggestionHandler", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tabBarEClass, TabBar.class, "TabBar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tabLayoutPanelEClass, TabLayoutPanel.class, "TabLayoutPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tabListenerEClass, TabListener.class, "TabListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tabListenerCollectionEClass, TabListenerCollection.class, "TabListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tabPanelEClass, TabPanel.class, "TabPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tableListenerEClass, TableListener.class, "TableListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tableListenerCollectionEClass, TableListenerCollection.class, "TableListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(textAreaEClass, TextArea.class, "TextArea", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(textBoxEClass, TextBox.class, "TextBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(textBoxBaseEClass, TextBoxBase.class, "TextBoxBase", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(toggleButtonEClass, ToggleButton.class, "ToggleButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(treeEClass, Tree.class, "Tree", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(treeImagesEClass, TreeImages.class, "TreeImages", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(treeItemEClass, TreeItem.class, "TreeItem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(treeListenerEClass, TreeListener.class, "TreeListener", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(treeListenerCollectionEClass, TreeListenerCollection.class, "TreeListenerCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(valueBoxEClass, ValueBox.class, "ValueBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(valueBoxBaseEClass, ValueBoxBase.class, "ValueBoxBase", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(valueLabelEClass, ValueLabel.class, "ValueLabel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(valueListBoxEClass, ValueListBox.class, "ValueListBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(valuePickerEClass, ValuePicker.class, "ValuePicker", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(verticalPanelEClass, VerticalPanel.class, "VerticalPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(verticalScrollbarEClass, VerticalScrollbar.class, "VerticalScrollbar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(verticalSplitPanelEClass, VerticalSplitPanel.class, "VerticalSplitPanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(verticalSplitPanelImagesEClass, VerticalSplitPanelImages.class, "VerticalSplitPanelImages", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(widgetCollectionEClass, WidgetCollection.class, "WidgetCollection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(widgetIteratorsEClass, WidgetIterators.class, "WidgetIterators", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(absolutePanelEClass, AbsolutePanel.class, "AbsolutePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(datePickerEClass, DatePicker.class, "DatePicker", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(routeEClass, Route.class, "Route", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRoute_Token(), theCorePackage.getString(), "token", null, 0, 1, Route.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_To(), this.getPage(), null, "to", null, 0, 1, Route.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_From(), this.getPage(), null, "from", null, 0, 1, Route.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_By(), this.getWidget(), null, "by", null, 0, 1, Route.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(controllerHistoryEClass, ControllerHistory.class, "ControllerHistory", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getControllerHistory_Routes(), this.getRoute(), null, "routes", null, 0, -1, ControllerHistory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(activityEClass, Activity.class, "Activity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getActivity_Page(), this.getPage(), null, "Page", null, 0, 1, Activity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getActivity_Routes(), this.getRoutePlace(), null, "routes", null, 0, -1, Activity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(placeEClass, Place.class, "Place", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(routePlaceEClass, RoutePlace.class, "RoutePlace", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRoutePlace_Place(), this.getPlace(), null, "place", null, 0, 1, RoutePlace.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoutePlace_Widget(), this.getWidget(), null, "widget", null, 0, 1, RoutePlace.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(activityMapperEClass, ActivityMapper.class, "ActivityMapper", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(cellTableEClass, CellTable.class, "CellTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
	}

} //GwtPackageImpl
