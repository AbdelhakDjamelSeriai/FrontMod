/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DecoratedTabBar;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Decorated Tab Bar</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DecoratedTabBarImpl extends TabBarImpl implements DecoratedTabBar {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DecoratedTabBarImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DECORATED_TAB_BAR;
	}

} //DecoratedTabBarImpl
