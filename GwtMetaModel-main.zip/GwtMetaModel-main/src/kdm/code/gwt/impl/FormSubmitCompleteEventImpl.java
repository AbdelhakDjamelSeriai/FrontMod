/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FormSubmitCompleteEvent;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Form Submit Complete Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FormSubmitCompleteEventImpl extends EventObjectImpl implements FormSubmitCompleteEvent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FormSubmitCompleteEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FORM_SUBMIT_COMPLETE_EVENT;
	}

} //FormSubmitCompleteEventImpl
