/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.Accessibility;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Accessibility</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AccessibilityImpl extends HTMLTableImpl implements Accessibility {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AccessibilityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.ACCESSIBILITY;
	}

} //AccessibilityImpl
