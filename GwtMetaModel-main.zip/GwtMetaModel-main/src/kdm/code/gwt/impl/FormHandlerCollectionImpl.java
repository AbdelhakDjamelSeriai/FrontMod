/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FormHandlerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Form Handler Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FormHandlerCollectionImpl extends FormHandlerImpl implements FormHandlerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FormHandlerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FORM_HANDLER_COLLECTION;
	}

} //FormHandlerCollectionImpl
