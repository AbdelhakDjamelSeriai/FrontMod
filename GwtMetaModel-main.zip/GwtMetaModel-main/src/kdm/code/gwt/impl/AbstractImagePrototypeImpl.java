/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.AbstractImagePrototype;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Image Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AbstractImagePrototypeImpl extends ComplexPanelImpl implements AbstractImagePrototype {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractImagePrototypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.ABSTRACT_IMAGE_PROTOTYPE;
	}

} //AbstractImagePrototypeImpl
