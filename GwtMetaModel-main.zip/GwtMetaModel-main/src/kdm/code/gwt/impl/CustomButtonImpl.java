/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.CustomButton;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Custom Button</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CustomButtonImpl extends ButtonBaseImpl implements CustomButton {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CustomButtonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.CUSTOM_BUTTON;
	}

} //CustomButtonImpl
