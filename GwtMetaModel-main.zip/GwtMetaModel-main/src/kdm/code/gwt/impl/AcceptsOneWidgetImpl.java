/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.AcceptsOneWidget;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Accepts One Widget</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AcceptsOneWidgetImpl extends InterfaceUnitImpl implements AcceptsOneWidget {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AcceptsOneWidgetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.ACCEPTS_ONE_WIDGET;
	}

} //AcceptsOneWidgetImpl
