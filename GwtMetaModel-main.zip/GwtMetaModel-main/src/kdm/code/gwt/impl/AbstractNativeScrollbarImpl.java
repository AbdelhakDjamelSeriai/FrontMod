/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.AbstractNativeScrollbar;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Native Scrollbar</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AbstractNativeScrollbarImpl extends WidgetImpl implements AbstractNativeScrollbar {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractNativeScrollbarImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.ABSTRACT_NATIVE_SCROLLBAR;
	}

} //AbstractNativeScrollbarImpl
