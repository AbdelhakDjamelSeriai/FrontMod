/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FocusListenerAdapter;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Focus Listener Adapter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FocusListenerAdapterImpl extends UIObjectImpl implements FocusListenerAdapter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FocusListenerAdapterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FOCUS_LISTENER_ADAPTER;
	}

} //FocusListenerAdapterImpl
