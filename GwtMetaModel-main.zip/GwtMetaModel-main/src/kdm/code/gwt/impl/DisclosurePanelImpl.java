/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DisclosurePanel;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Disclosure Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DisclosurePanelImpl extends CompositeImpl implements DisclosurePanel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DisclosurePanelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DISCLOSURE_PANEL;
	}

} //DisclosurePanelImpl
