/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.CellTable;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cell Table</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CellTableImpl extends CompositeImpl implements CellTable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CellTableImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.CELL_TABLE;
	}

} //CellTableImpl
