/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FlowPanel;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Flow Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FlowPanelImpl extends ComplexPanelImpl implements FlowPanel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FlowPanelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FLOW_PANEL;
	}

} //FlowPanelImpl
