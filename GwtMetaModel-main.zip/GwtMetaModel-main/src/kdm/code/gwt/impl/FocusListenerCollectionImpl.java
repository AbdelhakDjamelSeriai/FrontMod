/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FocusListenerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Focus Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FocusListenerCollectionImpl extends FocusListenerImpl implements FocusListenerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FocusListenerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FOCUS_LISTENER_COLLECTION;
	}

} //FocusListenerCollectionImpl
