/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.ActivityMapper;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.ClassUnitImpl;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Activity Mapper</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ActivityMapperImpl extends ClassUnitImpl implements ActivityMapper {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActivityMapperImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.ACTIVITY_MAPPER;
	}

} //ActivityMapperImpl
