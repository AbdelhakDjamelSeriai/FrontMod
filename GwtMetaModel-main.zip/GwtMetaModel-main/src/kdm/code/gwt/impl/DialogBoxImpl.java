/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DialogBox;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dialog Box</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DialogBoxImpl extends DecoratedPopupPanelImpl implements DialogBox {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DialogBoxImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DIALOG_BOX;
	}

} //DialogBoxImpl
