/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.ButtonBase;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Button Base</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ButtonBaseImpl extends FocusWidgetImpl implements ButtonBase {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ButtonBaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.BUTTON_BASE;
	}

} //ButtonBaseImpl
