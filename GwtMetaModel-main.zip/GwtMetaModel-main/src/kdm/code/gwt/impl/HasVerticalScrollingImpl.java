/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HasVerticalScrolling;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Has Vertical Scrolling</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HasVerticalScrollingImpl extends InterfaceUnitImpl implements HasVerticalScrolling {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HasVerticalScrollingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HAS_VERTICAL_SCROLLING;
	}

} //HasVerticalScrollingImpl
