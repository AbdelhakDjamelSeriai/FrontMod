/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DisclosurePanelImagesRTL;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Disclosure Panel Images RTL</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DisclosurePanelImagesRTLImpl extends InterfaceUnitImpl implements DisclosurePanelImagesRTL {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DisclosurePanelImagesRTLImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DISCLOSURE_PANEL_IMAGES_RTL;
	}

} //DisclosurePanelImagesRTLImpl
