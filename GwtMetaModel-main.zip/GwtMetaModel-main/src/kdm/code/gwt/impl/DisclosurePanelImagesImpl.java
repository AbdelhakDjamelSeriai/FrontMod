/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DisclosurePanelImages;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Disclosure Panel Images</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DisclosurePanelImagesImpl extends InterfaceUnitImpl implements DisclosurePanelImages {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DisclosurePanelImagesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DISCLOSURE_PANEL_IMAGES;
	}

} //DisclosurePanelImagesImpl
