/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.GwtPackage;
import kdm.code.gwt.HTMLPanel;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>HTML Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HTMLPanelImpl extends ComplexPanelImpl implements HTMLPanel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HTMLPanelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.HTML_PANEL;
	}

} //HTMLPanelImpl
