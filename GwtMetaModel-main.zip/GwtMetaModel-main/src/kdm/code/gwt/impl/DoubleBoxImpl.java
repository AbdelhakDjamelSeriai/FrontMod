/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.DoubleBox;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Double Box</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DoubleBoxImpl extends ValueBoxImpl implements DoubleBox {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DoubleBoxImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.DOUBLE_BOX;
	}

} //DoubleBoxImpl
