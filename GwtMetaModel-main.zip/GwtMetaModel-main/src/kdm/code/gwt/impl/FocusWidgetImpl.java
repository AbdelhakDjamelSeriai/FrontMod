/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FocusWidget;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Focus Widget</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FocusWidgetImpl extends WidgetImpl implements FocusWidget {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FocusWidgetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FOCUS_WIDGET;
	}

} //FocusWidgetImpl
