/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.ClickListenerCollection;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Click Listener Collection</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClickListenerCollectionImpl extends ClickListenerImpl implements ClickListenerCollection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClickListenerCollectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.CLICK_LISTENER_COLLECTION;
	}

} //ClickListenerCollectionImpl
