/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.FiresSuggestionEvents;
import kdm.code.gwt.GwtPackage;

import kdm.code.impl.InterfaceUnitImpl;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fires Suggestion Events</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FiresSuggestionEventsImpl extends InterfaceUnitImpl implements FiresSuggestionEvents {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FiresSuggestionEventsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.FIRES_SUGGESTION_EVENTS;
	}

} //FiresSuggestionEventsImpl
