/**
 */
package kdm.code.gwt.impl;

import kdm.code.gwt.EventObject;
import kdm.code.gwt.GwtPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EventObjectImpl extends MinimalEObjectImpl.Container implements EventObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GwtPackage.Literals.EVENT_OBJECT;
	}

} //EventObjectImpl
