/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Accessibility</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getAccessibility()
 * @model
 * @generated
 */
public interface Accessibility extends HTMLTable {
} // Accessibility
