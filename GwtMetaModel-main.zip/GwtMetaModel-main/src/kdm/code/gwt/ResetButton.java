/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reset Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getResetButton()
 * @model
 * @generated
 */
public interface ResetButton extends Button {
} // ResetButton
