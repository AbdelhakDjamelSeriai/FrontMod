/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Custom Scroll Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getCustomScrollPanel()
 * @model
 * @generated
 */
public interface CustomScrollPanel extends ScrollPanel {
} // CustomScrollPanel
