/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Has Directional Html</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getHasDirectionalHtml()
 * @model
 * @generated
 */
public interface HasDirectionalHtml extends InterfaceUnit {
} // HasDirectionalHtml
