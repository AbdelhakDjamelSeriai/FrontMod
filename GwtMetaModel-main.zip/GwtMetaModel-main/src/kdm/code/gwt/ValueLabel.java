/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Label</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getValueLabel()
 * @model
 * @generated
 */
public interface ValueLabel extends LabelBase {
} // ValueLabel
