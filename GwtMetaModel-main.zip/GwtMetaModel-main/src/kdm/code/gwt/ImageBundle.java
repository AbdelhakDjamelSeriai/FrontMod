/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image Bundle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getImageBundle()
 * @model
 * @generated
 */
public interface ImageBundle extends InterfaceUnit {
} // ImageBundle
