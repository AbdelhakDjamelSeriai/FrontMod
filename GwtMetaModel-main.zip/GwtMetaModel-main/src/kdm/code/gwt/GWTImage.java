/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>GWT Image</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getGWTImage()
 * @model
 * @generated
 */
public interface GWTImage extends Widget {
} // GWTImage
