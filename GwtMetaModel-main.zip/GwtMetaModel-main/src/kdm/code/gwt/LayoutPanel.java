/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layout Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getLayoutPanel()
 * @model
 * @generated
 */
public interface LayoutPanel extends ComplexPanel {
} // LayoutPanel
