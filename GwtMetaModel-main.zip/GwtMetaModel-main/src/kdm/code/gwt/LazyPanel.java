/**
 */
package kdm.code.gwt;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lazy Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getLazyPanel()
 * @model
 * @generated
 */
public interface LazyPanel extends SimplePanel {
} // LazyPanel
