/**
 */
package kdm.code.gwt;

import kdm.code.InterfaceUnit;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Suggestion Handler</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.gwt.GwtPackage#getSuggestionHandler()
 * @model
 * @generated
 */
public interface SuggestionHandler extends InterfaceUnit {
} // SuggestionHandler
