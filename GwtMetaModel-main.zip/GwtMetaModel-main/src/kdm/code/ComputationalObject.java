/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Computational Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getComputationalObject()
 * @model
 * @generated
 */
public interface ComputationalObject extends CodeItem {
} // ComputationalObject
