/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getValueElement()
 * @model abstract="true"
 * @generated
 */
public interface ValueElement extends DataElement {
} // ValueElement
