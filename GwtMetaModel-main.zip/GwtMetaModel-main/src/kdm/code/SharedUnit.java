/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shared Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getSharedUnit()
 * @model
 * @generated
 */
public interface SharedUnit extends CompilationUnit {
} // SharedUnit
