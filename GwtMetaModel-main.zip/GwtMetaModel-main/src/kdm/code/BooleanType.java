/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Boolean Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getBooleanType()
 * @model
 * @generated
 */
public interface BooleanType extends PrimitiveType {
} // BooleanType
