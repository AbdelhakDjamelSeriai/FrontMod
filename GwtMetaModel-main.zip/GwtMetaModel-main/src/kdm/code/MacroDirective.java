/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Macro Directive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getMacroDirective()
 * @model
 * @generated
 */
public interface MacroDirective extends PreprocessorDirective {
} // MacroDirective
