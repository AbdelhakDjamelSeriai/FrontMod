/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Void Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getVoidType()
 * @model
 * @generated
 */
public interface VoidType extends PrimitiveType {
} // VoidType
