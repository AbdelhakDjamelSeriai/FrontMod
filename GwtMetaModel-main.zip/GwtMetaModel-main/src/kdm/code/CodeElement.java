/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getCodeElement()
 * @model
 * @generated
 */
public interface CodeElement extends CodeItem {
} // CodeElement
