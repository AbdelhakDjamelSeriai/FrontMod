/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Char Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getCharType()
 * @model
 * @generated
 */
public interface CharType extends PrimitiveType {
} // CharType
