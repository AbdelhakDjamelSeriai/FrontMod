/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Compilation Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getCompilationUnit()
 * @model
 * @generated
 */
public interface CompilationUnit extends kdm.code.Module {
} // CompilationUnit
