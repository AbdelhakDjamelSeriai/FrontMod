/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Octetstring Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getOctetstringType()
 * @model
 * @generated
 */
public interface OctetstringType extends PrimitiveType {
} // OctetstringType
