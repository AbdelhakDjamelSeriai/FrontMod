/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getItemUnit()
 * @model
 * @generated
 */
public interface ItemUnit extends DataElement {
} // ItemUnit
