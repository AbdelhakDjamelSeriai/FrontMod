/**
 */
package kdm.code;

import kdm.core.KDMRelationship;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Code Relationship</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getAbstractCodeRelationship()
 * @model abstract="true"
 * @generated
 */
public interface AbstractCodeRelationship extends KDMRelationship {
} // AbstractCodeRelationship
