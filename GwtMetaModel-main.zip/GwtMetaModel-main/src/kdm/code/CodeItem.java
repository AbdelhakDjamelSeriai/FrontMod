/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getCodeItem()
 * @model abstract="true"
 * @generated
 */
public interface CodeItem extends AbstractCodeElement {
} // CodeItem
