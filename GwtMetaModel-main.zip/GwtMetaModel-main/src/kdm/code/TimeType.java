/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Time Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getTimeType()
 * @model
 * @generated
 */
public interface TimeType extends PrimitiveType {
} // TimeType
