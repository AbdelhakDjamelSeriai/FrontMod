/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Integer Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getIntegerType()
 * @model
 * @generated
 */
public interface IntegerType extends PrimitiveType {
} // IntegerType
