/**
 */
package kdm.code;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Template Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kdm.code.CodePackage#getTemplateType()
 * @model
 * @generated
 */
public interface TemplateType extends Datatype {
} // TemplateType
