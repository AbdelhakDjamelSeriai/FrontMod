# ATLauncher

A Java project ready to run <em>ATL/EMFVM<em> transformations.

## Description

This repo contains an ATL model transformation module that transform KDM model to GWT-KDM Model, We show below the content of this project :


  | Path     |  Desription   |
  |----------|:-------------:|
  | [`src/main/java/lirmm/modelTransromation/atl/runner/ATLRunner.java.`](https://github.com/migration-Fr-org/ATLauncher/blob/base/src/main/java/lirmm/modelTransromation/atl/runner/ATLRunner.java) |  it's main transformation class |
  | [`lib`](https://github.com/migration-Fr-org/gwt-kdm-model-transformer/tree/base/lib) | contains dependencies to create <em>FAT JAR</em> |
  | [`metamodels`](https://github.com/migration-Fr-org/gwt-kdm-model-transformer/tree/base/metamodels) | contains Source,Target MetaModel |
  | [`resources`](https://github.com/migration-Fr-org/gwt-kdm-model-transformer/tree/base/resources) | contains external text files for client specifications  |
  | [`models`](https://github.com/migration-Fr-org/gwt-kdm-model-transformer/tree/base/models) | contains models  |
  | [`transformations`](https://github.com/migration-Fr-org/gwt-kdm-model-transformer/tree/base/transformations) | contains emfvtm file (executable) and ATL file (how contains rules)  |
  | [`log.txt`](https://github.com/migration-Fr-org/gwt-kdm-model-transformer/blob/base/log.txt) | Logger |
 
  ## Prerequisites
 
  - Compiler compliance level: 1.7+
  - ATL - ATL Transformation Language 4.5.0.v202105252007+
  - ATL EMFTVM 4.5.0.v202105252007+
 
  ## Usage
 
   run the main class [`ATLRunner`]().