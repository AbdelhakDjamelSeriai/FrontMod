package tests.main.java.lirmm.modelTransromation.units;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;

import main.java.lirmm.modelTransromation.atl.json.ClientModelExtractor;
import main.java.lirmm.modelTransromation.atl.json.ClientModelFileReader;
import main.java.lirmm.modelTransromation.atl.json.ExtractorData;
import main.java.lirmm.modelTransromation.atl.json.JSONFileReader;

public class ExtractorDataTest {

	
	public final static String CLIENT_MODEL = "./resources/client.json";
	
	private JSONFileReader fileReader ;
	
	private ExtractorData extractorData;
	
	@Before
	public void setUp() throws Exception {
		
		fileReader = new ClientModelFileReader(CLIENT_MODEL);
		
		extractorData = new ClientModelExtractor(fileReader);


	}

	
	@Test
	public void it_can_return_pages() {
				
		
		JSONArray pages	= (JSONArray)extractorData.getDesiredData("Pages");
		
		
		Object[] objects= {new String("PageOne"), new String("PageTwo") ,new String("PageThree") ,
				
				new String("PageFour")} ;
		
		
		assertArrayEquals((new ArrayList<Object>(Arrays.asList(objects))).toArray(), new ArrayList<>(Arrays.asList(pages.toArray())).toArray() );
		
	}
	
	@Test 
	public void it_can_return_routes() {
		
				
		JSONArray routes = (JSONArray)extractorData.getDesiredData("Routes");
	
		assertEquals(4, routes.size());
	}
	
	@Test
	public void it_can_return_value_from_object() {
		
		JSONArray routes = (JSONArray)extractorData.getDesiredData("Routes");
		
		JSONObject object = (JSONObject)routes.get(0);
		
		assertEquals("PageTwo", extractorData.getObjectValue(object, "to"));
		
	}
	
	@Test
	public void it_can_return_option() {
		
		String option = (String)extractorData.getDesiredData("option");
		
		assertEquals("pages", option);

		
	}

}
