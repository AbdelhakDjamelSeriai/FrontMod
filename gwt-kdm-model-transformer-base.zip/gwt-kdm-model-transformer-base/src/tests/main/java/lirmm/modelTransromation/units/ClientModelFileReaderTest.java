package tests.main.java.lirmm.modelTransromation.units;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.json.simple.JSONArray;
import org.junit.Before;
import org.junit.Test;

import main.java.lirmm.modelTransromation.atl.json.ClientModelExtractor;
import main.java.lirmm.modelTransromation.atl.json.ClientModelFileReader;
import main.java.lirmm.modelTransromation.atl.json.ExtractorData;
import main.java.lirmm.modelTransromation.atl.json.JSONFileReader;


/**
 * This's an integration test , because we use client file as env of data 
 * @author gm_be
 *
 */
public class ClientModelFileReaderTest {

	public final static String CLIENT_MODEL = "./resources/client.json";
	
	JSONFileReader fileReader ;
	
	@Before
	public void setUp() throws Exception {
		fileReader = new ClientModelFileReader(CLIENT_MODEL);

	}


	@Test
	public void it_can_parse_client_model() {
		
		
		fileReader = new ClientModelFileReader(CLIENT_MODEL);
		
		//fileReader.parseData()
		assertNotNull(null);
	}
	
	

}
