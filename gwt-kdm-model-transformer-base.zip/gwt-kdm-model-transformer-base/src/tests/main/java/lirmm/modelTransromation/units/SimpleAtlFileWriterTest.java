package tests.main.java.lirmm.modelTransromation.units;

import static org.junit.Assert.*;

import org.junit.Test;

import main.java.lirmm.modelTransromation.atl.json.ClientModelFileReader;
import main.java.lirmm.modelTransromation.atl.json.JSONFileReader;
import main.java.lirmm.modelTransromation.atl.writer.SimpleAtlFileWriter;

public class SimpleAtlFileWriterTest {
	
	@Test
	public void it_can_write_data_to_Atl_File() {
		
		
		/*ClientModelFileReader clientModelFileReader = new ClientModelFileReader("./resources/client.json");
		
		SimpleAtlFileWriter simpleAtlFileWriter = new SimpleAtlFileWriter("./transformations/Omg2Kdm.atl");
		
		simpleAtlFileWriter.updateDataInAtlFile(clientModelFileReader.getPages());*/
		
		assertTrue(true);
	}
}
