package main.java.lirmm.modelTransromation.atl.writer;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import org.json.simple.JSONArray;



public class SimpleAtlFileWriter extends AtlFileWriter{
	
	
	
	
	public SimpleAtlFileWriter(String pathToFile) {
		
		try {
			
			this.pathToFile = pathToFile;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	@Override
	public void writeToAtlFile() {
		
	}
	
	/**
	 * 
	 */
	public void updateDataInAtlFile(Object pages /*,Object routes, String token*/) {
		//"helper def :pages : Sequence(String) = Sequence{};"
			
		try {
			
		    int positionOfPagesSequence = 9;
		   // int positionOfRoutesSequence = 10;
		   // int positionOfClassUnitToPageCondition = 644;
			//String dataToBeAdded = chooseYourMethodToDetectPages(token);
			
			
			Path path = Paths.get(this.pathToFile);
			
			List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
	
			pages = String.join(", ", (JSONArray)pages);
		    		    
		    String extraLine = "helper def : addedPagesByClient : Sequence(String) = Sequence {" + pages + "};";
		    
		    lines.set(positionOfPagesSequence, extraLine);
		    //lines.set(positionOfRoutesSequence, (String)routes);
		    //lines.set(positionOfClassUnitToPageCondition,dataToBeAdded);
		    
		    

		    Files.write(path, lines, StandardCharsets.UTF_8);
		    
		    
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 * @param method
	 * @return
	 */
	public static String chooseYourMethodToDetectPages(String method) {
		
		String atlExpression;
		
		switch (method) {
			  case "pages" :
				  
				  atlExpression = "	from src: MM!ClassUnit (thisModule.pages->exists(i | i = src.name) )";
				  
				  break;			  
				  
			  default:
				  
				  atlExpression = "	from src: MM!ClassUnit (src.codeElement->select(e | e.oclIsTypeOf(MM!StorableUnit) and e.type.oclIsTypeOf(MM!ClassUnit) and thisModule.widgets->exists(i | i = e.type.name))->size() > 0)";	  
		
		}
		
		return atlExpression;
			
	}
	
	
	
}
