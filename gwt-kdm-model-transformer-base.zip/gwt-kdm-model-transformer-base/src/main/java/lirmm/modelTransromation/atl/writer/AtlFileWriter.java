package main.java.lirmm.modelTransromation.atl.writer;


abstract public class AtlFileWriter {
	
	protected String pathToFile; 
	
	abstract public void writeToAtlFile();

}
