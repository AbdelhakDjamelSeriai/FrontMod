package main.java.lirmm.modelTransromation.atl.json;

import org.json.simple.JSONObject;

abstract public class ExtractorData {
	
	protected JSONFileReader jsonFileReader;
	
	
	public abstract Object getDesiredData(String key);
	
	
	public abstract String getObjectValue(JSONObject object, String key);
	

}
