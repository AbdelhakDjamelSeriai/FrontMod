package main.java.lirmm.modelTransromation.atl.runner;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.m2m.atl.emftvm.EmftvmFactory;
import org.eclipse.m2m.atl.emftvm.ExecEnv;
import org.eclipse.m2m.atl.emftvm.Metamodel;
import org.eclipse.m2m.atl.emftvm.Model;
import org.eclipse.m2m.atl.emftvm.impl.resource.EMFTVMResourceFactoryImpl;
import org.eclipse.m2m.atl.emftvm.util.DefaultModuleResolver;
import org.eclipse.m2m.atl.emftvm.util.ModuleResolver;
import org.eclipse.m2m.atl.emftvm.util.TimingData;



/**
 * Import for Logger!!
 */
/*import java.util.logging.FileHandler;
import org.eclipse.emf.common.util.Logger;
import org.eclipse.m2m.atl.common.ATLLogFormatter;
import org.eclipse.m2m.atl.common.ATLLogger;*/


/**
 * An off-the-shelf launcher for ATL/EMFTVM transformations
 * @author Mahi BEGOUG - mahi.begoug@etu.umontpellier.fr
 * University of Montpellier - LIRMM Lab.
 * Using code examples from: https://wiki.eclipse.org/ATL/EMFTVM
 */
public class ATLRunner {
	
	
	// Some constants for quick initialization and testing.
	public final static String IN_METAMODEL = "./metamodels/kdm.ecore";
	public final static String IN_METAMODEL_NAME = "MM";
	public final static String OUT_METAMODEL = "./metamodels/kdm_gwt.ecore";
	public final static String OUT_METAMODEL_NAME = "MM1";
	
	
	
	public final static String IN_MODELS_DIR = "./models/inputs/";
	

	public final static String OUT_MODELS_DIR = "./models/outputs/";
	
	
	public final static String TRANSFORMATION_DIR = "./transformations/";
	public final static String TRANSFORMATION_MODULE= "Omg2Kdm";
	
	
	
	// The input and output metamodel nsURIs are resolved using lazy registration of metamodels, see below.
	private String inputMetamodelNsURI;
	private String outputMetamodelNsURI;
	
	//Main transformation launch method
	public void launch(String inMetamodelPath, String inModelPath, String outMetamodelPath,
			String outModelPath, String transformationDir, String transformationModule){
		
		/* 
		 * Creates the execution environment where the transformation is going to be executed,
		 * you could use an execution pool if you want to run multiple transformations in parallel,
		 * but for the purpose of the example let's keep it simple.
		 */
		ExecEnv env = EmftvmFactory.eINSTANCE.createExecEnv();
		ResourceSet rs = new ResourceSetImpl();

		/*
		 * Load meta-models in the resource set we just created, the idea here is to make the meta-models
		 * available in the context of the execution environment, the ResourceSet is later passed to the
		 * ModuleResolver that is the actual class that will run the transformation.
		 * Notice that we use the nsUris to locate the metamodels in the package registry, we initialize them 
		 * from Ecore files that we registered lazily as shown below in e.g. registerInputMetamodel(...) 
		 */
		Metamodel inMetamodel = EmftvmFactory.eINSTANCE.createMetamodel();
		
		inMetamodel.setResource(rs.getResource(URI.createURI(inputMetamodelNsURI), true));
		//inMetamodel.setResource(CodePackage.eINSTANCE.eResource());
		env.registerMetaModel(IN_METAMODEL_NAME, inMetamodel);
		
		Metamodel outMetamodel = EmftvmFactory.eINSTANCE.createMetamodel();
		outMetamodel.setResource(rs.getResource(URI.createURI(outputMetamodelNsURI), true));
		env.registerMetaModel(OUT_METAMODEL_NAME, outMetamodel);
		
		/*
		 * Create and register resource factories to read/parse .xmi and .emftvm files,
		 * we need an .xmi parser because our in/output models are .xmi and our transformations are
		 * compiled using the ATL-EMFTV compiler that generates .emftvm files
		 */
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("emftvm", new EMFTVMResourceFactoryImpl());
	
		
		// Load models

		Model inModel = EmftvmFactory.eINSTANCE.createModel();
		inModel.setResource(rs.getResource(URI.createURI(inModelPath, true), true));
		env.registerInputModel("IN", inModel);
		
		Model outModel = EmftvmFactory.eINSTANCE.createModel();
		outModel.setResource(rs.createResource(URI.createURI(outModelPath)));
		env.registerOutputModel("OUT", outModel);
		
		
		/*
		 *  Load and run the transformation module
		 *  Point at the directory your transformations are stored, the ModuleResolver will 
		 *  look for the .emftvm file corresponding to the module you want to load and run
		 */	 
		ModuleResolver mr = new DefaultModuleResolver(transformationDir, rs);
		TimingData td = new TimingData();
		env.loadModule(mr, TRANSFORMATION_MODULE);
		
		td.finishLoading();
		env.run(td);
		td.finish();
			
		// Save models
		try {
			
			outModel.getResource().save(Collections.emptyMap());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * I seriously hate relying on the eclipse facilities, and if you're not building an eclipse plugin
	 * you can't rely on eclipse's registry (let's say you're building a stand-alone tool that needs to run ATL
	 * transformation, you need to 'manually' register your metamodels) 
	 * This method does two things, it initializes an Ecore parser and then programmatically looks for
	 * the package definition on it, obtains the NsUri and registers it.
	 */
	private String lazyMetamodelRegistration(String metamodelPath){
		
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("*", new EcoreResourceFactoryImpl());
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("emftvm", new EMFTVMResourceFactoryImpl());
   	
	    ResourceSet rs = new ResourceSetImpl();
	    // Enables extended meta-data, weird we have to do this but well...
	    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(EPackage.Registry.INSTANCE);
	    rs.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
	
	    Resource r = rs.getResource(URI.createFileURI(metamodelPath), true);
	    EObject eObject = r.getContents().get(0);
	    // A meta-model might have multiple packages we assume the main package is the first one listed
	    
	    
	    if (eObject instanceof EPackage) {
	    	
	        EPackage p = (EPackage)eObject;
	        EPackage.Registry.INSTANCE.put(p.getNsURI(), p);
	        lazyPackagesRegistration(eObject);
	        return p.getNsURI();
	        
	    }
	    
	    return null;
	}
	
	/**
	 * Register Packages Recursively
	 * @param eObject
	 */
	private void lazyPackagesRegistration(EObject eObject){
	    // A meta-model might have multiple packages we assume the main package is the first one listed
		EList<EPackage> ePackages = ((EPackage) eObject).getESubpackages();
		
		for (EPackage ePackage: ePackages) {
	        EPackage.Registry.INSTANCE.put(ePackage.getNsURI(), ePackage);
		}
		
	}
	
	/*
	 * As shown above we need the inputMetamodelNsURI and the outputMetamodelNsURI to create the context of
	 * the transformation, so we simply use the return value of lazyMetamodelRegistration to store them.
	 * -- Notice that the lazyMetamodelRegistration(..) implementation may return null in case it doesn't 
	 * find a package in the given metamodel, so watch out for malformed metamodels.
	 * 
	 */
	public void registerInputMetamodel(String inputMetamodelPath){	
		inputMetamodelNsURI = lazyMetamodelRegistration(inputMetamodelPath);
	}

	public void registerOutputMetamodel(String outputMetamodelPath){
		outputMetamodelNsURI = lazyMetamodelRegistration(outputMetamodelPath);
	}
	
	
	/**
	 * 
	 * @param inModel
	 * @param sourceMetaMdelName
	 * @param targetMetaModelName
	 * @return
	 */
	public String produiceTargetModelUri(String inModel, String sourceMetaMdelName ,String targetMetaModelName) {	
		String[] parts = inModel.split(sourceMetaMdelName);
	    String part2 = sourceMetaMdelName + "_" + targetMetaModelName;	        		
	     
		return parts[0] + part2 + parts[1];
	}

	/*
	 *  A test main method, I'm using constants so I can quickly change the case study by simply
	 *  modifying the header of the class.
	 */	
	public static void main(String... args) throws IOException{
		
		ATLRunner l = new ATLRunner();
		l.registerInputMetamodel(IN_METAMODEL);
		l.registerOutputMetamodel(OUT_METAMODEL);
		
		// 5 
		
		/*
		ClientModelFileReader clientModelFileReader = new ClientModelFileReader("./resources/client.json");
		
		SimpleAtlFileWriter simpleAtlFileWriter = new SimpleAtlFileWriter("./transformations/Omg2Kdm.atl");
		
		simpleAtlFileWriter.updateDataInAtlFile(clientModelFileReader.getPages());*/
		

		
		/**
		 * Get All models from inputs folder 
		 */
		List<Path> paths =  Files.walk(Paths.get("models/inputs")).filter(Files::isRegularFile).collect(Collectors.toList());
       
		System.out.println("-------------------------------We start transformation-------------------------------");
		
		for (Path path: paths) {
			
			System.out.println("Transform KDM MODEL : " + path.getFileName());
			
			
			l.launch(IN_METAMODEL, 
					IN_MODELS_DIR + path.getFileName(), 
					OUT_METAMODEL, 
					OUT_MODELS_DIR + l.produiceTargetModelUri( path.getFileName().toString(), "kdm", "gwt")
					, TRANSFORMATION_DIR, TRANSFORMATION_MODULE);
			
			System.out.println("GWT-KDM Model Successfully Transformed :" + l.produiceTargetModelUri( path.getFileName().toString(), "kdm", "gwt"));
			
			System.err.println("-------------------------------------------------------------------------------------");
		}
		
		
	}
	
	
}
