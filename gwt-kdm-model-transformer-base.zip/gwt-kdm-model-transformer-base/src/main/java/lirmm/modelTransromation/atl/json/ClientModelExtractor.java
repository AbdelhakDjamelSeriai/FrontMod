package main.java.lirmm.modelTransromation.atl.json;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ClientModelExtractor extends ExtractorData{
	
	
	
	public ClientModelExtractor(JSONFileReader jsonFileReader) {
		
		this.jsonFileReader = jsonFileReader;
		
	}
	
	@Override
	public Object getDesiredData(String key) {
		
		//JSONObject jsonObject = (JSONObject)jsonFileReader.parseData();

		//return (Object)jsonObject.get(key);
		return null;
	}
	
	@Override
	public String getObjectValue(JSONObject object,String key) {
		
		return (String)object.get(key);
	}

}
