package main.java.lirmm.modelTransromation.atl.json;

import java.io.FileReader;

abstract public class JSONFileReader {
	
	//protected  fileReader;
	
	abstract public Object parseData(FileReader fileReader);
}
