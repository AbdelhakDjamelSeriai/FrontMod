package main.java.lirmm.modelTransromation.atl.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class ClientModelFileReader extends JSONFileReader{
	
	public String pathToFile;
	
	public ClientModelFileReader(String pathToFile) {
		try {
			this.pathToFile = pathToFile;
			//this.fileReader = new FileReader(pathToFile);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public Object parseData(FileReader reader) {
		
		
		JSONParser parser = new JSONParser();
		
		JSONObject dataObject = null;
		
		try {
				        
	        dataObject = (JSONObject)parser.parse(reader); 
                        

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		} catch (org.json.simple.parser.ParseException e) {
			e.printStackTrace();
		}
		
		return (Object)dataObject;
	}
	
	/**
	 * 
	 * @return
	 */
	public JSONArray getPages() {
		
		JSONObject object = null;
		
		try {
			
			object = (JSONObject) this.parseData(new FileReader(pathToFile));

		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return (JSONArray)object.get("Pages");
	}
	
	
	/**
	 * 
	 * @return
	*/
	public JSONArray getRoutes() {
		
		JSONObject object = null;
		
		try {
			
			object = (JSONObject) this.parseData(new FileReader(pathToFile));

		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return (JSONArray)object.get("Routes");
	}
	
	/**
	 * 
	 */
	public String transformRoutesToSequence(JSONArray jsonArray) {
		
	   String sequences= "helper def :routes : Sequence(Sequence(String)) = Sequence { ";
		
		String internalSequence = null;
		
		for (int i = 0 ; i < jsonArray.size(); i++) {
			
			internalSequence = jsonArray.get(i).toString().replaceAll("(\"by\":)|(\"from\":)|(\"token\":)|(\"to\":)|(\")", "");
			
			internalSequence = "Sequence"+internalSequence+",";
			
			sequences = sequences+internalSequence;
			
			
		}
		// 
		//System.out.println(sequences.substring(0, sequences.length() - 1)+"};");
		return sequences.substring(0, sequences.length() - 1)+"};";
	}

}
